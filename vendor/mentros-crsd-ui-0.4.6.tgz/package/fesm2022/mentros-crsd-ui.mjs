import * as i0 from '@angular/core';
import { input, booleanAttribute, HostListener, HostBinding, Attribute, Directive, InjectionToken, signal, computed, inject, Injectable, Component, model, output, effect, contentChild, TemplateRef, ElementRef, ViewContainerRef, DestroyRef, ApplicationRef, viewChild, contentChildren } from '@angular/core';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { DomPortal, TemplatePortal } from '@angular/cdk/portal';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { fromEvent, filter, timer, merge } from 'rxjs';
import { filter as filter$1, switchMap, takeUntil } from 'rxjs/operators';
import { Overlay, OverlayConfig } from '@angular/cdk/overlay';
import { FocusTrapFactory } from '@angular/cdk/a11y';
import { NgTemplateOutlet } from '@angular/common';

function cn(...inputs) {
    return twMerge(clsx(inputs));
}

const BUTTON_BASE = 'inline-flex cursor-pointer items-center justify-center gap-2 rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none';
const SOLID_CLASSES$1 = {
    primary: 'bg-primary text-primary-foreground hover:bg-primary/90',
    secondary: 'bg-secondary text-secondary-foreground hover:bg-secondary/80',
    success: 'bg-success text-success-foreground hover:bg-success/90',
    warning: 'bg-warning text-warning-foreground hover:bg-warning/90',
    info: 'bg-info text-info-foreground hover:bg-info/90',
    destructive: 'bg-destructive text-destructive-foreground hover:bg-destructive/90',
    inherit: 'bg-transparent text-inherit hover:bg-foreground/10',
};
const OUTLINE_CLASSES$1 = {
    primary: 'border border-primary bg-background text-primary hover:bg-primary/10',
    secondary: 'border border-secondary bg-background text-secondary-foreground hover:bg-secondary/10',
    success: 'border border-success bg-background text-success hover:bg-success/10',
    warning: 'border border-warning bg-background text-warning hover:bg-warning/10',
    info: 'border border-info bg-background text-info hover:bg-info/10',
    destructive: 'border border-destructive bg-background text-destructive hover:bg-destructive/10',
    inherit: 'border-transparent bg-transparent text-inherit hover:bg-foreground/10',
};
const GHOST_CLASSES = {
    primary: 'text-primary hover:bg-primary/10',
    secondary: 'text-secondary-foreground hover:bg-secondary/10',
    success: 'text-success hover:bg-success/10',
    warning: 'text-warning hover:bg-warning/10',
    info: 'text-info hover:bg-info/10',
    destructive: 'text-destructive hover:bg-destructive/10',
    inherit: 'text-inherit hover:bg-foreground/10',
};
const LINK_CLASSES = {
    primary: 'text-primary underline-offset-4 hover:underline',
    secondary: 'text-secondary-foreground underline-offset-4 hover:underline',
    success: 'text-success underline-offset-4 hover:underline',
    warning: 'text-warning underline-offset-4 hover:underline',
    info: 'text-info underline-offset-4 hover:underline',
    destructive: 'text-destructive underline-offset-4 hover:underline',
    inherit: 'text-inherit underline-offset-4 hover:underline',
};
const SOFT_CLASSES$1 = {
    primary: 'bg-primary/10 text-primary hover:bg-primary/20',
    secondary: 'bg-secondary/50 text-secondary-foreground hover:bg-secondary/70',
    success: 'bg-success/10 text-success hover:bg-success/20',
    warning: 'bg-warning/10 text-warning hover:bg-warning/20',
    info: 'bg-info/10 text-info hover:bg-info/20',
    destructive: 'bg-destructive/10 text-destructive hover:bg-destructive/20',
    inherit: 'bg-transparent text-inherit hover:bg-foreground/10',
};
const VARIANT_CLASSES$1 = {
    solid: SOLID_CLASSES$1,
    outline: OUTLINE_CLASSES$1,
    ghost: GHOST_CLASSES,
    link: LINK_CLASSES,
    soft: SOFT_CLASSES$1,
};
function buttonClasses(variant, color) {
    return VARIANT_CLASSES$1[variant][color];
}
const BUTTON_SIZES = {
    sm: 'h-8 px-3 text-xs',
    md: 'h-10 px-4 py-2',
    lg: 'h-11 px-8',
    'icon-xs': 'size-3.5 shrink-0 p-0 min-h-0 min-w-0 ring-offset-0 [&_.crsd-icon-graphic]:size-2.5',
    'icon-sm': 'size-5 shrink-0 p-0 min-h-0 min-w-0 ring-offset-0 [&_.crsd-icon-graphic]:size-3',
    icon: 'size-10 shrink-0 p-0 ring-offset-0 [&_.crsd-icon-graphic]:size-4',
};
const ICON_BTN_SIZE_SET = new Set(['icon-xs', 'icon-sm', 'icon']);
/** Icon-only button sizes — do not pair with visible text labels. */
function isIconBtnSize(size) {
    return ICON_BTN_SIZE_SET.has(size);
}
/** Neutralizes BUTTON_BASE typography so fixed icon box sizes stay square. */
const BUTTON_ICON_TYPO = 'gap-0 text-[0] leading-none font-normal';

class CrsdBtn {
    staticClass;
    variant = input('solid', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    color = input('primary', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []));
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    loading = input(false, { ...(ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    get hostClasses() {
        const size = this.size();
        return cn(BUTTON_BASE, isIconBtnSize(size) && BUTTON_ICON_TYPO, buttonClasses(this.variant(), this.color()), BUTTON_SIZES[size], {
            'opacity-50 pointer-events-none': this.disabled() || this.loading(),
        }, this.staticClass, this.userClass());
    }
    onClick(event) {
        if (this.disabled() || this.loading()) {
            event.preventDefault();
            event.stopImmediatePropagation();
        }
    }
    onKeydown(event) {
        if (this.disabled() || this.loading()) {
            event.preventDefault();
            event.stopImmediatePropagation();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdBtn, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdBtn, isStandalone: true, selector: "[crsdBtn]", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, color: { classPropertyName: "color", publicName: "color", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "button" }, listeners: { "click": "onClick($event)", "keydown.enter": "onKeydown($event)", "keydown.space": "onKeydown($event)" }, properties: { "attr.type": "\"button\"", "attr.disabled": "disabled() || loading() ? true : null", "attr.aria-disabled": "disabled() || loading() ? \"true\" : null", "attr.aria-busy": "loading() ? \"true\" : null", "class": "this.hostClasses" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdBtn, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdBtn]',
                    standalone: true,
                    host: {
                        role: 'button',
                        '[attr.type]': '"button"',
                        '[attr.disabled]': 'disabled() || loading() ? true : null',
                        '[attr.aria-disabled]': 'disabled() || loading() ? "true" : null',
                        '[attr.aria-busy]': 'loading() ? "true" : null',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], color: [{ type: i0.Input, args: [{ isSignal: true, alias: "color", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }], onClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }], onKeydown: [{
                type: HostListener,
                args: ['keydown.enter', ['$event']]
            }, {
                type: HostListener,
                args: ['keydown.space', ['$event']]
            }] } });

const CRSD_THEME_FEATURES = [
    'motion',
    'ambient',
    'copy',
    'icons',
    'forms',
    'table',
    'bursts',
];
const DEFAULT_THEME_FEATURES = {
    motion: true,
    ambient: true,
    copy: true,
    icons: true,
    forms: true,
    table: true,
    bursts: true,
};
function mergeThemeFeatures(base, ...overrides) {
    return overrides.reduce((flags, patch) => ({ ...flags, ...patch }), { ...base });
}
function featureDatasetKey(feature) {
    return `crsdFeature${feature.charAt(0).toUpperCase()}${feature.slice(1)}`;
}

const CRSD_THEME_CONFIG = new InjectionToken('CRSD_THEME_CONFIG');
const THEME_STORAGE_KEY = 'crsd-theme';
const INTENSITY_STORAGE_KEY = 'crsd-cursed-intensity';
const LEGACY_DOCS_THEME_KEY = 'crsd-docs-theme';
function provideCrsdTheme(config = {}) {
    return { provide: CRSD_THEME_CONFIG, useValue: config };
}
class CrsdThemeService {
    theme = signal('default', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "theme" }] : /* istanbul ignore next */ []));
    intensity = signal('medium', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "intensity" }] : /* istanbul ignore next */ []));
    corruptionActive = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "corruptionActive" }] : /* istanbul ignore next */ []));
    radianceActive = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "radianceActive" }] : /* istanbul ignore next */ []));
    isCursed = computed(() => this.theme() === 'cursed', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isCursed" }] : /* istanbul ignore next */ []));
    isBlessed = computed(() => this.theme() === 'blessed', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isBlessed" }] : /* istanbul ignore next */ []));
    isThemed = computed(() => this.theme() !== 'default', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isThemed" }] : /* istanbul ignore next */ []));
    features = computed(() => {
        if (!this.isThemed()) {
            return { ...DEFAULT_THEME_FEATURES };
        }
        const presetOverrides = this.theme() === 'cursed' ? this.presetConfig.cursed : this.presetConfig.blessed;
        return mergeThemeFeatures(DEFAULT_THEME_FEATURES, presetOverrides, this.runtimeFeatureOverrides());
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "features" }] : /* istanbul ignore next */ []));
    injectedConfig = inject(CRSD_THEME_CONFIG, { optional: true }) ?? {};
    presetConfig = { ...this.injectedConfig };
    runtimeFeatureOverrides = signal({}, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "runtimeFeatureOverrides" }] : /* istanbul ignore next */ []));
    corruptionTimer = null;
    radianceTimer = null;
    constructor() {
        this.restoreFromStorage();
        this.apply();
    }
    isFeatureEnabled(feature) {
        if (!this.isThemed()) {
            return false;
        }
        return this.features()[feature];
    }
    setFeature(feature, enabled) {
        this.runtimeFeatureOverrides.update((current) => ({
            ...current,
            [feature]: enabled,
        }));
        this.apply();
    }
    configureFeatures(overrides) {
        this.runtimeFeatureOverrides.update((current) => ({
            ...current,
            ...overrides,
        }));
        this.apply();
    }
    resetFeatures() {
        this.runtimeFeatureOverrides.set({});
        this.apply();
    }
    configurePreset(config) {
        this.presetConfig = {
            cursed: { ...this.injectedConfig.cursed, ...this.presetConfig.cursed, ...config.cursed },
            blessed: { ...this.injectedConfig.blessed, ...this.presetConfig.blessed, ...config.blessed },
        };
        this.apply();
    }
    setTheme(theme) {
        this.theme.set(theme);
        if (theme !== 'cursed') {
            this.corruptionActive.set(false);
        }
        if (theme !== 'blessed') {
            this.radianceActive.set(false);
        }
        this.persist();
        this.apply();
    }
    setIntensity(intensity) {
        this.intensity.set(intensity);
        this.persist();
        this.apply();
    }
    toggle() {
        const order = ['default', 'cursed', 'blessed'];
        const index = order.indexOf(this.theme());
        this.setTheme(order[(index + 1) % order.length] ?? 'default');
    }
    triggerCorruption(durationMs = 3000) {
        if (typeof document === 'undefined') {
            return;
        }
        if (this.theme() !== 'cursed') {
            this.setTheme('cursed');
        }
        if (!this.isFeatureEnabled('bursts')) {
            return;
        }
        this.radianceActive.set(false);
        this.corruptionActive.set(true);
        this.apply();
        if (this.corruptionTimer) {
            clearTimeout(this.corruptionTimer);
        }
        this.corruptionTimer = setTimeout(() => {
            this.corruptionActive.set(false);
            this.apply();
            this.corruptionTimer = null;
        }, durationMs);
    }
    triggerRadiance(durationMs = 3000) {
        if (typeof document === 'undefined') {
            return;
        }
        if (this.theme() !== 'blessed') {
            this.setTheme('blessed');
        }
        if (!this.isFeatureEnabled('bursts')) {
            return;
        }
        this.corruptionActive.set(false);
        this.radianceActive.set(true);
        this.apply();
        if (this.radianceTimer) {
            clearTimeout(this.radianceTimer);
        }
        this.radianceTimer = setTimeout(() => {
            this.radianceActive.set(false);
            this.apply();
            this.radianceTimer = null;
        }, durationMs);
    }
    restoreFromStorage() {
        if (typeof localStorage === 'undefined') {
            return;
        }
        const legacy = localStorage.getItem(LEGACY_DOCS_THEME_KEY);
        const storedTheme = localStorage.getItem(THEME_STORAGE_KEY) ?? legacy;
        const storedIntensity = localStorage.getItem(INTENSITY_STORAGE_KEY);
        if (storedTheme === 'cursed' || storedTheme === 'blessed') {
            this.theme.set(storedTheme);
        }
        if (storedIntensity === 'low' ||
            storedIntensity === 'medium' ||
            storedIntensity === 'high') {
            this.intensity.set(storedIntensity);
        }
        if (legacy && !localStorage.getItem(THEME_STORAGE_KEY)) {
            localStorage.setItem(THEME_STORAGE_KEY, legacy);
            localStorage.removeItem(LEGACY_DOCS_THEME_KEY);
        }
    }
    persist() {
        if (typeof localStorage === 'undefined') {
            return;
        }
        localStorage.setItem(THEME_STORAGE_KEY, this.theme());
        localStorage.setItem(INTENSITY_STORAGE_KEY, this.intensity());
    }
    apply() {
        if (typeof document === 'undefined') {
            return;
        }
        const root = document.documentElement;
        delete root.dataset['crsdTheme'];
        delete root.dataset['crsdCursedIntensity'];
        delete root.dataset['crsdCursedCorruption'];
        delete root.dataset['crsdBlessedRadiance'];
        for (const feature of CRSD_THEME_FEATURES) {
            delete root.dataset[featureDatasetKey(feature)];
        }
        if (this.theme() === 'default') {
            this.corruptionActive.set(false);
            this.radianceActive.set(false);
            return;
        }
        root.dataset['crsdTheme'] = this.theme();
        const flags = this.features();
        for (const feature of CRSD_THEME_FEATURES) {
            root.dataset[featureDatasetKey(feature)] = flags[feature] ? 'on' : 'off';
        }
        if (this.theme() === 'cursed') {
            root.dataset['crsdCursedIntensity'] = this.intensity();
            if (this.corruptionActive() && flags.bursts) {
                root.dataset['crsdCursedCorruption'] = 'true';
            }
        }
        if (this.theme() === 'blessed' && this.radianceActive() && flags.bursts) {
            root.dataset['crsdBlessedRadiance'] = 'true';
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdThemeService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdThemeService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdThemeService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });
function applyCrsdThemeFromStorage() {
    if (typeof document === 'undefined' || typeof localStorage === 'undefined') {
        return;
    }
    const legacy = localStorage.getItem(LEGACY_DOCS_THEME_KEY);
    const theme = localStorage.getItem(THEME_STORAGE_KEY) ?? legacy;
    const intensity = localStorage.getItem(INTENSITY_STORAGE_KEY) ?? 'medium';
    if (theme === 'cursed' || theme === 'blessed') {
        document.documentElement.dataset['crsdTheme'] = theme;
        if (theme === 'cursed') {
            document.documentElement.dataset['crsdCursedIntensity'] = intensity;
        }
        for (const feature of CRSD_THEME_FEATURES) {
            document.documentElement.dataset[featureDatasetKey(feature)] = 'on';
        }
    }
}

const CURSED_ICON_SHAPES = {
    check: [
        { type: 'path', d: 'M20 6 9 17l-2-2' },
        { type: 'path', d: 'M6 6l3 3' },
    ],
    x: [
        { type: 'path', d: 'M19 5 5 19' },
        { type: 'path', d: 'm7 5 12 12' },
    ],
    star: [
        { type: 'path', d: 'M12 2l1.4 4.3 4.6.2-3.6 2.7 1.3 4.5L12 11.8 8.3 14l1.3-4.5-3.6-2.7 4.6-.2L12 2z' },
        { type: 'path', d: 'M4 20l2-6' },
    ],
    'alert-triangle': [
        { type: 'path', d: 'M12 3 2 21h20L12 3z' },
        { type: 'path', d: 'M12 9v5' },
        { type: 'path', d: 'M11 17h2' },
        { type: 'path', d: 'M8 19l8-14' },
    ],
    loader: [
        { type: 'path', d: 'M12 2v4' },
        { type: 'path', d: 'M12 18v4' },
        { type: 'path', d: 'm4.93 4.93 2.83 2.83' },
        { type: 'path', d: 'm16.24 16.24 2.83 2.83' },
        { type: 'path', d: 'M2 12h4' },
        { type: 'path', d: 'M18 12h4' },
    ],
    heart: [
        { type: 'path', d: 'M12 21s-6-4.35-8-7.5C2.5 10.5 4 7 7 7c1.7 0 3 1 5 3 2-2 3.3-3 5-3 3 0 4.5 3.5 3 6.5-2 3.15-8 7.5-8 7.5z' },
        { type: 'path', d: 'M8 9l2 2 4-4' },
    ],
    settings: [
        { type: 'circle', cx: '12', cy: '12', r: '3' },
        { type: 'path', d: 'M12 2v2' },
        { type: 'path', d: 'M12 20v2' },
        { type: 'path', d: 'm4.93 4.93 1.41 1.41' },
        { type: 'path', d: 'm17.66 17.66 1.41 1.41' },
        { type: 'path', d: 'M2 12h2' },
        { type: 'path', d: 'M20 12h2' },
    ],
    user: [
        { type: 'circle', cx: '12', cy: '8', r: '3.5' },
        { type: 'path', d: 'M6 20c0-3.5 2.7-6 6-6s6 2.5 6 6' },
        { type: 'circle', cx: '9', cy: '7.5', r: '0.5' },
        { type: 'circle', cx: '15', cy: '7.5', r: '0.5' },
    ],
    home: [
        { type: 'path', d: 'M4 11 12 4l8 7' },
        { type: 'path', d: 'M6 10v9h12v-9' },
        { type: 'path', d: 'M10 19V13h4v6' },
        { type: 'path', d: 'M3 21h18' },
    ],
    search: [
        { type: 'circle', cx: '10', cy: '10', r: '6' },
        { type: 'path', d: 'm21 21-5-5' },
        { type: 'path', d: 'M8 8h4' },
    ],
    bell: [
        { type: 'path', d: 'M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9' },
        { type: 'path', d: 'M10 21h4' },
        { type: 'path', d: 'M12 3v2' },
    ],
};
function isCursedIconName(name) {
    return name in CURSED_ICON_SHAPES;
}

const BLESSED_ICON_SHAPES = {
    check: [
        { type: 'circle', cx: '12', cy: '12', r: '9' },
        { type: 'path', d: 'M8 12.5 10.5 15 16 9' },
    ],
    x: [
        { type: 'circle', cx: '12', cy: '12', r: '9' },
        { type: 'path', d: 'M9 9l6 6' },
        { type: 'path', d: 'm15 9-6 6' },
    ],
    star: [
        { type: 'path', d: 'M12 3l2.2 4.5 5 .7-3.6 3.5 1 5.2L12 14.8 7.4 17l1-5.2L4.8 8.2l5-.7L12 3z' },
        { type: 'path', d: 'M12 3v2' },
    ],
    'alert-triangle': [
        { type: 'path', d: 'M12 4.5 20.5 19H3.5L12 4.5z' },
        { type: 'path', d: 'M12 9v4.5' },
        { type: 'circle', cx: '12', cy: '16.5', r: '0.75' },
    ],
    loader: [
        { type: 'circle', cx: '12', cy: '12', r: '9' },
        { type: 'path', d: 'M12 3v3' },
        { type: 'path', d: 'M12 18v3' },
        { type: 'path', d: 'm4.22 4.22 2.12 2.12' },
        { type: 'path', d: 'm17.66 17.66 2.12 2.12' },
        { type: 'path', d: 'M3 12h3' },
        { type: 'path', d: 'M18 12h3' },
    ],
    heart: [
        {
            type: 'path',
            d: 'M12 20.5s-5.5-3.8-7.5-6.8C2.8 10.8 4.5 7.5 7.8 7.5c1.6 0 2.8.8 4.2 2.4 1.4-1.6 2.6-2.4 4.2-2.4 3.3 0 5 3.3 3.3 6.2-2 3-7.5 6.8-7.5 6.8z',
        },
        { type: 'path', d: 'M9 10.5l1.8 1.8L15 8' },
    ],
    settings: [
        { type: 'circle', cx: '12', cy: '12', r: '3.5' },
        { type: 'path', d: 'M12 2.5v2.5' },
        { type: 'path', d: 'M12 19v2.5' },
        { type: 'path', d: 'm4.5 4.5 1.8 1.8' },
        { type: 'path', d: 'm17.7 17.7 1.8 1.8' },
        { type: 'path', d: 'M2.5 12H5' },
        { type: 'path', d: 'M19 12h2.5' },
    ],
    user: [
        { type: 'circle', cx: '12', cy: '8.5', r: '3.25' },
        { type: 'path', d: 'M6.5 19.5c0-3 2.5-5.5 5.5-5.5s5.5 2.5 5.5 5.5' },
        { type: 'path', d: 'M12 2.5v1.5' },
    ],
    home: [
        { type: 'path', d: 'M5 11.5 12 5l7 6.5' },
        { type: 'path', d: 'M7.5 10.5V19h9v-8.5' },
        { type: 'path', d: 'M10 19v-4.5h4V19' },
        { type: 'path', d: 'M4 19.5h16' },
    ],
    search: [
        { type: 'circle', cx: '10.5', cy: '10.5', r: '5.5' },
        { type: 'path', d: 'm20 20-4.8-4.8' },
        { type: 'path', d: 'M10.5 7.5v6' },
    ],
    bell: [
        { type: 'path', d: 'M6.5 9.5a5.5 5.5 0 0 1 11 0c0 6 2.5 7.5 2.5 7.5H4s2.5-1.5 2.5-7.5' },
        { type: 'path', d: 'M10.5 19a1.5 1.5 0 0 0 3 0' },
        { type: 'path', d: 'M12 3.5v1.5' },
    ],
};
function isBlessedIconName(name) {
    return name in BLESSED_ICON_SHAPES;
}

const ICON_BASE = 'shrink-0 pointer-events-none';
const ICON_SIZES = {
    xs: 'size-3',
    sm: 'size-4',
    md: 'size-5',
    lg: 'size-6',
};
const ICON_SHAPES = {
    plus: [
        { type: 'path', d: 'M5 12h14' },
        { type: 'path', d: 'M12 5v14' },
    ],
    minus: [{ type: 'path', d: 'M5 12h14' }],
    x: [
        { type: 'path', d: 'M18 6 6 18' },
        { type: 'path', d: 'm6 6 12 12' },
    ],
    check: [{ type: 'path', d: 'M20 6 9 17l-5-5' }],
    'chevron-up': [{ type: 'path', d: 'm18 15-6-6-6 6' }],
    'chevron-down': [{ type: 'path', d: 'm6 9 6 6 6-6' }],
    'chevron-left': [{ type: 'path', d: 'm15 18-6-6 6-6' }],
    'chevron-right': [{ type: 'path', d: 'm9 18 6-6-6-6' }],
    'arrow-up': [
        { type: 'path', d: 'm5 12 7-7 7 7' },
        { type: 'path', d: 'M12 19V5' },
    ],
    'arrow-down': [
        { type: 'path', d: 'M12 5v14' },
        { type: 'path', d: 'm19 12-7 7-7-7' },
    ],
    'arrow-left': [
        { type: 'path', d: 'm12 19-7-7 7-7' },
        { type: 'path', d: 'M19 12H5' },
    ],
    'arrow-right': [
        { type: 'path', d: 'M5 12h14' },
        { type: 'path', d: 'm12 5 7 7-7 7' },
    ],
    search: [
        { type: 'circle', cx: '11', cy: '11', r: '8' },
        { type: 'path', d: 'm21 21-4.3-4.3' },
    ],
    settings: [
        {
            type: 'path',
            d: 'M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z',
        },
        { type: 'circle', cx: '12', cy: '12', r: '3' },
    ],
    menu: [
        { type: 'path', d: 'M4 12h16' },
        { type: 'path', d: 'M4 6h16' },
        { type: 'path', d: 'M4 18h16' },
    ],
    user: [
        { type: 'path', d: 'M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2' },
        { type: 'circle', cx: '12', cy: '7', r: '4' },
    ],
    mail: [
        { type: 'rect', x: '2', y: '4', width: '20', height: '16', rx: '2' },
        { type: 'path', d: 'm22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7' },
    ],
    bell: [
        { type: 'path', d: 'M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9' },
        { type: 'path', d: 'M10.3 21a1.94 1.94 0 0 0 3.4 0' },
    ],
    trash: [
        { type: 'path', d: 'M3 6h18' },
        { type: 'path', d: 'M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6' },
        { type: 'path', d: 'M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2' },
    ],
    pencil: [
        {
            type: 'path',
            d: 'M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z',
        },
        { type: 'path', d: 'm15 5 4 4' },
    ],
    copy: [
        { type: 'rect', x: '9', y: '9', width: '13', height: '13', rx: '2' },
        { type: 'path', d: 'M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1' },
    ],
    download: [
        { type: 'path', d: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4' },
        { type: 'polyline', points: '7 10 12 15 17 10' },
        { type: 'path', d: 'M12 15V3' },
    ],
    upload: [
        { type: 'path', d: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4' },
        { type: 'polyline', points: '17 8 12 3 7 8' },
        { type: 'path', d: 'M12 3v12' },
    ],
    'external-link': [
        { type: 'path', d: 'M15 3h6v6' },
        { type: 'path', d: 'M10 14 21 3' },
        { type: 'path', d: 'M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6' },
    ],
    info: [
        { type: 'circle', cx: '12', cy: '12', r: '10' },
        { type: 'path', d: 'M12 16v-4' },
        { type: 'path', d: 'M12 8h.01' },
    ],
    'alert-triangle': [
        {
            type: 'path',
            d: 'm21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3',
        },
        { type: 'path', d: 'M12 9v4' },
        { type: 'path', d: 'M12 17h.01' },
    ],
    'alert-circle': [
        { type: 'circle', cx: '12', cy: '12', r: '10' },
        { type: 'path', d: 'M12 8v4' },
        { type: 'path', d: 'M12 16h.01' },
    ],
    loader: [{ type: 'path', d: 'M21 12a9 9 0 1 1-6.219-8.56' }],
    home: [
        { type: 'path', d: 'm3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z' },
        { type: 'polyline', points: '9 22 9 12 15 12 15 22' },
    ],
    heart: [
        {
            type: 'path',
            d: 'M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z',
        },
    ],
    star: [
        {
            type: 'path',
            d: 'M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z',
        },
    ],
    eye: [
        { type: 'path', d: 'M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z' },
        { type: 'circle', cx: '12', cy: '12', r: '3' },
    ],
    'eye-off': [
        { type: 'path', d: 'M9.88 9.88a3 3 0 1 0 4.24 4.24' },
        {
            type: 'path',
            d: 'M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68',
        },
        {
            type: 'path',
            d: 'M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61',
        },
        { type: 'line', x1: '2', y1: '2', x2: '22', y2: '22' },
    ],
    lock: [
        { type: 'rect', x: '3', y: '11', width: '18', height: '11', rx: '2' },
        { type: 'path', d: 'M7 11V7a5 5 0 0 1 10 0v4' },
    ],
    unlock: [
        { type: 'rect', x: '3', y: '11', width: '18', height: '11', rx: '2' },
        { type: 'path', d: 'M7 11V7a5 5 0 0 1 9.9-1' },
    ],
    calendar: [
        { type: 'rect', x: '3', y: '4', width: '18', height: '18', rx: '2' },
        { type: 'path', d: 'M16 2v4' },
        { type: 'path', d: 'M8 2v4' },
        { type: 'path', d: 'M3 10h18' },
    ],
    clock: [
        { type: 'circle', cx: '12', cy: '12', r: '10' },
        { type: 'polyline', points: '12 6 12 12 16 14' },
    ],
    sun: [
        { type: 'circle', cx: '12', cy: '12', r: '4' },
        { type: 'path', d: 'M12 2v2' },
        { type: 'path', d: 'M12 20v2' },
        { type: 'path', d: 'm4.93 4.93 1.41 1.41' },
        { type: 'path', d: 'm17.66 17.66 1.41 1.41' },
        { type: 'path', d: 'M2 12h2' },
        { type: 'path', d: 'M20 12h2' },
        { type: 'path', d: 'm6.34 17.66-1.41 1.41' },
        { type: 'path', d: 'm19.07 4.93-1.41 1.41' },
    ],
    moon: [{ type: 'path', d: 'M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z' }],
    filter: [{ type: 'path', d: 'M22 3H2l8 9.46V19l4 2v-8.54L22 3z' }],
    'more-horizontal': [
        { type: 'circle', cx: '12', cy: '12', r: '1' },
        { type: 'circle', cx: '19', cy: '12', r: '1' },
        { type: 'circle', cx: '5', cy: '12', r: '1' },
    ],
    'more-vertical': [
        { type: 'circle', cx: '12', cy: '12', r: '1' },
        { type: 'circle', cx: '12', cy: '5', r: '1' },
        { type: 'circle', cx: '12', cy: '19', r: '1' },
    ],
    refresh: [
        { type: 'path', d: 'M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8' },
        { type: 'path', d: 'M21 3v5h-5' },
        { type: 'path', d: 'M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16' },
        { type: 'path', d: 'M8 16H3v5' },
    ],
    link: [
        { type: 'path', d: 'M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71' },
        { type: 'path', d: 'M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71' },
    ],
    folder: [{ type: 'path', d: 'M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z' }],
    file: [
        { type: 'path', d: 'M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z' },
        { type: 'path', d: 'M14 2v4a2 2 0 0 0 2 2h4' },
    ],
    share: [
        { type: 'path', d: 'M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8' },
        { type: 'polyline', points: '16 6 12 2 8 6' },
        { type: 'path', d: 'M12 2v13' },
    ],
    'log-in': [
        { type: 'path', d: 'M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4' },
        { type: 'polyline', points: '10 17 15 12 10 7' },
        { type: 'path', d: 'M15 12H3' },
    ],
    'log-out': [
        { type: 'path', d: 'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4' },
        { type: 'polyline', points: '16 17 21 12 16 7' },
        { type: 'path', d: 'M21 12H9' },
    ],
};
function iconShapes(name) {
    return ICON_SHAPES[name];
}
function resolveIconShapes(name, theme) {
    if (theme === 'cursed' && isCursedIconName(name)) {
        return CURSED_ICON_SHAPES[name];
    }
    if (theme === 'blessed' && isBlessedIconName(name)) {
        return BLESSED_ICON_SHAPES[name];
    }
    return iconShapes(name);
}

class CrsdIcon {
    name = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []));
    size = input('sm', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    strokeWidth = input(2, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "strokeWidth" }] : /* istanbul ignore next */ []));
    spin = input(false, { ...(ngDevMode ? { debugName: "spin" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    themeService = inject(CrsdThemeService);
    get hostClasses() {
        return cn('inline-flex', this.userClass());
    }
    shapes = computed(() => {
        if (!this.themeService.isFeatureEnabled('icons')) {
            return iconShapes(this.name());
        }
        return resolveIconShapes(this.name(), this.themeService.theme());
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "shapes" }] : /* istanbul ignore next */ []));
    svgClasses = computed(() => cn(ICON_BASE, ICON_SIZES[this.size()], 'crsd-icon-graphic', {
        'animate-spin': this.spin() || this.name() === 'loader',
        'crsd-icon-graphic--cursed-loader': this.themeService.isFeatureEnabled('motion') &&
            this.themeService.isCursed() &&
            (this.spin() || this.name() === 'loader'),
        'crsd-icon-graphic--blessed-loader': this.themeService.isFeatureEnabled('motion') &&
            this.themeService.isBlessed() &&
            (this.spin() || this.name() === 'loader'),
    }), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "svgClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdIcon, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.2.3", type: CrsdIcon, isStandalone: true, selector: "crsd-icon", inputs: { name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: true, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, strokeWidth: { classPropertyName: "strokeWidth", publicName: "strokeWidth", isSignal: true, isRequired: false, transformFunction: null }, spin: { classPropertyName: "spin", publicName: "spin", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "this.hostClasses" } }, ngImport: i0, template: `
    <svg
      [class]="svgClasses()"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      [attr.stroke-width]="strokeWidth()"
      stroke-linecap="round"
      stroke-linejoin="round"
      [attr.aria-hidden]="label() ? null : 'true'"
      [attr.role]="label() ? 'img' : null"
      [attr.aria-label]="label() || null"
    >
      @for (shape of shapes(); track $index) {
        @switch (shape.type) {
          @case ('path') {
            <path [attr.d]="shape.d" />
          }
          @case ('circle') {
            <circle [attr.cx]="shape.cx" [attr.cy]="shape.cy" [attr.r]="shape.r" />
          }
          @case ('line') {
            <line [attr.x1]="shape.x1" [attr.y1]="shape.y1" [attr.x2]="shape.x2" [attr.y2]="shape.y2" />
          }
          @case ('polyline') {
            <polyline [attr.points]="shape.points" />
          }
          @case ('rect') {
            <rect
              [attr.x]="shape.x"
              [attr.y]="shape.y"
              [attr.width]="shape.width"
              [attr.height]="shape.height"
              [attr.rx]="shape.rx ?? null"
            />
          }
        }
      }
    </svg>
  `, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdIcon, decorators: [{
            type: Component,
            args: [{
                    selector: 'crsd-icon',
                    standalone: true,
                    template: `
    <svg
      [class]="svgClasses()"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      [attr.stroke-width]="strokeWidth()"
      stroke-linecap="round"
      stroke-linejoin="round"
      [attr.aria-hidden]="label() ? null : 'true'"
      [attr.role]="label() ? 'img' : null"
      [attr.aria-label]="label() || null"
    >
      @for (shape of shapes(); track $index) {
        @switch (shape.type) {
          @case ('path') {
            <path [attr.d]="shape.d" />
          }
          @case ('circle') {
            <circle [attr.cx]="shape.cx" [attr.cy]="shape.cy" [attr.r]="shape.r" />
          }
          @case ('line') {
            <line [attr.x1]="shape.x1" [attr.y1]="shape.y1" [attr.x2]="shape.x2" [attr.y2]="shape.y2" />
          }
          @case ('polyline') {
            <polyline [attr.points]="shape.points" />
          }
          @case ('rect') {
            <rect
              [attr.x]="shape.x"
              [attr.y]="shape.y"
              [attr.width]="shape.width"
              [attr.height]="shape.height"
              [attr.rx]="shape.rx ?? null"
            />
          }
        }
      }
    </svg>
  `,
                }]
        }], propDecorators: { name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: true }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], strokeWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "strokeWidth", required: false }] }], spin: [{ type: i0.Input, args: [{ isSignal: true, alias: "spin", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });

function combineDescribedBy(...ids) {
    const unique = [...new Set(ids.filter((id) => !!id))];
    return unique.length > 0 ? unique.join(' ') : null;
}

class CrsdFieldContext {
    controlId = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []));
    invalid = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "invalid" }] : /* istanbul ignore next */ []));
    errorIds = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorIds" }] : /* istanbul ignore next */ []));
    descriptionIds = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "descriptionIds" }] : /* istanbul ignore next */ []));
    setControlId(id) {
        if (!this.controlId()) {
            this.controlId.set(id);
        }
    }
    registerDescription(id) {
        this.descriptionIds.update((ids) => (ids.includes(id) ? ids : [...ids, id]));
    }
    unregisterDescription(id) {
        this.descriptionIds.update((ids) => ids.filter((value) => value !== id));
    }
    registerError(id) {
        this.errorIds.update((ids) => (ids.includes(id) ? ids : [...ids, id]));
        this.invalid.set(true);
    }
    unregisterError(id) {
        this.errorIds.update((ids) => ids.filter((value) => value !== id));
        this.invalid.set(this.errorIds().length > 0);
    }
    describedBy() {
        return combineDescribedBy(...this.descriptionIds(), ...this.errorIds());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdFieldContext, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdFieldContext });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdFieldContext, decorators: [{
            type: Injectable
        }] });

const INPUT_BASE = 'flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50';

class CrsdInput {
    staticClass;
    value = model('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    invalid = input(false, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    fieldContext = inject(CrsdFieldContext, { optional: true });
    validFlash = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "validFlash" }] : /* istanbul ignore next */ []));
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    controlId = computed(() => this.fieldContext?.controlId() ?? null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []));
    describedBy = computed(() => this.fieldContext?.describedBy() ?? null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []));
    isInvalid = computed(() => this.invalid() || (this.fieldContext?.invalid() ?? false), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isInvalid" }] : /* istanbul ignore next */ []));
    get hostClasses() {
        return cn(INPUT_BASE, {
            'border-destructive focus-visible:ring-destructive': this.isInvalid(),
            'crsd-input-invalid': this.isInvalid(),
            'crsd-input-valid-flash': this.validFlash(),
        }, this.staticClass, this.userClass());
    }
    get hostValue() {
        return this.value();
    }
    onInput(event) {
        const target = event.target;
        this.value.set(target.value);
    }
    onBlur() {
        if (this.isInvalid() || !this.value().trim()) {
            return;
        }
        this.validFlash.set(true);
        setTimeout(() => this.validFlash.set(false), 600);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdInput, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdInput, isStandalone: true, selector: "[crsdInput]", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { listeners: { "input": "onInput($event)", "blur": "onBlur()" }, properties: { "attr.aria-invalid": "isInvalid() ? \"true\" : null", "attr.aria-disabled": "disabled() ? \"true\" : null", "attr.disabled": "disabled() ? true : null", "attr.readonly": "readonly() ? true : null", "attr.id": "controlId()", "attr.aria-describedby": "describedBy()", "class": "this.hostClasses", "value": "this.hostValue" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdInput, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdInput]',
                    standalone: true,
                    host: {
                        '[attr.aria-invalid]': 'isInvalid() ? "true" : null',
                        '[attr.aria-disabled]': 'disabled() ? "true" : null',
                        '[attr.disabled]': 'disabled() ? true : null',
                        '[attr.readonly]': 'readonly() ? true : null',
                        '[attr.id]': 'controlId()',
                        '[attr.aria-describedby]': 'describedBy()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }], hostValue: [{
                type: HostBinding,
                args: ['value']
            }], onInput: [{
                type: HostListener,
                args: ['input', ['$event']]
            }], onBlur: [{
                type: HostListener,
                args: ['blur']
            }] } });

/** Multiline control styling aligned with {@link INPUT_BASE}. */
const TEXTAREA_BASE = INPUT_BASE.replace('h-10', 'min-h-28 h-auto resize-y');

class CrsdTextarea {
    staticClass;
    value = model('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    invalid = input(false, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    fieldContext = inject(CrsdFieldContext, { optional: true });
    validFlash = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "validFlash" }] : /* istanbul ignore next */ []));
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    controlId = computed(() => this.fieldContext?.controlId() ?? null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "controlId" }] : /* istanbul ignore next */ []));
    describedBy = computed(() => this.fieldContext?.describedBy() ?? null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "describedBy" }] : /* istanbul ignore next */ []));
    isInvalid = computed(() => this.invalid() || (this.fieldContext?.invalid() ?? false), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isInvalid" }] : /* istanbul ignore next */ []));
    get hostClasses() {
        return cn(TEXTAREA_BASE, {
            'border-destructive focus-visible:ring-destructive': this.isInvalid(),
            'crsd-input-invalid': this.isInvalid(),
            'crsd-input-valid-flash': this.validFlash(),
        }, this.staticClass, this.userClass());
    }
    get hostValue() {
        return this.value();
    }
    onInput(event) {
        const target = event.target;
        this.value.set(target.value);
    }
    onBlur() {
        if (this.isInvalid() || !this.value().trim()) {
            return;
        }
        this.validFlash.set(true);
        setTimeout(() => this.validFlash.set(false), 600);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdTextarea, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdTextarea, isStandalone: true, selector: "[crsdTextarea]", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { listeners: { "input": "onInput($event)", "blur": "onBlur()" }, properties: { "attr.aria-invalid": "isInvalid() ? \"true\" : null", "attr.aria-disabled": "disabled() ? \"true\" : null", "attr.disabled": "disabled() ? true : null", "attr.readonly": "readonly() ? true : null", "attr.id": "controlId()", "attr.aria-describedby": "describedBy()", "class": "this.hostClasses", "value": "this.hostValue" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdTextarea, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdTextarea]',
                    standalone: true,
                    host: {
                        '[attr.aria-invalid]': 'isInvalid() ? "true" : null',
                        '[attr.aria-disabled]': 'disabled() ? "true" : null',
                        '[attr.disabled]': 'disabled() ? true : null',
                        '[attr.readonly]': 'readonly() ? true : null',
                        '[attr.id]': 'controlId()',
                        '[attr.aria-describedby]': 'describedBy()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }], hostValue: [{
                type: HostBinding,
                args: ['value']
            }], onInput: [{
                type: HostListener,
                args: ['input', ['$event']]
            }], onBlur: [{
                type: HostListener,
                args: ['blur']
            }] } });

const SWITCH_TRACK_BASE = 'relative shrink-0 cursor-pointer rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50';
const SWITCH_TRACK_SIZES = {
    sm: 'h-5 w-9',
    md: 'h-6 w-11',
    lg: 'h-8 w-14',
};
const SWITCH_ICON_TRACK_SIZES = {
    sm: 'h-7 w-14 p-0.5 grid grid-cols-2',
    md: 'h-8 w-16 p-0.5 grid grid-cols-2',
    lg: 'h-10 w-20 p-0.5 grid grid-cols-2',
};
const SWITCH_TRACK_CHECKED = 'bg-primary';
const SWITCH_TRACK_UNCHECKED = 'bg-input';
const SWITCH_DEFAULT_TRACK = 'inline-flex border-0 p-0.5';
const SWITCH_ICON_TRACK = 'inline-grid border-0 bg-muted';
/** Tailwind v4 uses the `translate` property — not `transform` — for translate utilities. */
const SWITCH_DEFAULT_TRACK_TRANSITION = 'transition-colors duration-700 ease-in-out motion-reduce:transition-none';
const SWITCH_DEFAULT_THUMB_BASE = 'pointer-events-none absolute top-1/2 left-0.5 aspect-square h-[calc(100%-0.25rem)] -translate-y-1/2 rounded-full bg-background shadow-sm transition-[translate,box-shadow] duration-700 ease-[cubic-bezier(0.4,0,0.2,1)] motion-reduce:transition-none';
const SWITCH_DEFAULT_THUMB_OFFSET = {
    sm: { off: 'translate-x-0', on: 'translate-x-4' },
    md: { off: 'translate-x-0', on: 'translate-x-5' },
    lg: { off: 'translate-x-0', on: 'translate-x-6' },
};
const SWITCH_DEFAULT_THUMB_CHECKED = 'shadow-md';
const SWITCH_DEFAULT_THUMB_UNCHECKED = 'shadow-sm';
const SWITCH_ICON_THUMB_BASE = 'pointer-events-none absolute top-1/2 z-10 flex aspect-square h-[calc(100%-0.25rem)] -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-background shadow-sm transition-[left,box-shadow] duration-200 ease-in-out motion-reduce:transition-none';
const SWITCH_ICON_THUMB_POSITION = {
    on: 'left-1/4',
    off: 'left-3/4',
};
const SWITCH_ICON_SIZES = {
    sm: 'xs',
    md: 'xs',
    lg: 'sm',
};
const SWITCH_ICON_SLOT_BASE = 'flex items-center justify-center';
const SWITCH_ICON_INACTIVE = 'text-muted-foreground/70';

class CrsdSwitch {
    checked = input(false, { ...(ngDevMode ? { debugName: "checked" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    variant = input('default', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    ariaLabel = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    offLabel = input('Off', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "offLabel" }] : /* istanbul ignore next */ []));
    onLabel = input('On', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "onLabel" }] : /* istanbul ignore next */ []));
    checkedIcon = input('moon', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "checkedIcon" }] : /* istanbul ignore next */ []));
    uncheckedIcon = input('sun', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "uncheckedIcon" }] : /* istanbul ignore next */ []));
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    checkedChange = output();
    iconSize = computed(() => SWITCH_ICON_SIZES[this.size()], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "iconSize" }] : /* istanbul ignore next */ []));
    activeIcon = computed(() => this.checked() ? this.checkedIcon() : this.uncheckedIcon(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeIcon" }] : /* istanbul ignore next */ []));
    trackClasses = computed(() => cn(SWITCH_TRACK_BASE, this.isIconVariant()
        ? cn(SWITCH_ICON_TRACK, SWITCH_ICON_TRACK_SIZES[this.size()])
        : cn(SWITCH_DEFAULT_TRACK, SWITCH_DEFAULT_TRACK_TRANSITION, SWITCH_TRACK_SIZES[this.size()], this.checked() ? SWITCH_TRACK_CHECKED : SWITCH_TRACK_UNCHECKED), this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trackClasses" }] : /* istanbul ignore next */ []));
    thumbClasses = computed(() => {
        const offset = this.checked() ? 'on' : 'off';
        const thumbShadow = this.checked()
            ? SWITCH_DEFAULT_THUMB_CHECKED
            : SWITCH_DEFAULT_THUMB_UNCHECKED;
        if (this.isIconVariant()) {
            return cn(SWITCH_ICON_THUMB_BASE, SWITCH_ICON_THUMB_POSITION[offset], thumbShadow);
        }
        return cn(SWITCH_DEFAULT_THUMB_BASE, SWITCH_DEFAULT_THUMB_OFFSET[this.size()][offset], thumbShadow);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "thumbClasses" }] : /* istanbul ignore next */ []));
    iconSlotClasses = computed(() => cn(SWITCH_ICON_SLOT_BASE, SWITCH_ICON_INACTIVE), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "iconSlotClasses" }] : /* istanbul ignore next */ []));
    toggle() {
        if (this.disabled()) {
            return;
        }
        this.checkedChange.emit(!this.checked());
    }
    isIconVariant() {
        return this.variant() === 'icon';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSwitch, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.2.3", type: CrsdSwitch, isStandalone: true, selector: "crsd-switch", inputs: { checked: { classPropertyName: "checked", publicName: "checked", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, offLabel: { classPropertyName: "offLabel", publicName: "offLabel", isSignal: true, isRequired: false, transformFunction: null }, onLabel: { classPropertyName: "onLabel", publicName: "onLabel", isSignal: true, isRequired: false, transformFunction: null }, checkedIcon: { classPropertyName: "checkedIcon", publicName: "checkedIcon", isSignal: true, isRequired: false, transformFunction: null }, uncheckedIcon: { classPropertyName: "uncheckedIcon", publicName: "uncheckedIcon", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { checkedChange: "checkedChange" }, ngImport: i0, template: `
    <button
      type="button"
      role="switch"
      [class]="trackClasses()"
      [attr.aria-checked]="checked()"
      [attr.aria-label]="ariaLabel() || null"
      [disabled]="disabled()"
      (click)="toggle()"
    >
      <span class="sr-only">{{ checked() ? onLabel() : offLabel() }}</span>

      @if (variant() === 'icon') {
        <span [class]="iconSlotClasses()" aria-hidden="true">
          @if (!checked()) {
            <crsd-icon [name]="checkedIcon()" [size]="iconSize()" />
          }
        </span>
        <span [class]="iconSlotClasses()" aria-hidden="true">
          @if (checked()) {
            <crsd-icon [name]="uncheckedIcon()" [size]="iconSize()" />
          }
        </span>

        <span [class]="thumbClasses()" aria-hidden="true">
          <crsd-icon [name]="activeIcon()" [size]="iconSize()" />
        </span>
      }       @else {
        <span [class]="thumbClasses()" aria-hidden="true"></span>
      }
    </button>
  `, isInline: true, dependencies: [{ kind: "component", type: CrsdIcon, selector: "crsd-icon", inputs: ["name", "size", "strokeWidth", "spin", "label", "class"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSwitch, decorators: [{
            type: Component,
            args: [{
                    selector: 'crsd-switch',
                    standalone: true,
                    imports: [CrsdIcon],
                    template: `
    <button
      type="button"
      role="switch"
      [class]="trackClasses()"
      [attr.aria-checked]="checked()"
      [attr.aria-label]="ariaLabel() || null"
      [disabled]="disabled()"
      (click)="toggle()"
    >
      <span class="sr-only">{{ checked() ? onLabel() : offLabel() }}</span>

      @if (variant() === 'icon') {
        <span [class]="iconSlotClasses()" aria-hidden="true">
          @if (!checked()) {
            <crsd-icon [name]="checkedIcon()" [size]="iconSize()" />
          }
        </span>
        <span [class]="iconSlotClasses()" aria-hidden="true">
          @if (checked()) {
            <crsd-icon [name]="uncheckedIcon()" [size]="iconSize()" />
          }
        </span>

        <span [class]="thumbClasses()" aria-hidden="true">
          <crsd-icon [name]="activeIcon()" [size]="iconSize()" />
        </span>
      }       @else {
        <span [class]="thumbClasses()" aria-hidden="true"></span>
      }
    </button>
  `,
                }]
        }], propDecorators: { checked: [{ type: i0.Input, args: [{ isSignal: true, alias: "checked", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], offLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "offLabel", required: false }] }], onLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "onLabel", required: false }] }], checkedIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "checkedIcon", required: false }] }], uncheckedIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "uncheckedIcon", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], checkedChange: [{ type: i0.Output, args: ["checkedChange"] }] } });

const CARD_BASE = 'rounded-lg border border-border bg-background text-foreground';
const CARD_VARIANTS = {
    default: '',
    elevated: 'shadow-md',
};
const CARD_HEADER = 'flex flex-col space-y-1.5 p-6';
const CARD_TITLE = 'text-2xl font-semibold leading-none tracking-tight';
const CARD_DESCRIPTION = 'text-sm text-muted-foreground';
const CARD_CONTENT = 'p-6 pt-0';
const CARD_FOOTER = 'flex items-center p-6 pt-0';

class CrsdCard {
    staticClass;
    variant = input('default', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    get hostClasses() {
        return cn(CARD_BASE, CARD_VARIANTS[this.variant()], this.staticClass, this.userClass());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdCard, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdCard, isStandalone: true, selector: "[crsdCard]", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "this.hostClasses" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdCard, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdCard]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });
class CrsdCardHeader {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    get hostClasses() {
        return cn(CARD_HEADER, this.staticClass, this.userClass());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdCardHeader, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdCardHeader, isStandalone: true, selector: "[crsdCardHeader]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "this.hostClasses" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdCardHeader, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdCardHeader]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });
class CrsdCardTitle {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    get hostClasses() {
        return cn(CARD_TITLE, this.staticClass, this.userClass());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdCardTitle, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdCardTitle, isStandalone: true, selector: "[crsdCardTitle]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "this.hostClasses" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdCardTitle, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdCardTitle]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });
class CrsdCardDescription {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    get hostClasses() {
        return cn(CARD_DESCRIPTION, this.staticClass, this.userClass());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdCardDescription, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdCardDescription, isStandalone: true, selector: "[crsdCardDescription]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "this.hostClasses" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdCardDescription, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdCardDescription]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });
class CrsdCardContent {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    get hostClasses() {
        return cn(CARD_CONTENT, this.staticClass, this.userClass());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdCardContent, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdCardContent, isStandalone: true, selector: "[crsdCardContent]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "this.hostClasses" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdCardContent, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdCardContent]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });
class CrsdCardFooter {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    get hostClasses() {
        return cn(CARD_FOOTER, this.staticClass, this.userClass());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdCardFooter, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdCardFooter, isStandalone: true, selector: "[crsdCardFooter]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "this.hostClasses" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdCardFooter, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdCardFooter]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });

function sortRows(rows, key, direction) {
    if (!key || !direction) {
        return [...rows];
    }
    const sorted = [...rows].sort((a, b) => {
        const left = a[key];
        const right = b[key];
        if (left == null && right == null)
            return 0;
        if (left == null)
            return 1;
        if (right == null)
            return -1;
        if (typeof left === 'number' && typeof right === 'number') {
            return left - right;
        }
        return String(left).localeCompare(String(right));
    });
    return direction === 'desc' ? sorted.reverse() : sorted;
}
function toggleSortDirection(current) {
    if (current === null)
        return 'asc';
    if (current === 'asc')
        return 'desc';
    return null;
}

const CURSED_SKELETON_LABELS = [
    'Null Priest',
    'Void Walker',
    'Glitch Entity',
    'Wrong One',
    '???',
];
function pickCursedSkeletonLabel() {
    return (CURSED_SKELETON_LABELS[Math.floor(Math.random() * CURSED_SKELETON_LABELS.length)] ??
        CURSED_SKELETON_LABELS[0]);
}

const BLESSED_SKELETON_LABELS = [
    'Awaiting light…',
    'Gathering grace…',
    'Almost radiant…',
    'Patience, pilgrim',
    'Loading warmth…',
];
class CrsdTable {
    data = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []));
    columns = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []));
    loading = input(false, { ...(ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    themeService = inject(CrsdThemeService);
    skeletonRows = [0, 1, 2];
    sortGlitchKey = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sortGlitchKey" }] : /* istanbul ignore next */ []));
    sortGlowKey = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sortGlowKey" }] : /* istanbul ignore next */ []));
    corruptedFlash = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "corruptedFlash" }] : /* istanbul ignore next */ []));
    corruptedRows = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "corruptedRows" }] : /* istanbul ignore next */ []));
    radianceReveal = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "radianceReveal" }] : /* istanbul ignore next */ []));
    glitchTimer = null;
    glowTimer = null;
    flashTimer = null;
    radianceTimer = null;
    wasLoading = false;
    get hostClasses() {
        return cn(this.userClass());
    }
    sortKey = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sortKey" }] : /* istanbul ignore next */ []));
    sortDirection = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sortDirection" }] : /* istanbul ignore next */ []));
    displayRows = computed(() => sortRows(this.data(), this.sortKey(), this.sortDirection()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "displayRows" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            const loading = this.loading();
            const rows = this.data();
            if (this.wasLoading && !loading && rows.length > 0 && this.themeService.isFeatureEnabled('table')) {
                if (this.themeService.isCursed()) {
                    this.triggerCorruptedFlash(rows);
                }
                else if (this.themeService.isBlessed()) {
                    this.triggerRadianceReveal();
                }
            }
            this.wasLoading = loading;
        });
    }
    onSort(column) {
        if (!column.sortable) {
            return;
        }
        if (this.themeService.isFeatureEnabled('table') && this.themeService.isCursed()) {
            this.sortGlitchKey.set(column.key);
            if (this.glitchTimer) {
                clearTimeout(this.glitchTimer);
            }
            this.glitchTimer = setTimeout(() => this.sortGlitchKey.set(null), 220);
        }
        if (this.themeService.isFeatureEnabled('table') && this.themeService.isBlessed()) {
            this.sortGlowKey.set(column.key);
            if (this.glowTimer) {
                clearTimeout(this.glowTimer);
            }
            this.glowTimer = setTimeout(() => this.sortGlowKey.set(null), 350);
        }
        if (this.sortKey() !== column.key) {
            this.sortKey.set(column.key);
            this.sortDirection.set('asc');
            return;
        }
        const nextDirection = toggleSortDirection(this.sortDirection());
        this.sortDirection.set(nextDirection);
        if (nextDirection === null) {
            this.sortKey.set(null);
        }
    }
    skeletonLabel(rowIndex, key) {
        return CURSED_SKELETON_LABELS[(rowIndex + key.length) % CURSED_SKELETON_LABELS.length] ?? '???';
    }
    skeletonLabelBlessed(rowIndex, key) {
        return BLESSED_SKELETON_LABELS[(rowIndex + key.length) % BLESSED_SKELETON_LABELS.length] ?? '…';
    }
    ariaSort(key) {
        if (this.sortKey() !== key || !this.sortDirection()) {
            return 'none';
        }
        return this.sortDirection() === 'asc' ? 'ascending' : 'descending';
    }
    showSortIcon(key) {
        return this.sortKey() === key && this.sortDirection() !== null;
    }
    sortIconName(key) {
        const ascending = this.sortDirection() === 'asc';
        if (this.sortGlitchKey() === key) {
            return ascending ? 'chevron-down' : 'chevron-up';
        }
        return ascending ? 'chevron-up' : 'chevron-down';
    }
    trackRow(index, row) {
        return row['id'] ?? index;
    }
    triggerCorruptedFlash(rows) {
        const keys = this.columns().map((column) => column.key);
        const corrupted = rows.map((row, index) => {
            const clone = { ...row };
            const firstKey = keys[0];
            if (firstKey) {
                clone[firstKey] = CURSED_SKELETON_LABELS[index % CURSED_SKELETON_LABELS.length];
            }
            return clone;
        });
        this.corruptedRows.set(corrupted);
        this.corruptedFlash.set(true);
        if (this.flashTimer) {
            clearTimeout(this.flashTimer);
        }
        this.flashTimer = setTimeout(() => {
            this.corruptedFlash.set(false);
            this.corruptedRows.set([]);
            this.flashTimer = null;
        }, 180);
    }
    triggerRadianceReveal() {
        this.radianceReveal.set(true);
        if (this.radianceTimer) {
            clearTimeout(this.radianceTimer);
        }
        this.radianceTimer = setTimeout(() => {
            this.radianceReveal.set(false);
            this.radianceTimer = null;
        }, 550);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdTable, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.2.3", type: CrsdTable, isStandalone: true, selector: "crsd-table", inputs: { data: { classPropertyName: "data", publicName: "data", isSignal: true, isRequired: false, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "this.hostClasses" } }, ngImport: i0, template: `
    <div class="w-full overflow-auto rounded-md border border-border">
      <table class="w-full caption-bottom text-sm" role="table">
        <thead class="border-b border-border bg-muted/50">
          <tr class="border-b border-border">
            @for (column of columns(); track column.key) {
              <th
                class="h-12 px-4 text-left align-middle font-medium text-muted-foreground"
                [class.cursor-pointer]="column.sortable"
                [class.select-none]="column.sortable"
                [attr.aria-sort]="ariaSort(column.key)"
                (click)="onSort(column)"
              >
                <span
                  class="inline-flex items-center gap-1"
                  [class.crsd-table-sort-glitch]="sortGlitchKey() === column.key"
                  [class.crsd-table-sort-glow]="sortGlowKey() === column.key"
                >
                  {{ column.header }}
                  @if (column.sortable && showSortIcon(column.key)) {
                    <crsd-icon [name]="sortIconName(column.key)" size="xs" />
                  }
                </span>
              </th>
            }
          </tr>
        </thead>
        <tbody>
          @if (loading()) {
            @for (rowIndex of skeletonRows; track rowIndex) {
              <tr class="crsd-table-skeleton-row">
                @for (column of columns(); track column.key) {
                  <td class="p-4 align-middle">
                    <span
                      class="crsd-skeleton-bar"
                      [class.crsd-skeleton-corrupted]="themeService.isFeatureEnabled('table') && themeService.isCursed()"
                      [class.crsd-skeleton-blessed]="themeService.isFeatureEnabled('table') && themeService.isBlessed()"
                    >
                      @if (themeService.isFeatureEnabled('table') && themeService.isCursed()) {
                        {{ skeletonLabel(rowIndex, column.key) }}
                      } @else if (themeService.isFeatureEnabled('table') && themeService.isBlessed()) {
                        {{ skeletonLabelBlessed(rowIndex, column.key) }}
                      }
                    </span>
                  </td>
                }
              </tr>
            }
          } @else if (corruptedFlash()) {
            @for (row of corruptedRows(); track $index) {
              <tr class="crsd-table-row crsd-table-corrupted-flash border-b border-border">
                @for (column of columns(); track column.key) {
                  <td class="p-4 align-middle">{{ row[column.key] }}</td>
                }
              </tr>
            }
          } @else {
            @for (row of displayRows(); track trackRow($index, row)) {
              <tr
                class="crsd-table-row border-b border-border transition-colors hover:bg-muted/50"
                [class.crsd-table-radiance-reveal]="radianceReveal()"
              >
                @for (column of columns(); track column.key) {
                  <td class="p-4 align-middle">{{ row[column.key] }}</td>
                }
              </tr>
            } @empty {
              <tr>
                <td class="p-4 text-muted-foreground" [attr.colspan]="columns().length">
                  No results.
                </td>
              </tr>
            }
          }
        </tbody>
      </table>
    </div>
  `, isInline: true, dependencies: [{ kind: "component", type: CrsdIcon, selector: "crsd-icon", inputs: ["name", "size", "strokeWidth", "spin", "label", "class"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdTable, decorators: [{
            type: Component,
            args: [{
                    selector: 'crsd-table',
                    standalone: true,
                    imports: [CrsdIcon],
                    template: `
    <div class="w-full overflow-auto rounded-md border border-border">
      <table class="w-full caption-bottom text-sm" role="table">
        <thead class="border-b border-border bg-muted/50">
          <tr class="border-b border-border">
            @for (column of columns(); track column.key) {
              <th
                class="h-12 px-4 text-left align-middle font-medium text-muted-foreground"
                [class.cursor-pointer]="column.sortable"
                [class.select-none]="column.sortable"
                [attr.aria-sort]="ariaSort(column.key)"
                (click)="onSort(column)"
              >
                <span
                  class="inline-flex items-center gap-1"
                  [class.crsd-table-sort-glitch]="sortGlitchKey() === column.key"
                  [class.crsd-table-sort-glow]="sortGlowKey() === column.key"
                >
                  {{ column.header }}
                  @if (column.sortable && showSortIcon(column.key)) {
                    <crsd-icon [name]="sortIconName(column.key)" size="xs" />
                  }
                </span>
              </th>
            }
          </tr>
        </thead>
        <tbody>
          @if (loading()) {
            @for (rowIndex of skeletonRows; track rowIndex) {
              <tr class="crsd-table-skeleton-row">
                @for (column of columns(); track column.key) {
                  <td class="p-4 align-middle">
                    <span
                      class="crsd-skeleton-bar"
                      [class.crsd-skeleton-corrupted]="themeService.isFeatureEnabled('table') && themeService.isCursed()"
                      [class.crsd-skeleton-blessed]="themeService.isFeatureEnabled('table') && themeService.isBlessed()"
                    >
                      @if (themeService.isFeatureEnabled('table') && themeService.isCursed()) {
                        {{ skeletonLabel(rowIndex, column.key) }}
                      } @else if (themeService.isFeatureEnabled('table') && themeService.isBlessed()) {
                        {{ skeletonLabelBlessed(rowIndex, column.key) }}
                      }
                    </span>
                  </td>
                }
              </tr>
            }
          } @else if (corruptedFlash()) {
            @for (row of corruptedRows(); track $index) {
              <tr class="crsd-table-row crsd-table-corrupted-flash border-b border-border">
                @for (column of columns(); track column.key) {
                  <td class="p-4 align-middle">{{ row[column.key] }}</td>
                }
              </tr>
            }
          } @else {
            @for (row of displayRows(); track trackRow($index, row)) {
              <tr
                class="crsd-table-row border-b border-border transition-colors hover:bg-muted/50"
                [class.crsd-table-radiance-reveal]="radianceReveal()"
              >
                @for (column of columns(); track column.key) {
                  <td class="p-4 align-middle">{{ row[column.key] }}</td>
                }
              </tr>
            } @empty {
              <tr>
                <td class="p-4 text-muted-foreground" [attr.colspan]="columns().length">
                  No results.
                </td>
              </tr>
            }
          }
        </tbody>
      </table>
    </div>
  `,
                }]
        }], ctorParameters: () => [], propDecorators: { data: [{ type: i0.Input, args: [{ isSignal: true, alias: "data", required: false }] }], columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });

const BADGE_BASE = 'inline-flex items-center rounded-md border px-2 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2';
const SOLID_CLASSES = {
    primary: 'border-transparent bg-primary text-primary-foreground',
    secondary: 'border-transparent bg-secondary text-secondary-foreground',
    success: 'border-transparent bg-success text-success-foreground',
    warning: 'border-transparent bg-warning text-warning-foreground',
    info: 'border-transparent bg-info text-info-foreground',
    destructive: 'border-transparent bg-destructive text-destructive-foreground',
};
const OUTLINE_CLASSES = {
    primary: 'border-primary text-primary',
    secondary: 'border-secondary text-secondary-foreground',
    success: 'border-success text-success',
    warning: 'border-warning text-warning',
    info: 'border-info text-info',
    destructive: 'border-destructive text-destructive',
};
const SOFT_CLASSES = {
    primary: 'border-transparent bg-primary/10 text-primary',
    secondary: 'border-transparent bg-secondary/50 text-secondary-foreground',
    success: 'border-transparent bg-success/10 text-success',
    warning: 'border-transparent bg-warning/10 text-warning',
    info: 'border-transparent bg-info/10 text-info',
    destructive: 'border-transparent bg-destructive/10 text-destructive',
};
const VARIANT_CLASSES = {
    solid: SOLID_CLASSES,
    outline: OUTLINE_CLASSES,
    soft: SOFT_CLASSES,
};
function badgeClasses(variant, color) {
    return VARIANT_CLASSES[variant][color];
}
const BADGE_SIZES = {
    sm: 'px-1.5 py-0 text-[10px]',
    md: 'px-2 py-0.5 text-xs',
};
/** Tighter chip layout when a dismiss control sits inside a badge. */
const REMOVABLE_BADGE_LAYOUT = 'gap-0 py-0 pl-1.5 pr-0';
/** Visual tuning for dismiss controls nested in badges (hit target stays icon-xs). */
const BADGE_DISMISS_BTN = 'rounded-sm opacity-60 ring-offset-0 hover:bg-current/10 hover:opacity-100';

class CrsdBadge {
    staticClass;
    variant = input('soft', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    color = input('primary', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []));
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(BADGE_BASE, badgeClasses(this.variant(), this.color()), BADGE_SIZES[this.size()], this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdBadge, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdBadge, isStandalone: true, selector: "[crsdBadge]", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, color: { classPropertyName: "color", publicName: "color", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdBadge, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdBadge]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], color: [{ type: i0.Input, args: [{ isSignal: true, alias: "color", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

class CrsdBadgeDismiss {
    removeLabel = input('Remove', { ...(ngDevMode ? { debugName: "removeLabel" } : /* istanbul ignore next */ {}), alias: 'removeLabel' });
    variant = input('ghost', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    color = input('inherit', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []));
    size = input('icon-xs', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    dismiss = output();
    hostClasses = computed(() => {
        const size = this.size();
        return cn(BUTTON_BASE, isIconBtnSize(size) && BUTTON_ICON_TYPO, buttonClasses(this.variant(), this.color()), BUTTON_SIZES[size], BADGE_DISMISS_BTN, {
            'pointer-events-none opacity-40': this.disabled(),
        });
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    iconSize() {
        return this.size() === 'icon-sm' ? 'sm' : 'xs';
    }
    onClick(event) {
        event.preventDefault();
        event.stopPropagation();
        if (this.disabled()) {
            return;
        }
        this.dismiss.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdBadgeDismiss, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.2.3", type: CrsdBadgeDismiss, isStandalone: true, selector: "button[crsdBadgeDismiss]", inputs: { removeLabel: { classPropertyName: "removeLabel", publicName: "removeLabel", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, color: { classPropertyName: "color", publicName: "color", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { dismiss: "dismiss" }, host: { attributes: { "role": "button", "type": "button" }, listeners: { "click": "onClick($event)" }, properties: { "class": "hostClasses()", "attr.disabled": "disabled() ? true : null", "attr.aria-disabled": "disabled() ? \"true\" : null", "attr.aria-label": "removeLabel()" } }, ngImport: i0, template: `<crsd-icon name="x" [size]="iconSize()" />`, isInline: true, dependencies: [{ kind: "component", type: CrsdIcon, selector: "crsd-icon", inputs: ["name", "size", "strokeWidth", "spin", "label", "class"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdBadgeDismiss, decorators: [{
            type: Component,
            args: [{
                    selector: 'button[crsdBadgeDismiss]',
                    standalone: true,
                    imports: [CrsdIcon],
                    host: {
                        role: 'button',
                        type: 'button',
                        '[class]': 'hostClasses()',
                        '[attr.disabled]': 'disabled() ? true : null',
                        '[attr.aria-disabled]': 'disabled() ? "true" : null',
                        '[attr.aria-label]': 'removeLabel()',
                    },
                    template: `<crsd-icon name="x" [size]="iconSize()" />`,
                }]
        }], propDecorators: { removeLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "removeLabel", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], color: [{ type: i0.Input, args: [{ isSignal: true, alias: "color", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], dismiss: [{ type: i0.Output, args: ["dismiss"] }], onClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

class CrsdRemovableBadge {
    REMOVABLE_BADGE_LAYOUT = REMOVABLE_BADGE_LAYOUT;
    variant = input('soft', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    color = input('primary', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "color" }] : /* istanbul ignore next */ []));
    size = input('sm', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    removeLabel = input('Remove', { ...(ngDevMode ? { debugName: "removeLabel" } : /* istanbul ignore next */ {}), alias: 'removeLabel' });
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    dismiss = output();
    onDismiss() {
        if (this.disabled()) {
            return;
        }
        this.dismiss.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdRemovableBadge, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.2.3", type: CrsdRemovableBadge, isStandalone: true, selector: "crsd-removable-badge", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, color: { classPropertyName: "color", publicName: "color", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, removeLabel: { classPropertyName: "removeLabel", publicName: "removeLabel", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { dismiss: "dismiss" }, ngImport: i0, template: `
    <span
      crsdBadge
      [variant]="variant()"
      [color]="color()"
      [size]="size()"
      [class]="REMOVABLE_BADGE_LAYOUT"
    >
      <ng-content />
      <button
        crsdBadgeDismiss
        [removeLabel]="removeLabel()"
        [disabled]="disabled()"
        (dismiss)="onDismiss()"
      ></button>
    </span>
  `, isInline: true, dependencies: [{ kind: "directive", type: CrsdBadge, selector: "[crsdBadge]", inputs: ["variant", "color", "size", "class"] }, { kind: "component", type: CrsdBadgeDismiss, selector: "button[crsdBadgeDismiss]", inputs: ["removeLabel", "variant", "color", "size", "disabled"], outputs: ["dismiss"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdRemovableBadge, decorators: [{
            type: Component,
            args: [{
                    selector: 'crsd-removable-badge',
                    standalone: true,
                    imports: [CrsdBadge, CrsdBadgeDismiss],
                    template: `
    <span
      crsdBadge
      [variant]="variant()"
      [color]="color()"
      [size]="size()"
      [class]="REMOVABLE_BADGE_LAYOUT"
    >
      <ng-content />
      <button
        crsdBadgeDismiss
        [removeLabel]="removeLabel()"
        [disabled]="disabled()"
        (dismiss)="onDismiss()"
      ></button>
    </span>
  `,
                }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], color: [{ type: i0.Input, args: [{ isSignal: true, alias: "color", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], removeLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "removeLabel", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], dismiss: [{ type: i0.Output, args: ["dismiss"] }] } });

const SPINNER_BASE = 'animate-spin text-primary';
const SPINNER_SIZES = {
    sm: 'size-4',
    md: 'size-6',
    lg: 'size-8',
};
const SPINNER_STROKE = {
    sm: 2,
    md: 2,
    lg: 2.5,
};

class CrsdSpinner {
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    strokeWidth = computed(() => SPINNER_STROKE[this.size()], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "strokeWidth" }] : /* istanbul ignore next */ []));
    hostClasses = computed(() => cn('inline-flex', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    svgClasses = computed(() => cn(SPINNER_BASE, SPINNER_SIZES[this.size()]), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "svgClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSpinner, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSpinner, isStandalone: true, selector: "crsd-spinner", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "status" }, properties: { "attr.aria-busy": "true", "attr.aria-label": "label() || \"Loading\"", "class": "hostClasses()" } }, ngImport: i0, template: `
    <svg
      class="crsd-spinner-graphic"
      [class]="svgClasses()"
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      aria-hidden="true"
    >
      <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" [attr.stroke-width]="strokeWidth()" />
      <path
        class="opacity-75"
        fill="currentColor"
        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
      />
    </svg>
  `, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSpinner, decorators: [{
            type: Component,
            args: [{
                    selector: 'crsd-spinner',
                    standalone: true,
                    host: {
                        role: 'status',
                        '[attr.aria-busy]': 'true',
                        '[attr.aria-label]': 'label() || "Loading"',
                        '[class]': 'hostClasses()',
                    },
                    template: `
    <svg
      class="crsd-spinner-graphic"
      [class]="svgClasses()"
      xmlns="http://www.w3.org/2000/svg"
      fill="none"
      viewBox="0 0 24 24"
      aria-hidden="true"
    >
      <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" [attr.stroke-width]="strokeWidth()" />
      <path
        class="opacity-75"
        fill="currentColor"
        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
      />
    </svg>
  `,
                }]
        }], propDecorators: { size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

const LABEL_BASE = 'text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70';

class CrsdLabel {
    staticClass;
    for = input('', { ...(ngDevMode ? { debugName: "for" } : /* istanbul ignore next */ {}), alias: 'for' });
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(LABEL_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdLabel, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdLabel, isStandalone: true, selector: "[crsdLabel]", inputs: { for: { classPropertyName: "for", publicName: "for", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()", "attr.for": "for() || null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdLabel, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdLabel]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                        '[attr.for]': 'for() || null',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { for: [{ type: i0.Input, args: [{ isSignal: true, alias: "for", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

let nextId = 0;
class CrsdIdService {
    generate(prefix = 'crsd') {
        nextId += 1;
        return `${prefix}-${nextId}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdIdService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdIdService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdIdService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const FIELD_BASE = 'space-y-2';
const FIELD_ERROR_BASE = 'text-sm font-medium text-destructive';
const FIELD_DESCRIPTION_BASE = 'text-sm text-muted-foreground';

class CrsdField {
    staticClass;
    invalid = input(false, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    fieldContext = inject(CrsdFieldContext);
    idService = inject(CrsdIdService);
    isInvalid = computed(() => this.invalid() || this.fieldContext.errorIds().length > 0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isInvalid" }] : /* istanbul ignore next */ []));
    constructor(staticClass) {
        this.staticClass = staticClass;
        effect(() => {
            this.fieldContext.invalid.set(this.isInvalid());
        });
    }
    ngOnInit() {
        this.fieldContext.setControlId(this.idService.generate('crsd-field'));
    }
    hostClasses = computed(() => cn(FIELD_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    get context() {
        return this.fieldContext;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdField, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdField, isStandalone: true, selector: "[crsdField]", inputs: { invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()", "class.crsd-field-invalid": "isInvalid()" } }, providers: [CrsdFieldContext], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdField, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdField]',
                    standalone: true,
                    providers: [CrsdFieldContext],
                    host: {
                        '[class]': 'hostClasses()',
                        '[class.crsd-field-invalid]': 'isInvalid()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdFieldDescription {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    fieldContext = inject(CrsdFieldContext, { optional: true });
    idService = inject(CrsdIdService);
    _elementId = this.idService.generate('crsd-field-desc');
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    elementId = computed(() => this._elementId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "elementId" }] : /* istanbul ignore next */ []));
    hostClasses = computed(() => cn(FIELD_DESCRIPTION_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    ngOnInit() {
        this.fieldContext?.registerDescription(this._elementId);
    }
    ngOnDestroy() {
        this.fieldContext?.unregisterDescription(this._elementId);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdFieldDescription, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdFieldDescription, isStandalone: true, selector: "[crsdFieldDescription]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()", "attr.id": "elementId()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdFieldDescription, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdFieldDescription]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                        '[attr.id]': 'elementId()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdFieldError {
    staticClass;
    validator = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "validator" }] : /* istanbul ignore next */ []));
    show = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "show" }] : /* istanbul ignore next */ []));
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    fieldContext = inject(CrsdFieldContext, { optional: true });
    idService = inject(CrsdIdService);
    _elementId = this.idService.generate('crsd-field-error');
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    elementId = computed(() => this._elementId, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "elementId" }] : /* istanbul ignore next */ []));
    visible = computed(() => {
        if (this.show() !== null) {
            return this.show();
        }
        return true;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    hostClasses = computed(() => cn(FIELD_ERROR_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    ngOnInit() {
        if (this.visible()) {
            this.fieldContext?.registerError(this._elementId);
        }
    }
    ngOnDestroy() {
        this.fieldContext?.unregisterError(this._elementId);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdFieldError, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdFieldError, isStandalone: true, selector: "[crsdFieldError]", inputs: { validator: { classPropertyName: "validator", publicName: "validator", isSignal: true, isRequired: false, transformFunction: null }, show: { classPropertyName: "show", publicName: "show", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "alert" }, properties: { "class": "hostClasses()", "attr.id": "elementId()", "attr.aria-live": "\"polite\"", "hidden": "!visible()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdFieldError, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdFieldError]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                        '[attr.id]': 'elementId()',
                        role: 'alert',
                        '[attr.aria-live]': '"polite"',
                        '[hidden]': '!visible()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { validator: [{ type: i0.Input, args: [{ isSignal: true, alias: "validator", required: false }] }], show: [{ type: i0.Input, args: [{ isSignal: true, alias: "show", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

const ALERT_BASE = 'relative w-full rounded-lg border p-4 text-sm';
const ALERT_VARIANTS = {
    default: 'border-border bg-background text-foreground',
    success: 'border-success/50 bg-success/10 text-success',
    error: 'border-destructive/50 bg-destructive/10 text-destructive',
    warning: 'border-warning/50 bg-warning/10 text-warning',
    info: 'border-info/50 bg-info/10 text-info',
};
const ALERT_TITLE_BASE = 'mb-1 font-medium leading-none tracking-tight';
const ALERT_DESCRIPTION_BASE = 'text-sm leading-relaxed';

function alertRole(variant) {
    return variant === 'error' || variant === 'warning' ? 'alert' : 'status';
}
function alertLive(variant) {
    return variant === 'error' ? 'assertive' : 'polite';
}
class CrsdAlert {
    staticClass;
    variant = input('default', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(ALERT_BASE, ALERT_VARIANTS[this.variant()], this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    hostRole = computed(() => alertRole(this.variant()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostRole" }] : /* istanbul ignore next */ []));
    hostLive = computed(() => alertLive(this.variant()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostLive" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdAlert, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdAlert, isStandalone: true, selector: "[crsdAlert]", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()", "attr.role": "hostRole()", "attr.aria-live": "hostLive()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdAlert, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdAlert]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                        '[attr.role]': 'hostRole()',
                        '[attr.aria-live]': 'hostLive()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdAlertTitle {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(ALERT_TITLE_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdAlertTitle, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdAlertTitle, isStandalone: true, selector: "[crsdAlertTitle]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdAlertTitle, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdAlertTitle]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdAlertDescription {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(ALERT_DESCRIPTION_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdAlertDescription, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdAlertDescription, isStandalone: true, selector: "[crsdAlertDescription]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdAlertDescription, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdAlertDescription]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

class CrsdOverlayRef {
    overlayRef;
    destroyRef;
    options;
    escapeSub = null;
    backdropSub = null;
    disposed = false;
    constructor(overlayRef, destroyRef, options = {}) {
        this.overlayRef = overlayRef;
        this.destroyRef = destroyRef;
        this.options = options;
        if (options.closeOnEscape !== false) {
            this.escapeSub = fromEvent(document, 'keydown')
                .pipe(filter((event) => event.key === 'Escape'), takeUntilDestroyed(this.destroyRef))
                .subscribe(() => this.close());
        }
        if (options.closeOnBackdropClick !== false && options.hasBackdrop) {
            this.backdropSub = this.overlayRef
                .backdropClick()
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe(() => this.close());
        }
    }
    attachPortal(portal) {
        const viewRef = this.overlayRef.attach(portal);
        viewRef.detectChanges();
        return viewRef;
    }
    attachDomElement(element) {
        // DomPortal requires the element to already be connected to the document.
        if (!element.isConnected) {
            document.body.appendChild(element);
        }
        this.overlayRef.attach(new DomPortal(element));
    }
    detach() {
        this.overlayRef.detach();
    }
    close() {
        if (this.disposed) {
            return;
        }
        this.disposed = true;
        this.options.onClose?.();
        this.overlayRef.dispose();
        this.escapeSub?.unsubscribe();
        this.backdropSub?.unsubscribe();
    }
    updatePosition() {
        this.overlayRef.updatePosition();
    }
    listenPointerDownOutside(origin, onDismiss) {
        return fromEvent(document, 'pointerdown', { capture: true })
            .pipe(filter((event) => {
            const target = event.target;
            const pane = this.overlayRef.overlayElement;
            return !origin.contains(target) && !pane.contains(target);
        }))
            .subscribe(onDismiss);
    }
    setConnectedWidth(width) {
        const pane = this.overlayRef.overlayElement;
        pane.style.width = `${width}px`;
        pane.style.minWidth = `${width}px`;
    }
    get overlayElement() {
        return this.overlayRef.overlayElement;
    }
}

function normalizePanelClass(panelClass) {
    if (!panelClass) {
        return panelClass;
    }
    if (Array.isArray(panelClass)) {
        return panelClass;
    }
    return panelClass.includes(' ') ? panelClass.split(/\s+/).filter(Boolean) : panelClass;
}
class CrsdOverlayService {
    overlay = inject(Overlay);
    createCentered(config = {}, options = {}, destroyRef) {
        const positionStrategy = this.overlay
            .position()
            .global()
            .centerHorizontally()
            .centerVertically();
        return this.create({ ...config, positionStrategy }, options, destroyRef);
    }
    createConnected(origin, positions, config = {}, options = {}, destroyRef) {
        const positionStrategy = this.overlay
            .position()
            .flexibleConnectedTo(origin)
            .withPositions(positions)
            .withFlexibleDimensions(false)
            .withPush(true)
            .withViewportMargin(8);
        return this.create({ ...config, positionStrategy }, options, destroyRef);
    }
    create(config, options = {}, destroyRef) {
        const scrollStrategy = config.scrollStrategy ??
            (options.scrollStrategy === 'noop'
                ? this.overlay.scrollStrategies.noop()
                : this.overlay.scrollStrategies.reposition());
        const overlayConfig = new OverlayConfig({
            positionStrategy: config.positionStrategy,
            hasBackdrop: config.hasBackdrop ?? options.hasBackdrop ?? false,
            backdropClass: config.backdropClass ?? 'cdk-overlay-dark-backdrop',
            panelClass: normalizePanelClass(config.panelClass),
            scrollStrategy,
            width: config.width,
            height: config.height,
            minWidth: config.minWidth,
            maxWidth: config.maxWidth,
            maxHeight: config.maxHeight,
        });
        const overlayRef = this.overlay.create(overlayConfig);
        if (!destroyRef) {
            throw new Error('CrsdOverlayService.create requires a DestroyRef from the calling component.');
        }
        return new CrsdOverlayRef(overlayRef, destroyRef, options);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdOverlayService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdOverlayService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdOverlayService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const CRSD_TOOLTIP_SIDES = {
    bottom: { originX: 'center', originY: 'bottom', overlayX: 'center', overlayY: 'top', offsetY: 4 },
    top: { originX: 'center', originY: 'top', overlayX: 'center', overlayY: 'bottom', offsetY: -4 },
    right: { originX: 'end', originY: 'center', overlayX: 'start', overlayY: 'center', offsetX: 4 },
    left: { originX: 'start', originY: 'center', overlayX: 'end', overlayY: 'center', offsetX: -4 },
};
const TOOLTIP_SIDE_ORDER = ['bottom', 'top', 'right', 'left'];
function tooltipPositions(preferred = 'bottom') {
    return [preferred, ...TOOLTIP_SIDE_ORDER.filter((side) => side !== preferred)].map((side) => CRSD_TOOLTIP_SIDES[side]);
}
const CRSD_CONNECTED_POSITIONS = tooltipPositions('bottom');
const CRSD_SHEET_POSITIONS = {
    right: [{ originX: 'end', originY: 'center', overlayX: 'end', overlayY: 'center' }],
    left: [{ originX: 'start', originY: 'center', overlayX: 'start', overlayY: 'center' }],
    top: [{ originX: 'center', originY: 'top', overlayX: 'center', overlayY: 'top' }],
    bottom: [{ originX: 'center', originY: 'bottom', overlayX: 'center', overlayY: 'bottom' }],
};

const TOOLTIP_CONTENT_BASE = 'z-tooltip rounded-md border border-border bg-popover px-3 py-1.5 text-sm text-popover-foreground shadow-md';
/** Inline styles for dynamically created tooltip nodes (Tailwind may not apply). */
function applyTooltipContentStyles(element) {
    Object.assign(element.style, {
        borderRadius: 'calc(var(--crsd-radius) - 2px)',
        border: '1px solid hsl(var(--crsd-border))',
        background: 'hsl(var(--crsd-popover))',
        color: 'hsl(var(--crsd-popover-foreground))',
        padding: '0.375rem 0.75rem',
        fontSize: '0.875rem',
        lineHeight: '1.25rem',
        boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
        pointerEvents: 'none',
        whiteSpace: 'nowrap',
        maxWidth: '20rem',
    });
}

class CrsdTooltipPortal {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdTooltipPortal, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdTooltipPortal, isStandalone: true, selector: "[crsdTooltipPortal]", host: { styleAttribute: "display: none" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdTooltipPortal, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdTooltipPortal]',
                    standalone: true,
                    host: {
                        style: 'display: none',
                    },
                }]
        }] });
class CrsdTooltip {
    attrTooltip;
    crsdTooltip = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "crsdTooltip" }] : /* istanbul ignore next */ []));
    side = input('bottom', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "side" }] : /* istanbul ignore next */ []));
    showDelay = input(300, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showDelay" }] : /* istanbul ignore next */ []));
    hideDelay = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hideDelay" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    portalTemplate = contentChild(CrsdTooltipPortal, { ...(ngDevMode ? { debugName: "portalTemplate" } : /* istanbul ignore next */ {}), read: TemplateRef });
    elementRef = inject((ElementRef));
    portalViewContainer = inject(ViewContainerRef, { skipSelf: true });
    overlayService = inject(CrsdOverlayService);
    idService = inject(CrsdIdService);
    destroyRef = inject(DestroyRef);
    applicationRef = inject(ApplicationRef);
    tooltipId = this.idService.generate('crsd-tooltip');
    isOpen = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isOpen" }] : /* istanbul ignore next */ []));
    overlayRef = null;
    constructor(attrTooltip) {
        this.attrTooltip = attrTooltip;
        const host = this.elementRef.nativeElement;
        const enter$ = fromEvent(host, 'mouseenter');
        const leave$ = fromEvent(host, 'mouseleave');
        const focusIn$ = fromEvent(host, 'focusin');
        const focusOut$ = fromEvent(host, 'focusout');
        enter$
            .pipe(filter$1(() => !this.disabled() && this.hasContent()), switchMap(() => timer(this.showDelay()).pipe(takeUntil(leave$))), takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.open());
        leave$
            .pipe(switchMap(() => timer(this.hideDelay()).pipe(takeUntil(enter$))), takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.close());
        focusIn$
            .pipe(filter$1(() => !this.disabled() && this.hasContent()), takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.open());
        focusOut$
            .pipe(switchMap(() => timer(this.hideDelay()).pipe(takeUntil(focusIn$))), takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.close());
        fromEvent(document, 'keydown')
            .pipe(filter$1((event) => event.key === 'Escape'), takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.close());
    }
    tooltipText() {
        return this.crsdTooltip() || this.attrTooltip || '';
    }
    hasContent() {
        return !!this.tooltipText() || !!this.portalTemplate();
    }
    open() {
        if (this.overlayRef || this.disabled() || !this.hasContent()) {
            return;
        }
        this.overlayRef = this.overlayService.createConnected(this.elementRef.nativeElement, tooltipPositions(this.side()), { panelClass: ['z-tooltip', 'pointer-events-none'], hasBackdrop: false }, { closeOnEscape: false, scrollStrategy: 'noop' }, this.destroyRef);
        this.overlayRef.overlayElement.style.pointerEvents = 'none';
        const portalTemplate = this.portalTemplate();
        if (portalTemplate) {
            this.overlayRef.attachPortal(new TemplatePortal(portalTemplate, this.portalViewContainer));
        }
        else {
            const el = document.createElement('div');
            el.id = this.tooltipId;
            el.setAttribute('role', 'tooltip');
            el.className = TOOLTIP_CONTENT_BASE;
            applyTooltipContentStyles(el);
            el.textContent = this.tooltipText();
            this.overlayRef.attachDomElement(el);
        }
        this.overlayRef.updatePosition();
        if (portalTemplate) {
            this.applicationRef.tick();
        }
        this.isOpen.set(true);
    }
    close() {
        this.overlayRef?.close();
        this.overlayRef = null;
        this.isOpen.set(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdTooltip, deps: [{ token: 'crsdTooltip', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "22.2.3", type: CrsdTooltip, isStandalone: true, selector: "[crsdTooltip]", inputs: { crsdTooltip: { classPropertyName: "crsdTooltip", publicName: "crsdTooltip", isSignal: true, isRequired: false, transformFunction: null }, side: { classPropertyName: "side", publicName: "side", isSignal: true, isRequired: false, transformFunction: null }, showDelay: { classPropertyName: "showDelay", publicName: "showDelay", isSignal: true, isRequired: false, transformFunction: null }, hideDelay: { classPropertyName: "hideDelay", publicName: "hideDelay", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.aria-describedby": "isOpen() ? tooltipId : null" } }, queries: [{ propertyName: "portalTemplate", first: true, predicate: CrsdTooltipPortal, descendants: true, read: TemplateRef, isSignal: true }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdTooltip, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdTooltip]',
                    standalone: true,
                    host: {
                        '[attr.aria-describedby]': 'isOpen() ? tooltipId : null',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['crsdTooltip']
                }] }], propDecorators: { crsdTooltip: [{ type: i0.Input, args: [{ isSignal: true, alias: "crsdTooltip", required: false }] }], side: [{ type: i0.Input, args: [{ isSignal: true, alias: "side", required: false }] }], showDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "showDelay", required: false }] }], hideDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideDelay", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], portalTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => CrsdTooltipPortal), { ...{ read: TemplateRef }, isSignal: true }] }] } });

class CrsdFocusTrap {
    crsdFocusTrap = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "crsdFocusTrap" }] : /* istanbul ignore next */ []));
    crsdFocusTrapAutoCapture = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "crsdFocusTrapAutoCapture" }] : /* istanbul ignore next */ []));
    trap = null;
    previousFocus = null;
    elementRef = inject((ElementRef));
    focusTrapFactory = inject(FocusTrapFactory);
    ngOnInit() {
        if (!this.crsdFocusTrap()) {
            return;
        }
        this.previousFocus = document.activeElement;
        this.trap = this.focusTrapFactory.create(this.elementRef.nativeElement);
        if (this.crsdFocusTrapAutoCapture()) {
            this.trap.focusInitialElementWhenReady();
        }
    }
    ngOnDestroy() {
        this.trap?.destroy();
        this.previousFocus?.focus?.();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdFocusTrap, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdFocusTrap, isStandalone: true, selector: "[crsdFocusTrap]", inputs: { crsdFocusTrap: { classPropertyName: "crsdFocusTrap", publicName: "crsdFocusTrap", isSignal: true, isRequired: false, transformFunction: null }, crsdFocusTrapAutoCapture: { classPropertyName: "crsdFocusTrapAutoCapture", publicName: "crsdFocusTrapAutoCapture", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdFocusTrap, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdFocusTrap]',
                    standalone: true,
                }]
        }], propDecorators: { crsdFocusTrap: [{ type: i0.Input, args: [{ isSignal: true, alias: "crsdFocusTrap", required: false }] }], crsdFocusTrapAutoCapture: [{ type: i0.Input, args: [{ isSignal: true, alias: "crsdFocusTrapAutoCapture", required: false }] }] } });

const DIALOG_CONTENT_BASE = 'fixed left-1/2 top-1/2 z-modal grid w-full max-w-lg -translate-x-1/2 -translate-y-1/2 gap-4 border border-border bg-background p-6 shadow-lg sm:rounded-lg';
const DIALOG_HEADER_BASE = 'flex flex-col space-y-1.5 text-center sm:text-left';
const DIALOG_FOOTER_BASE = 'flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2';
const DIALOG_TITLE_BASE = 'text-lg font-semibold leading-none tracking-tight';
const DIALOG_DESCRIPTION_BASE = 'text-sm text-muted-foreground';

class CrsdDialogPortal {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialogPortal, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdDialogPortal, isStandalone: true, selector: "[crsdDialogPortal]", host: { styleAttribute: "display: none" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialogPortal, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdDialogPortal]',
                    standalone: true,
                    host: {
                        style: 'display: none',
                    },
                }]
        }] });
class CrsdDialog {
    state = model('closed', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    stateChanged = output();
    closeOnBackdropClick = input(true, { ...(ngDevMode ? { debugName: "closeOnBackdropClick" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closeOnEscape = input(true, { ...(ngDevMode ? { debugName: "closeOnEscape" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    titleId = inject(CrsdIdService).generate('crsd-dialog-title');
    descriptionId = inject(CrsdIdService).generate('crsd-dialog-desc');
    portalTemplate = contentChild(CrsdDialogPortal, { ...(ngDevMode ? { debugName: "portalTemplate" } : /* istanbul ignore next */ {}), read: TemplateRef });
    overlayService = inject(CrsdOverlayService);
    viewContainer = inject(ViewContainerRef);
    destroyRef = inject(DestroyRef);
    overlayRef = null;
    triggerElement = null;
    constructor() {
        effect(() => {
            if (this.state() === 'open') {
                this.attachOverlay();
            }
            else {
                this.detachOverlay();
            }
        });
    }
    open(from) {
        this.triggerElement = from ?? document.activeElement;
        this.setState('open');
    }
    close() {
        if (this.state() === 'closed') {
            return;
        }
        this.setState('closed');
        this.triggerElement?.focus?.();
    }
    setState(next) {
        this.state.set(next);
        this.stateChanged.emit(next);
    }
    attachOverlay() {
        const template = this.portalTemplate();
        if (!template || this.overlayRef) {
            return;
        }
        this.overlayRef = this.overlayService.createCentered({
            hasBackdrop: true,
            panelClass: 'pointer-events-none',
        }, {
            hasBackdrop: true,
            closeOnBackdropClick: this.closeOnBackdropClick(),
            closeOnEscape: this.closeOnEscape(),
            onClose: () => {
                if (this.state() === 'open') {
                    this.setState('closed');
                    this.triggerElement?.focus?.();
                }
            },
        }, this.destroyRef);
        this.overlayRef.attachPortal(new TemplatePortal(template, this.viewContainer));
    }
    detachOverlay() {
        if (!this.overlayRef) {
            return;
        }
        const ref = this.overlayRef;
        this.overlayRef = null;
        ref.close();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialog, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "22.2.3", type: CrsdDialog, isStandalone: true, selector: "[crsdDialog]", inputs: { state: { classPropertyName: "state", publicName: "state", isSignal: true, isRequired: false, transformFunction: null }, closeOnBackdropClick: { classPropertyName: "closeOnBackdropClick", publicName: "closeOnBackdropClick", isSignal: true, isRequired: false, transformFunction: null }, closeOnEscape: { classPropertyName: "closeOnEscape", publicName: "closeOnEscape", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { state: "stateChange", stateChanged: "stateChanged" }, queries: [{ propertyName: "portalTemplate", first: true, predicate: CrsdDialogPortal, descendants: true, read: TemplateRef, isSignal: true }], exportAs: ["crsdDialog"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialog, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdDialog]',
                    standalone: true,
                    exportAs: 'crsdDialog',
                }]
        }], ctorParameters: () => [], propDecorators: { state: [{ type: i0.Input, args: [{ isSignal: true, alias: "state", required: false }] }, { type: i0.Output, args: ["stateChange"] }], stateChanged: [{ type: i0.Output, args: ["stateChanged"] }], closeOnBackdropClick: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnBackdropClick", required: false }] }], closeOnEscape: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnEscape", required: false }] }], portalTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => CrsdDialogPortal), { ...{ read: TemplateRef }, isSignal: true }] }] } });
class CrsdDialogTrigger {
    dialog = inject(CrsdDialog);
    elementRef = inject((ElementRef));
    onClick(event) {
        event.preventDefault();
        this.dialog.open(this.elementRef.nativeElement);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialogTrigger, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdDialogTrigger, isStandalone: true, selector: "[crsdDialogTrigger]", host: { listeners: { "click": "onClick($event)" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialogTrigger, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdDialogTrigger]',
                    standalone: true,
                    host: {
                        '(click)': 'onClick($event)',
                    },
                }]
        }] });
class CrsdDialogClose {
    dialog = inject(CrsdDialog);
    onClick() {
        this.dialog.close();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialogClose, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdDialogClose, isStandalone: true, selector: "[crsdDialogClose]", host: { listeners: { "click": "onClick()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialogClose, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdDialogClose]',
                    standalone: true,
                    host: {
                        '(click)': 'onClick()',
                    },
                }]
        }] });
class CrsdDialogContent {
    staticClass;
    dialog = inject(CrsdDialog);
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    alert = input(false, { ...(ngDevMode ? { debugName: "alert" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(DIALOG_CONTENT_BASE, 'pointer-events-auto', this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    hostRole = computed(() => (this.alert() ? 'alertdialog' : 'dialog'), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostRole" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialogContent, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdDialogContent, isStandalone: true, selector: "[crsdDialogContent]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null }, alert: { classPropertyName: "alert", publicName: "alert", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.role": "hostRole()", "attr.aria-modal": "true", "attr.aria-labelledby": "dialog.titleId", "attr.aria-describedby": "dialog.descriptionId", "class": "hostClasses()" } }, hostDirectives: [{ directive: CrsdFocusTrap }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialogContent, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdDialogContent]',
                    standalone: true,
                    hostDirectives: [CrsdFocusTrap],
                    host: {
                        '[attr.role]': 'hostRole()',
                        '[attr.aria-modal]': 'true',
                        '[attr.aria-labelledby]': 'dialog.titleId',
                        '[attr.aria-describedby]': 'dialog.descriptionId',
                        '[class]': 'hostClasses()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], alert: [{ type: i0.Input, args: [{ isSignal: true, alias: "alert", required: false }] }] } });
class CrsdDialogHeader {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(DIALOG_HEADER_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialogHeader, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdDialogHeader, isStandalone: true, selector: "[crsdDialogHeader]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialogHeader, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdDialogHeader]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdDialogTitle {
    staticClass;
    dialog = inject(CrsdDialog);
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(DIALOG_TITLE_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialogTitle, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdDialogTitle, isStandalone: true, selector: "[crsdDialogTitle]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()", "attr.id": "dialog.titleId" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialogTitle, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdDialogTitle]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                        '[attr.id]': 'dialog.titleId',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdDialogDescription {
    staticClass;
    dialog = inject(CrsdDialog);
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(DIALOG_DESCRIPTION_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialogDescription, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdDialogDescription, isStandalone: true, selector: "[crsdDialogDescription]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()", "attr.id": "dialog.descriptionId" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialogDescription, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdDialogDescription]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                        '[attr.id]': 'dialog.descriptionId',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdDialogFooter {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(DIALOG_FOOTER_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialogFooter, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdDialogFooter, isStandalone: true, selector: "[crsdDialogFooter]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDialogFooter, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdDialogFooter]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

class CrsdConfirmDialog {
    state = model('closed', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    title = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    description = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []));
    cancelLabel = input('Cancel', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cancelLabel" }] : /* istanbul ignore next */ []));
    confirmLabel = input('Continue', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "confirmLabel" }] : /* istanbul ignore next */ []));
    destructive = input(false, { ...(ngDevMode ? { debugName: "destructive" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closeOnBackdropClick = input(false, { ...(ngDevMode ? { debugName: "closeOnBackdropClick" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closeOnEscape = input(true, { ...(ngDevMode ? { debugName: "closeOnEscape" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    confirmed = output();
    cancelled = output();
    innerDialog = viewChild.required('innerDialog', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "innerDialog" }] : /* istanbul ignore next */ []));
    suppressDismissEvent = false;
    /** Open the confirm overlay; optional element receives focus when closed. */
    open(from) {
        this.innerDialog().open(from);
    }
    confirmColor() {
        return this.destructive() ? 'destructive' : 'primary';
    }
    onProjectedTriggerClick(event) {
        const target = event.target.closest('[crsdConfirmTrigger]');
        if (!target) {
            return;
        }
        event.preventDefault();
        this.open(target instanceof HTMLElement ? target : undefined);
    }
    confirm() {
        this.suppressDismissEvent = true;
        this.confirmed.emit();
        this.state.set('closed');
    }
    cancel() {
        this.suppressDismissEvent = true;
        this.cancelled.emit();
        this.state.set('closed');
    }
    onStateChanged(next) {
        if (next !== 'closed' || this.suppressDismissEvent) {
            this.suppressDismissEvent = false;
            return;
        }
        this.cancelled.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdConfirmDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.2.3", type: CrsdConfirmDialog, isStandalone: true, selector: "crsd-confirm-dialog", inputs: { state: { classPropertyName: "state", publicName: "state", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, description: { classPropertyName: "description", publicName: "description", isSignal: true, isRequired: false, transformFunction: null }, cancelLabel: { classPropertyName: "cancelLabel", publicName: "cancelLabel", isSignal: true, isRequired: false, transformFunction: null }, confirmLabel: { classPropertyName: "confirmLabel", publicName: "confirmLabel", isSignal: true, isRequired: false, transformFunction: null }, destructive: { classPropertyName: "destructive", publicName: "destructive", isSignal: true, isRequired: false, transformFunction: null }, closeOnBackdropClick: { classPropertyName: "closeOnBackdropClick", publicName: "closeOnBackdropClick", isSignal: true, isRequired: false, transformFunction: null }, closeOnEscape: { classPropertyName: "closeOnEscape", publicName: "closeOnEscape", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { state: "stateChange", confirmed: "confirmed", cancelled: "cancelled" }, viewQueries: [{ propertyName: "innerDialog", first: true, predicate: ["innerDialog"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <div
      crsdDialog
      #innerDialog="crsdDialog"
      [(state)]="state"
      [closeOnBackdropClick]="closeOnBackdropClick()"
      [closeOnEscape]="closeOnEscape()"
      (stateChanged)="onStateChanged($event)"
    >
      <div class="contents" (click)="onProjectedTriggerClick($event)">
        <ng-content select="[crsdConfirmTrigger]" />
      </div>
      <ng-template crsdDialogPortal>
        <div crsdDialogContent alert>
          <div crsdDialogHeader>
            <h2 crsdDialogTitle>{{ title() }}</h2>
            @if (description()) {
              <p crsdDialogDescription>{{ description() }}</p>
            }
          </div>
          <div crsdDialogFooter>
            <button crsdBtn variant="outline" type="button" (click)="cancel()">
              {{ cancelLabel() }}
            </button>
            <button
              crsdBtn
              type="button"
              [color]="confirmColor()"
              (click)="confirm()"
            >
              {{ confirmLabel() }}
            </button>
          </div>
        </div>
      </ng-template>
    </div>
  `, isInline: true, dependencies: [{ kind: "directive", type: CrsdBtn, selector: "[crsdBtn]", inputs: ["variant", "color", "size", "disabled", "loading", "class"] }, { kind: "directive", type: CrsdDialog, selector: "[crsdDialog]", inputs: ["state", "closeOnBackdropClick", "closeOnEscape"], outputs: ["stateChange", "stateChanged"], exportAs: ["crsdDialog"] }, { kind: "directive", type: CrsdDialogPortal, selector: "[crsdDialogPortal]" }, { kind: "directive", type: CrsdDialogContent, selector: "[crsdDialogContent]", inputs: ["class", "alert"] }, { kind: "directive", type: CrsdDialogHeader, selector: "[crsdDialogHeader]", inputs: ["class"] }, { kind: "directive", type: CrsdDialogTitle, selector: "[crsdDialogTitle]", inputs: ["class"] }, { kind: "directive", type: CrsdDialogDescription, selector: "[crsdDialogDescription]", inputs: ["class"] }, { kind: "directive", type: CrsdDialogFooter, selector: "[crsdDialogFooter]", inputs: ["class"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdConfirmDialog, decorators: [{
            type: Component,
            args: [{
                    selector: 'crsd-confirm-dialog',
                    standalone: true,
                    imports: [
                        CrsdBtn,
                        CrsdDialog,
                        CrsdDialogPortal,
                        CrsdDialogContent,
                        CrsdDialogHeader,
                        CrsdDialogTitle,
                        CrsdDialogDescription,
                        CrsdDialogFooter,
                    ],
                    template: `
    <div
      crsdDialog
      #innerDialog="crsdDialog"
      [(state)]="state"
      [closeOnBackdropClick]="closeOnBackdropClick()"
      [closeOnEscape]="closeOnEscape()"
      (stateChanged)="onStateChanged($event)"
    >
      <div class="contents" (click)="onProjectedTriggerClick($event)">
        <ng-content select="[crsdConfirmTrigger]" />
      </div>
      <ng-template crsdDialogPortal>
        <div crsdDialogContent alert>
          <div crsdDialogHeader>
            <h2 crsdDialogTitle>{{ title() }}</h2>
            @if (description()) {
              <p crsdDialogDescription>{{ description() }}</p>
            }
          </div>
          <div crsdDialogFooter>
            <button crsdBtn variant="outline" type="button" (click)="cancel()">
              {{ cancelLabel() }}
            </button>
            <button
              crsdBtn
              type="button"
              [color]="confirmColor()"
              (click)="confirm()"
            >
              {{ confirmLabel() }}
            </button>
          </div>
        </div>
      </ng-template>
    </div>
  `,
                }]
        }], propDecorators: { state: [{ type: i0.Input, args: [{ isSignal: true, alias: "state", required: false }] }, { type: i0.Output, args: ["stateChange"] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], description: [{ type: i0.Input, args: [{ isSignal: true, alias: "description", required: false }] }], cancelLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "cancelLabel", required: false }] }], confirmLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "confirmLabel", required: false }] }], destructive: [{ type: i0.Input, args: [{ isSignal: true, alias: "destructive", required: false }] }], closeOnBackdropClick: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnBackdropClick", required: false }] }], closeOnEscape: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnEscape", required: false }] }], confirmed: [{ type: i0.Output, args: ["confirmed"] }], cancelled: [{ type: i0.Output, args: ["cancelled"] }], innerDialog: [{ type: i0.ViewChild, args: ['innerDialog', { isSignal: true }] }] } });

const CURSED_TOAST_MESSAGES = {
    default: {
        titles: ['Something happened.', 'A whisper in the wire.', 'Notification received.'],
        descriptions: ['Pay attention.', 'It might matter. Probably.', 'The system noticed.'],
    },
    success: {
        titles: ['The ritual succeeded.', 'Binding complete.', 'It worked. Somehow.'],
        descriptions: ['Do not question it.', 'The sigil held.', 'For now.'],
    },
    error: {
        titles: ['The binding failed.', 'Something broke.', 'That was not supposed to happen.'],
        descriptions: ['Probably your fault.', 'Try again. Or do not.', 'The void rejected your request.'],
    },
    warning: {
        titles: ['Unsaved changes linger.', 'You were warned.', 'Proceed with caution.'],
        descriptions: ['The threshold is thin here.', 'Save before leaving.', 'Something watches.'],
    },
    info: {
        titles: ['A tip from beyond.', 'Listen closely.', 'Useful knowledge. Maybe.'],
        descriptions: ['Filters narrow the search.', 'The docs know things.', 'Trust but verify.'],
    },
};
function pickCursedToastMessage(variant) {
    const pool = CURSED_TOAST_MESSAGES[variant];
    const title = pool.titles[Math.floor(Math.random() * pool.titles.length)] ?? pool.titles[0];
    const description = pool.descriptions[Math.floor(Math.random() * pool.descriptions.length)] ?? pool.descriptions[0];
    return { title, description };
}

const BLESSED_TOAST_MESSAGES = {
    default: {
        titles: ['A gentle notice.', 'Light reaches you.', 'Something worth knowing.'],
        descriptions: ['Take a breath.', 'All is in order.', 'Proceed with grace.'],
    },
    success: {
        titles: ['Radiance restored.', 'The seal holds.', 'Blessed outcome.'],
        descriptions: ['Your work is preserved.', 'The binding is true.', 'Carry on with confidence.'],
    },
    error: {
        titles: ['The light flickered.', 'Not this time.', 'A shadow crossed the path.'],
        descriptions: ['Try again when ready.', 'Patience brings clarity.', 'The way will reopen.'],
    },
    warning: {
        titles: ['A gentle warning.', 'Pause before you go.', 'Unsaved grace awaits.'],
        descriptions: ['Save your progress.', 'The threshold is near.', 'Mind the unfinished work.'],
    },
    info: {
        titles: ['Guidance received.', 'A luminous tip.', 'Wisdom, softly offered.'],
        descriptions: ['Filters narrow the search.', 'The docs illuminate the path.', 'Light finds a way.'],
    },
};
function pickBlessedToastMessage(variant) {
    const pool = BLESSED_TOAST_MESSAGES[variant];
    const title = pool.titles[Math.floor(Math.random() * pool.titles.length)] ?? pool.titles[0];
    const description = pool.descriptions[Math.floor(Math.random() * pool.descriptions.length)] ?? pool.descriptions[0];
    return { title, description };
}

class CrsdToastService {
    toasts = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "toasts" }] : /* istanbul ignore next */ []));
    themeService = inject(CrsdThemeService);
    nextId = 0;
    show(title, options = {}) {
        const variant = options.variant ?? 'default';
        const useBlessedCopy = this.shouldUseBlessedCopy(options);
        const useCursedCopy = !useBlessedCopy && this.shouldUseCursedCopy(options);
        const blessed = useBlessedCopy ? pickBlessedToastMessage(variant) : null;
        const cursed = useCursedCopy ? pickCursedToastMessage(variant) : null;
        const id = `crsd-toast-${++this.nextId}`;
        const toast = {
            id,
            title: useBlessedCopy ? blessed.title : useCursedCopy ? cursed.title : title,
            description: useBlessedCopy
                ? (options.description ?? blessed.description)
                : useCursedCopy
                    ? (options.description ?? cursed.description)
                    : options.description,
            variant,
            duration: options.duration ?? 4000,
        };
        this.toasts.update((items) => [...items, toast]);
        if (toast.duration > 0) {
            setTimeout(() => this.dismiss(id), toast.duration);
        }
        return id;
    }
    success(title, options = {}) {
        return this.show(title, { ...options, variant: 'success' });
    }
    error(title, options = {}) {
        return this.show(title, { ...options, variant: 'error' });
    }
    warning(title, options = {}) {
        return this.show(title, { ...options, variant: 'warning' });
    }
    info(title, options = {}) {
        return this.show(title, { ...options, variant: 'info' });
    }
    cursed(variant = 'default', options = {}) {
        const copy = pickCursedToastMessage(variant);
        return this.show(copy.title, { ...options, variant, description: options.description ?? copy.description });
    }
    blessed(variant = 'default', options = {}) {
        const copy = pickBlessedToastMessage(variant);
        return this.show(copy.title, { ...options, variant, description: options.description ?? copy.description });
    }
    dismiss(id) {
        this.toasts.update((items) => items.filter((item) => item.id !== id));
    }
    dismissAll() {
        this.toasts.set([]);
    }
    shouldUseCursedCopy(options) {
        if (options.cursedCopy === true) {
            return true;
        }
        if (options.cursedCopy === false || options.blessedCopy === true) {
            return false;
        }
        return this.themeService.isCursed() && this.themeService.isFeatureEnabled('copy');
    }
    shouldUseBlessedCopy(options) {
        if (options.blessedCopy === true) {
            return true;
        }
        if (options.blessedCopy === false || options.cursedCopy === true) {
            return false;
        }
        return this.themeService.isBlessed() && this.themeService.isFeatureEnabled('copy');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdToastService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdToastService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdToastService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
const toast = {
    show: (title, options) => injectToast().show(title, options),
    success: (title, options) => injectToast().success(title, options),
    error: (title, options) => injectToast().error(title, options),
    warning: (title, options) => injectToast().warning(title, options),
    info: (title, options) => injectToast().info(title, options),
    cursed: (variant, options) => injectToast().cursed(variant, options),
    blessed: (variant, options) => injectToast().blessed(variant, options),
    dismiss: (id) => injectToast().dismiss(id),
    dismissAll: () => injectToast().dismissAll(),
};
let toastServiceRef = null;
function provideCrsdToastService(service) {
    toastServiceRef = service;
}
function injectToast() {
    if (!toastServiceRef) {
        toastServiceRef = new CrsdToastService();
    }
    return toastServiceRef;
}

const TOAST_BASE = 'pointer-events-auto relative w-full overflow-hidden rounded-md border border-border p-4 pr-9 shadow-lg transition-all';
const TOAST_VARIANTS = {
    default: 'bg-background text-foreground',
    success: 'border-success/50 bg-success/10 text-success',
    error: 'border-destructive/50 bg-destructive/10 text-destructive',
    warning: 'border-warning/50 bg-warning/10 text-warning',
    info: 'border-info/50 bg-info/10 text-info',
};
const TOAST_RICH_VARIANTS = {
    default: 'border-border bg-background text-foreground',
    success: 'border-success bg-success text-success-foreground',
    error: 'border-destructive bg-destructive text-destructive-foreground',
    warning: 'border-warning bg-warning text-warning-foreground',
    info: 'border-info bg-info text-info-foreground',
};
const TOASTER_BASE = 'fixed top-0 z-toast flex max-h-screen w-full flex-col-reverse gap-2 p-4 sm:bottom-0 sm:right-0 sm:top-auto sm:flex-col md:max-w-[420px]';

class CrsdToaster {
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    richColors = input(false, { ...(ngDevMode ? { debugName: "richColors" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    toastService = inject(CrsdToastService);
    paused = new Map();
    constructor() {
        provideCrsdToastService(this.toastService);
    }
    toasts = this.toastService.toasts;
    hostClasses = computed(() => cn(TOASTER_BASE, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    toastClasses(variant) {
        const variants = this.richColors() ? TOAST_RICH_VARIANTS : TOAST_VARIANTS;
        return cn(TOAST_BASE, variants[variant]);
    }
    dismiss(id) {
        const timer = this.paused.get(id);
        if (timer) {
            clearTimeout(timer);
            this.paused.delete(id);
        }
        this.toastService.dismiss(id);
    }
    pauseDismiss(_id) {
        // hover pauses auto-dismiss — simplified: no-op for MVP timer reset
    }
    resumeDismiss(_id) {
        // resume handled by service duration on show
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdToaster, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.2.3", type: CrsdToaster, isStandalone: true, selector: "crsd-toaster", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null }, richColors: { classPropertyName: "richColors", publicName: "richColors", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "region", "aria-label": "Notifications", "aria-live": "polite" }, properties: { "class": "hostClasses()" } }, ngImport: i0, template: `
    @for (item of toasts(); track item.id) {
      <div
        class="crsd-toast-item"
        [class]="toastClasses(item.variant)"
        role="status"
        (mouseenter)="pauseDismiss(item.id)"
        (mouseleave)="resumeDismiss(item.id)"
      >
        <div class="grid gap-1">
          <p class="text-sm font-semibold">{{ item.title }}</p>
          @if (item.description) {
            <p class="text-sm opacity-90">{{ item.description }}</p>
          }
        </div>
        <button
          crsdBtn
          variant="ghost"
          color="inherit"
          size="icon-xs"
          class="absolute right-1.5 top-1.5 opacity-60 ring-offset-0 hover:opacity-100"
          aria-label="Dismiss notification"
          (click)="dismiss(item.id)"
        >
          <crsd-icon name="x" size="xs" />
        </button>
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: CrsdBtn, selector: "[crsdBtn]", inputs: ["variant", "color", "size", "disabled", "loading", "class"] }, { kind: "component", type: CrsdIcon, selector: "crsd-icon", inputs: ["name", "size", "strokeWidth", "spin", "label", "class"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdToaster, decorators: [{
            type: Component,
            args: [{
                    selector: 'crsd-toaster',
                    standalone: true,
                    imports: [CrsdBtn, CrsdIcon],
                    host: {
                        '[class]': 'hostClasses()',
                        role: 'region',
                        'aria-label': 'Notifications',
                        'aria-live': 'polite',
                    },
                    template: `
    @for (item of toasts(); track item.id) {
      <div
        class="crsd-toast-item"
        [class]="toastClasses(item.variant)"
        role="status"
        (mouseenter)="pauseDismiss(item.id)"
        (mouseleave)="resumeDismiss(item.id)"
      >
        <div class="grid gap-1">
          <p class="text-sm font-semibold">{{ item.title }}</p>
          @if (item.description) {
            <p class="text-sm opacity-90">{{ item.description }}</p>
          }
        </div>
        <button
          crsdBtn
          variant="ghost"
          color="inherit"
          size="icon-xs"
          class="absolute right-1.5 top-1.5 opacity-60 ring-offset-0 hover:opacity-100"
          aria-label="Dismiss notification"
          (click)="dismiss(item.id)"
        >
          <crsd-icon name="x" size="xs" />
        </button>
      </div>
    }
  `,
                }]
        }], ctorParameters: () => [], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], richColors: [{ type: i0.Input, args: [{ isSignal: true, alias: "richColors", required: false }] }] } });

function normalizeOptions(options) {
    return options.map((option) => {
        if (typeof option === 'object' && option !== null && 'value' in option && 'label' in option) {
            return option;
        }
        return { value: option, label: String(option) };
    });
}

const SELECT_TRIGGER_BASE = 'flex w-full cursor-pointer items-center justify-between gap-2 rounded-md border border-input bg-background text-left text-sm ring-offset-background transition-colors hover:bg-muted/50 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0';
const SELECT_TRIGGER_SIZES = {
    sm: 'h-8 px-2.5 py-1 text-xs',
    md: 'h-10 px-3 py-2',
    lg: 'h-11 px-4 py-2.5 text-base',
};
const SELECT_CONTENT_BASE = 'z-modal max-h-60 w-full overflow-auto rounded-md border border-border bg-popover p-1 text-popover-foreground shadow-md';
const SELECT_ITEM_BASE = 'relative flex w-full cursor-pointer select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none hover:bg-muted focus:bg-muted data-[disabled]:pointer-events-none data-[disabled]:opacity-50';
const SELECT_ITEM_SELECTED = "before:absolute before:left-2 before:text-xs before:font-semibold before:content-['✓']";
const SELECT_PLACEHOLDER_BASE = 'text-muted-foreground';

class CrsdSelectPortal {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectPortal, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdSelectPortal, isStandalone: true, selector: "[crsdSelectPortal]", host: { styleAttribute: "display: none" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectPortal, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSelectPortal]',
                    standalone: true,
                    host: {
                        style: 'display: none',
                    },
                }]
        }] });
class CrsdSelectTriggerHost {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectTriggerHost, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdSelectTriggerHost, isStandalone: true, selector: "[crsdSelectTriggerHost]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectTriggerHost, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSelectTriggerHost]',
                    standalone: true,
                }]
        }] });
class CrsdSelectValueTemplate {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectValueTemplate, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdSelectValueTemplate, isStandalone: true, selector: "[crsdSelectValueTemplate]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectValueTemplate, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSelectValueTemplate]',
                    standalone: true,
                }]
        }] });
class CrsdSelect {
    value = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    valueChanged = output();
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    state = model('closed', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    stateChanged = output();
    listboxId = inject(CrsdIdService).generate('crsd-select-listbox');
    valueTemplate = contentChild(CrsdSelectValueTemplate, { ...(ngDevMode ? { debugName: "valueTemplate" } : /* istanbul ignore next */ {}), read: TemplateRef });
    portalTemplate = contentChild(CrsdSelectPortal, { ...(ngDevMode ? { debugName: "portalTemplate" } : /* istanbul ignore next */ {}), read: TemplateRef });
    triggerRef = contentChild(CrsdSelectTriggerHost, { ...(ngDevMode ? { debugName: "triggerRef" } : /* istanbul ignore next */ {}), read: ElementRef });
    overlayService = inject(CrsdOverlayService);
    viewContainer = inject(ViewContainerRef);
    destroyRef = inject(DestroyRef);
    overlayRef = null;
    outsideClickSub = null;
    constructor() {
        effect(() => {
            if (this.state() === 'open' && !this.disabled()) {
                this.openOverlay();
            }
            else {
                this.closeOverlay();
            }
        });
        fromEvent(document, 'keydown')
            .pipe(filter$1(() => this.state() === 'open'), takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            if (event.key === 'Escape') {
                this.setState('closed');
            }
        });
    }
    select(value) {
        this.value.set(value);
        this.valueChanged.emit(value);
        this.setState('closed');
    }
    toggle() {
        if (this.disabled()) {
            return;
        }
        this.setState(this.state() === 'open' ? 'closed' : 'open');
    }
    setState(next) {
        this.state.set(next);
        this.stateChanged.emit(next);
    }
    openOverlay() {
        const template = this.portalTemplate();
        const trigger = this.triggerRef()?.nativeElement;
        if (!template || !trigger || this.overlayRef) {
            return;
        }
        this.overlayRef = this.overlayService.createConnected(trigger, CRSD_CONNECTED_POSITIONS, { panelClass: 'z-modal', hasBackdrop: false, width: trigger.offsetWidth, minWidth: trigger.offsetWidth }, { closeOnEscape: false, scrollStrategy: 'reposition' }, this.destroyRef);
        this.overlayRef.attachPortal(new TemplatePortal(template, this.viewContainer));
        this.overlayRef.setConnectedWidth(trigger.offsetWidth);
        this.outsideClickSub = this.overlayRef.listenPointerDownOutside(trigger, () => this.setState('closed'));
    }
    closeOverlay() {
        this.outsideClickSub?.unsubscribe();
        this.outsideClickSub = null;
        this.overlayRef?.close();
        this.overlayRef = null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelect, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "22.2.3", type: CrsdSelect, isStandalone: true, selector: "[crsdSelect]", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, state: { classPropertyName: "state", publicName: "state", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", valueChanged: "valueChanged", state: "stateChange", stateChanged: "stateChanged" }, queries: [{ propertyName: "valueTemplate", first: true, predicate: CrsdSelectValueTemplate, descendants: true, read: TemplateRef, isSignal: true }, { propertyName: "portalTemplate", first: true, predicate: CrsdSelectPortal, descendants: true, read: TemplateRef, isSignal: true }, { propertyName: "triggerRef", first: true, predicate: CrsdSelectTriggerHost, descendants: true, read: ElementRef, isSignal: true }], exportAs: ["crsdSelect"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelect, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSelect]',
                    standalone: true,
                    exportAs: 'crsdSelect',
                }]
        }], ctorParameters: () => [], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], valueChanged: [{ type: i0.Output, args: ["valueChanged"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], state: [{ type: i0.Input, args: [{ isSignal: true, alias: "state", required: false }] }, { type: i0.Output, args: ["stateChange"] }], stateChanged: [{ type: i0.Output, args: ["stateChanged"] }], valueTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => CrsdSelectValueTemplate), { ...{ read: TemplateRef }, isSignal: true }] }], portalTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => CrsdSelectPortal), { ...{ read: TemplateRef }, isSignal: true }] }], triggerRef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => CrsdSelectTriggerHost), { ...{ read: ElementRef }, isSignal: true }] }] } });
class CrsdSelectValue {
    crsdSelectValue = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "crsdSelectValue" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectValue, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSelectValue, isStandalone: true, selector: "[crsdSelectValue]", inputs: { crsdSelectValue: { classPropertyName: "crsdSelectValue", publicName: "crsdSelectValue", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectValue, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSelectValue]',
                    standalone: true,
                }]
        }], propDecorators: { crsdSelectValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "crsdSelectValue", required: false }] }] } });
class CrsdSelectPlaceholder {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(SELECT_PLACEHOLDER_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectPlaceholder, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSelectPlaceholder, isStandalone: true, selector: "[crsdSelectPlaceholder]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectPlaceholder, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSelectPlaceholder]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdSelectItem {
    staticClass;
    value = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    select = inject((CrsdSelect));
    selected = computed(() => this.select.value() === this.value(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []));
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(SELECT_ITEM_BASE, { [SELECT_ITEM_SELECTED]: this.selected(), 'bg-muted font-medium': this.selected() }, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    onSelect() {
        if (this.disabled()) {
            return;
        }
        this.select.select(this.value());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectItem, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSelectItem, isStandalone: true, selector: "[crsdSelectItem]", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "option" }, listeners: { "click": "onSelect()" }, properties: { "attr.aria-selected": "selected()", "class": "hostClasses()", "attr.data-disabled": "disabled() ? true : null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectItem, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSelectItem]',
                    standalone: true,
                    host: {
                        role: 'option',
                        '[attr.aria-selected]': 'selected()',
                        '[class]': 'hostClasses()',
                        '[attr.data-disabled]': 'disabled() ? true : null',
                        '(click)': 'onSelect()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: true }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdSelectContent {
    staticClass;
    select = inject((CrsdSelect));
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    options = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "options" }] : /* istanbul ignore next */ []));
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    normalizedOptions = computed(() => {
        const opts = this.options();
        return opts ? normalizeOptions(opts) : [];
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "normalizedOptions" }] : /* istanbul ignore next */ []));
    hostClasses = computed(() => cn(SELECT_CONTENT_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectContent, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.2.3", type: CrsdSelectContent, isStandalone: true, selector: "[crsdSelectContent]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "listbox" }, properties: { "attr.id": "select.listboxId", "class": "hostClasses()" } }, ngImport: i0, template: `
    @if (options(); as opts) {
      @for (option of normalizedOptions(); track option.value) {
        <li crsdSelectItem [value]="option.value" [disabled]="option.disabled ?? false">
          {{ option.label }}
        </li>
      }
    } @else {
      <ng-content />
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: CrsdSelectItem, selector: "[crsdSelectItem]", inputs: ["value", "disabled", "class"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectContent, decorators: [{
            type: Component,
            args: [{
                    selector: '[crsdSelectContent]',
                    standalone: true,
                    imports: [CrsdSelectItem],
                    host: {
                        role: 'listbox',
                        '[attr.id]': 'select.listboxId',
                        '[class]': 'hostClasses()',
                    },
                    template: `
    @if (options(); as opts) {
      @for (option of normalizedOptions(); track option.value) {
        <li crsdSelectItem [value]="option.value" [disabled]="option.disabled ?? false">
          {{ option.label }}
        </li>
      }
    } @else {
      <ng-content />
    }
  `,
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }] } });

class CrsdSelectTrigger {
    staticClass;
    select = inject(CrsdSelect);
    size = input('md', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "size" }] : /* istanbul ignore next */ []));
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(SELECT_TRIGGER_BASE, SELECT_TRIGGER_SIZES[this.size()], this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    onEnter(event) {
        event.preventDefault();
        this.select.toggle();
    }
    onSpace(event) {
        event.preventDefault();
        this.select.toggle();
    }
    onArrow(event) {
        event.preventDefault();
        this.select.setState('open');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectTrigger, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.2.3", type: CrsdSelectTrigger, isStandalone: true, selector: "[crsdSelectTrigger]", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "combobox" }, listeners: { "click": "select.toggle()", "keydown.enter": "onEnter($event)", "keydown.space": "onSpace($event)", "keydown.arrowdown": "onArrow($event)" }, properties: { "attr.aria-expanded": "select.state() === \"open\"", "attr.aria-haspopup": "\"listbox\"", "attr.aria-controls": "select.listboxId", "attr.disabled": "select.disabled() ? true : null", "class": "hostClasses()" } }, hostDirectives: [{ directive: CrsdSelectTriggerHost }], ngImport: i0, template: `
    @if (select.value() == null) {
      <ng-content select="[crsdSelectPlaceholder]" />
    } @else if (select.valueTemplate()) {
      <ng-container
        *ngTemplateOutlet="select.valueTemplate()!; context: { $implicit: select.value() }"
      />
    } @else {
      <ng-content select="[crsdSelectValue]" />
      <ng-content />
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectTrigger, decorators: [{
            type: Component,
            args: [{
                    selector: '[crsdSelectTrigger]',
                    standalone: true,
                    imports: [NgTemplateOutlet],
                    hostDirectives: [CrsdSelectTriggerHost],
                    host: {
                        role: 'combobox',
                        '[attr.aria-expanded]': 'select.state() === "open"',
                        '[attr.aria-haspopup]': '"listbox"',
                        '[attr.aria-controls]': 'select.listboxId',
                        '[attr.disabled]': 'select.disabled() ? true : null',
                        '[class]': 'hostClasses()',
                        '(click)': 'select.toggle()',
                        '(keydown.enter)': 'onEnter($event)',
                        '(keydown.space)': 'onSpace($event)',
                        '(keydown.arrowdown)': 'onArrow($event)',
                    },
                    template: `
    @if (select.value() == null) {
      <ng-content select="[crsdSelectPlaceholder]" />
    } @else if (select.valueTemplate()) {
      <ng-container
        *ngTemplateOutlet="select.valueTemplate()!; context: { $implicit: select.value() }"
      />
    } @else {
      <ng-content select="[crsdSelectValue]" />
      <ng-content />
    }
  `,
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

const EMPTY_BASE = 'flex min-w-0 flex-1 flex-col items-center justify-center gap-6 rounded-lg border border-dashed border-border p-6 text-center';
const EMPTY_HEADER_BASE = 'flex max-w-sm flex-col items-center gap-2';
const EMPTY_MEDIA_BASE = 'flex shrink-0 items-center justify-center text-muted-foreground';
const EMPTY_MEDIA_ICON_VARIANT = 'mb-2 rounded-full bg-muted p-3 text-muted-foreground [&_img]:size-6 [&_svg]:size-6';
const EMPTY_TITLE_BASE = 'text-lg font-semibold tracking-tight';
const EMPTY_DESCRIPTION_BASE = 'text-sm text-muted-foreground';

class CrsdEmpty {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(EMPTY_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdEmpty, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdEmpty, isStandalone: true, selector: "[crsdEmpty]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdEmpty, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdEmpty]',
                    standalone: true,
                    host: { '[class]': 'hostClasses()' },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdEmptyHeader {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(EMPTY_HEADER_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdEmptyHeader, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdEmptyHeader, isStandalone: true, selector: "[crsdEmptyHeader]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdEmptyHeader, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdEmptyHeader]',
                    standalone: true,
                    host: { '[class]': 'hostClasses()' },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdEmptyMedia {
    staticClass;
    variant = input('default', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(EMPTY_MEDIA_BASE, { [EMPTY_MEDIA_ICON_VARIANT]: this.variant() === 'icon' }, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdEmptyMedia, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdEmptyMedia, isStandalone: true, selector: "[crsdEmptyMedia]", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdEmptyMedia, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdEmptyMedia]',
                    standalone: true,
                    host: { '[class]': 'hostClasses()' },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdEmptyTitle {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(EMPTY_TITLE_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdEmptyTitle, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdEmptyTitle, isStandalone: true, selector: "[crsdEmptyTitle]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdEmptyTitle, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdEmptyTitle]',
                    standalone: true,
                    host: { '[class]': 'hostClasses()' },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdEmptyDescription {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(EMPTY_DESCRIPTION_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdEmptyDescription, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdEmptyDescription, isStandalone: true, selector: "[crsdEmptyDescription]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdEmptyDescription, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdEmptyDescription]',
                    standalone: true,
                    host: { '[class]': 'hostClasses()' },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

const SHEET_CONTENT_BASE = 'fixed z-modal flex flex-col gap-4 border border-border bg-background p-6 shadow-lg transition ease-in-out';
const SHEET_SIDES = {
    right: 'inset-y-0 right-0 h-full w-3/4 max-w-sm border-l',
    left: 'inset-y-0 left-0 h-full w-3/4 max-w-sm border-r',
    top: 'inset-x-0 top-0 w-full border-b',
    bottom: 'inset-x-0 bottom-0 w-full border-t',
};
const SHEET_HEADER_BASE = 'flex flex-col space-y-2 text-center sm:text-left';
const SHEET_FOOTER_BASE = 'flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2';
const SHEET_TITLE_BASE = 'text-lg font-semibold text-foreground';
const SHEET_DESCRIPTION_BASE = 'text-sm text-muted-foreground';

class CrsdSheetPortal {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheetPortal, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdSheetPortal, isStandalone: true, selector: "[crsdSheetPortal]", host: { styleAttribute: "display: none" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheetPortal, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSheetPortal]',
                    standalone: true,
                    host: { style: 'display: none' },
                }]
        }] });
class CrsdSheet {
    state = model('closed', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    stateChanged = output();
    side = input('right', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "side" }] : /* istanbul ignore next */ []));
    closeOnBackdropClick = input(true, { ...(ngDevMode ? { debugName: "closeOnBackdropClick" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    titleId = inject(CrsdIdService).generate('crsd-sheet-title');
    descriptionId = inject(CrsdIdService).generate('crsd-sheet-desc');
    portalTemplate = contentChild(CrsdSheetPortal, { ...(ngDevMode ? { debugName: "portalTemplate" } : /* istanbul ignore next */ {}), read: TemplateRef });
    overlayService = inject(CrsdOverlayService);
    viewContainer = inject(ViewContainerRef);
    destroyRef = inject(DestroyRef);
    overlayRef = null;
    triggerElement = null;
    constructor() {
        effect(() => {
            if (this.state() === 'open') {
                this.attachOverlay();
            }
            else {
                this.detachOverlay();
            }
        });
    }
    open(from) {
        this.triggerElement = from ?? document.activeElement;
        this.setState('open');
    }
    close() {
        this.setState('closed');
        this.triggerElement?.focus?.();
    }
    setState(next) {
        this.state.set(next);
        this.stateChanged.emit(next);
    }
    attachOverlay() {
        const template = this.portalTemplate();
        if (!template || this.overlayRef) {
            return;
        }
        this.overlayRef = this.overlayService.createConnected({ x: window.innerWidth / 2, y: window.innerHeight / 2 }, CRSD_SHEET_POSITIONS[this.side()], { hasBackdrop: true, panelClass: 'pointer-events-none' }, {
            hasBackdrop: true,
            closeOnBackdropClick: this.closeOnBackdropClick(),
            onClose: () => this.close(),
        }, this.destroyRef);
        this.overlayRef.attachPortal(new TemplatePortal(template, this.viewContainer));
    }
    detachOverlay() {
        if (!this.overlayRef) {
            return;
        }
        this.overlayRef.close();
        this.overlayRef = null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheet, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "22.2.3", type: CrsdSheet, isStandalone: true, selector: "[crsdSheet]", inputs: { state: { classPropertyName: "state", publicName: "state", isSignal: true, isRequired: false, transformFunction: null }, side: { classPropertyName: "side", publicName: "side", isSignal: true, isRequired: false, transformFunction: null }, closeOnBackdropClick: { classPropertyName: "closeOnBackdropClick", publicName: "closeOnBackdropClick", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { state: "stateChange", stateChanged: "stateChanged" }, queries: [{ propertyName: "portalTemplate", first: true, predicate: CrsdSheetPortal, descendants: true, read: TemplateRef, isSignal: true }], exportAs: ["crsdSheet"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheet, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSheet]',
                    standalone: true,
                    exportAs: 'crsdSheet',
                }]
        }], ctorParameters: () => [], propDecorators: { state: [{ type: i0.Input, args: [{ isSignal: true, alias: "state", required: false }] }, { type: i0.Output, args: ["stateChange"] }], stateChanged: [{ type: i0.Output, args: ["stateChanged"] }], side: [{ type: i0.Input, args: [{ isSignal: true, alias: "side", required: false }] }], closeOnBackdropClick: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeOnBackdropClick", required: false }] }], portalTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => CrsdSheetPortal), { ...{ read: TemplateRef }, isSignal: true }] }] } });
class CrsdSheetTrigger {
    sheet = inject(CrsdSheet);
    elementRef = inject((ElementRef));
    onClick(event) {
        event.preventDefault();
        this.sheet.open(this.elementRef.nativeElement);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheetTrigger, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdSheetTrigger, isStandalone: true, selector: "[crsdSheetTrigger]", host: { listeners: { "click": "onClick($event)" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheetTrigger, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSheetTrigger]',
                    standalone: true,
                    host: { '(click)': 'onClick($event)' },
                }]
        }] });
class CrsdSheetClose {
    sheet = inject(CrsdSheet);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheetClose, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdSheetClose, isStandalone: true, selector: "[crsdSheetClose]", host: { listeners: { "click": "sheet.close()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheetClose, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSheetClose]',
                    standalone: true,
                    host: { '(click)': 'sheet.close()' },
                }]
        }] });
class CrsdSheetContent {
    staticClass;
    sheet = inject(CrsdSheet);
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(SHEET_CONTENT_BASE, SHEET_SIDES[this.sheet.side()], 'pointer-events-auto', this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheetContent, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSheetContent, isStandalone: true, selector: "[crsdSheetContent]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "dialog" }, properties: { "attr.aria-modal": "true", "attr.aria-labelledby": "sheet.titleId", "attr.aria-describedby": "sheet.descriptionId", "class": "hostClasses()" } }, hostDirectives: [{ directive: CrsdFocusTrap }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheetContent, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSheetContent]',
                    standalone: true,
                    hostDirectives: [CrsdFocusTrap],
                    host: {
                        role: 'dialog',
                        '[attr.aria-modal]': 'true',
                        '[attr.aria-labelledby]': 'sheet.titleId',
                        '[attr.aria-describedby]': 'sheet.descriptionId',
                        '[class]': 'hostClasses()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdSheetHeader {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(SHEET_HEADER_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheetHeader, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSheetHeader, isStandalone: true, selector: "[crsdSheetHeader]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheetHeader, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSheetHeader]',
                    standalone: true,
                    host: { '[class]': 'hostClasses()' },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdSheetTitle {
    staticClass;
    sheet = inject(CrsdSheet);
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(SHEET_TITLE_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheetTitle, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSheetTitle, isStandalone: true, selector: "[crsdSheetTitle]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()", "attr.id": "sheet.titleId" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheetTitle, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSheetTitle]',
                    standalone: true,
                    host: { '[class]': 'hostClasses()', '[attr.id]': 'sheet.titleId' },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdSheetDescription {
    staticClass;
    sheet = inject(CrsdSheet);
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(SHEET_DESCRIPTION_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheetDescription, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSheetDescription, isStandalone: true, selector: "[crsdSheetDescription]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()", "attr.id": "sheet.descriptionId" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheetDescription, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSheetDescription]',
                    standalone: true,
                    host: { '[class]': 'hostClasses()', '[attr.id]': 'sheet.descriptionId' },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdSheetFooter {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(SHEET_FOOTER_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheetFooter, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSheetFooter, isStandalone: true, selector: "[crsdSheetFooter]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSheetFooter, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSheetFooter]',
                    standalone: true,
                    host: { '[class]': 'hostClasses()' },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

const MENU_CONTENT_BASE = 'z-modal min-w-[8rem] overflow-hidden rounded-md border border-border bg-popover p-1 text-popover-foreground shadow-md';
const MENU_ITEM_BASE = 'relative flex cursor-pointer select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none hover:bg-muted focus:bg-muted data-[disabled]:pointer-events-none data-[disabled]:opacity-50';
const MENU_LABEL_BASE = 'px-2 py-1.5 text-sm font-semibold';
const MENU_RADIO_INDICATOR_BASE = 'absolute left-2 flex size-3.5 items-center justify-center';

class CrsdMenu {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(MENU_CONTENT_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdMenu, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdMenu, isStandalone: true, selector: "[crsdMenu]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "menu" }, properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdMenu, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdMenu]',
                    standalone: true,
                    host: {
                        role: 'menu',
                        '[class]': 'hostClasses()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdMenuItem {
    staticClass;
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(MENU_ITEM_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdMenuItem, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdMenuItem, isStandalone: true, selector: "[crsdMenuItem]", inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "menuitem", "tabindex": "-1" }, properties: { "class": "hostClasses()", "attr.data-disabled": "disabled() ? true : null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdMenuItem, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdMenuItem]',
                    standalone: true,
                    host: {
                        role: 'menuitem',
                        tabindex: '-1',
                        '[class]': 'hostClasses()',
                        '[attr.data-disabled]': 'disabled() ? true : null',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdMenuLabel {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(MENU_LABEL_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdMenuLabel, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdMenuLabel, isStandalone: true, selector: "[crsdMenuLabel]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "presentation" }, properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdMenuLabel, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdMenuLabel]',
                    standalone: true,
                    host: {
                        role: 'presentation',
                        '[class]': 'hostClasses()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdMenuGroup {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdMenuGroup, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdMenuGroup, isStandalone: true, selector: "[crsdMenuGroup]", host: { attributes: { "role": "group" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdMenuGroup, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdMenuGroup]',
                    standalone: true,
                    host: {
                        role: 'group',
                    },
                }]
        }] });
class CrsdMenuRadioItem {
    staticClass;
    value = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    group = inject(CrsdMenuRadioGroup, { optional: true });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    selected = computed(() => this.group?.value() === this.value(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []));
    hostClasses = computed(() => cn(MENU_ITEM_BASE, 'pl-8', this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    select() {
        this.group?.value.set(this.value());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdMenuRadioItem, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdMenuRadioItem, isStandalone: true, selector: "[crsdMenuRadioItem]", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "menuitemradio", "tabindex": "-1" }, listeners: { "click": "select()" }, properties: { "attr.aria-checked": "selected()", "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdMenuRadioItem, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdMenuRadioItem]',
                    standalone: true,
                    host: {
                        role: 'menuitemradio',
                        '[attr.aria-checked]': 'selected()',
                        tabindex: '-1',
                        '[class]': 'hostClasses()',
                        '(click)': 'select()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: true }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdMenuRadioGroup {
    value = model('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    options = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "options" }] : /* istanbul ignore next */ []));
    normalizedOptions = computed(() => {
        const opts = this.options();
        return opts ? normalizeOptions(opts) : [];
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "normalizedOptions" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdMenuRadioGroup, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.2.3", type: CrsdMenuRadioGroup, isStandalone: true, selector: "[crsdMenuRadioGroup]", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { attributes: { "role": "group" } }, ngImport: i0, template: `
    @if (options(); as opts) {
      @for (option of normalizedOptions(); track option.value) {
        <div crsdMenuRadioItem [value]="option.value">{{ option.label }}</div>
      }
    } @else {
      <ng-content />
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: CrsdMenuRadioItem, selector: "[crsdMenuRadioItem]", inputs: ["value", "class"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdMenuRadioGroup, decorators: [{
            type: Component,
            args: [{
                    selector: '[crsdMenuRadioGroup]',
                    standalone: true,
                    imports: [CrsdMenuRadioItem],
                    host: {
                        role: 'group',
                    },
                    template: `
    @if (options(); as opts) {
      @for (option of normalizedOptions(); track option.value) {
        <div crsdMenuRadioItem [value]="option.value">{{ option.label }}</div>
      }
    } @else {
      <ng-content />
    }
  `,
                }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }] } });
class CrsdMenuRadioIndicator {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(MENU_RADIO_INDICATOR_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdMenuRadioIndicator, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdMenuRadioIndicator, isStandalone: true, selector: "[crsdMenuRadioIndicator]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdMenuRadioIndicator, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdMenuRadioIndicator]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

class CrsdDropdownMenuPortal {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDropdownMenuPortal, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdDropdownMenuPortal, isStandalone: true, selector: "[crsdDropdownMenuPortal]", host: { styleAttribute: "display: none" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDropdownMenuPortal, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdDropdownMenuPortal]',
                    standalone: true,
                    host: { style: 'display: none' },
                }]
        }] });
class CrsdDropdownMenuTrigger {
    menu = inject(CrsdDropdownMenu);
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDropdownMenuTrigger, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdDropdownMenuTrigger, isStandalone: true, selector: "[crsdDropdownMenuTrigger]", inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "menu.toggle()" }, properties: { "attr.aria-haspopup": "\"menu\"", "attr.aria-expanded": "menu.state() === \"open\"" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDropdownMenuTrigger, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdDropdownMenuTrigger]',
                    standalone: true,
                    host: {
                        '[attr.aria-haspopup]': '"menu"',
                        '[attr.aria-expanded]': 'menu.state() === "open"',
                        '(click)': 'menu.toggle()',
                    },
                }]
        }], propDecorators: { disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }] } });
class CrsdDropdownMenu {
    state = model('closed', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    stateChanged = output();
    portalTemplate = contentChild(CrsdDropdownMenuPortal, { ...(ngDevMode ? { debugName: "portalTemplate" } : /* istanbul ignore next */ {}), read: TemplateRef });
    triggerRef = contentChild(CrsdDropdownMenuTrigger, { ...(ngDevMode ? { debugName: "triggerRef" } : /* istanbul ignore next */ {}), read: ElementRef });
    overlayService = inject(CrsdOverlayService);
    viewContainer = inject(ViewContainerRef);
    destroyRef = inject(DestroyRef);
    overlayRef = null;
    outsideClickSub = null;
    constructor() {
        effect(() => {
            if (this.state() === 'open') {
                this.openOverlay();
            }
            else {
                this.closeOverlay();
            }
        });
    }
    toggle() {
        this.setState(this.state() === 'open' ? 'closed' : 'open');
    }
    close() {
        this.setState('closed');
    }
    setState(next) {
        this.state.set(next);
        this.stateChanged.emit(next);
    }
    openOverlay() {
        const template = this.portalTemplate();
        const trigger = this.triggerRef()?.nativeElement;
        if (!template || !trigger || this.overlayRef) {
            return;
        }
        this.overlayRef = this.overlayService.createConnected(trigger, CRSD_CONNECTED_POSITIONS, { panelClass: 'z-modal', hasBackdrop: false }, { closeOnEscape: true, onClose: () => this.close(), scrollStrategy: 'reposition' }, this.destroyRef);
        this.overlayRef.attachPortal(new TemplatePortal(template, this.viewContainer));
        this.outsideClickSub = this.overlayRef.listenPointerDownOutside(trigger, () => this.close());
        this.overlayRef.overlayElement.addEventListener('click', this.onMenuClick);
    }
    onMenuClick = (event) => {
        if (event.target.closest('[role=menuitem]')) {
            this.close();
        }
    };
    closeOverlay() {
        this.overlayRef?.overlayElement.removeEventListener('click', this.onMenuClick);
        this.outsideClickSub?.unsubscribe();
        this.outsideClickSub = null;
        this.overlayRef?.close();
        this.overlayRef = null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDropdownMenu, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "22.2.3", type: CrsdDropdownMenu, isStandalone: true, selector: "[crsdDropdownMenu]", inputs: { state: { classPropertyName: "state", publicName: "state", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { state: "stateChange", stateChanged: "stateChanged" }, queries: [{ propertyName: "portalTemplate", first: true, predicate: CrsdDropdownMenuPortal, descendants: true, read: TemplateRef, isSignal: true }, { propertyName: "triggerRef", first: true, predicate: CrsdDropdownMenuTrigger, descendants: true, read: ElementRef, isSignal: true }], exportAs: ["crsdDropdownMenu"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDropdownMenu, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdDropdownMenu]',
                    standalone: true,
                    exportAs: 'crsdDropdownMenu',
                }]
        }], ctorParameters: () => [], propDecorators: { state: [{ type: i0.Input, args: [{ isSignal: true, alias: "state", required: false }] }, { type: i0.Output, args: ["stateChange"] }], stateChanged: [{ type: i0.Output, args: ["stateChanged"] }], portalTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => CrsdDropdownMenuPortal), { ...{ read: TemplateRef }, isSignal: true }] }], triggerRef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => CrsdDropdownMenuTrigger), { ...{ read: ElementRef }, isSignal: true }] }] } });
class CrsdDropdownMenuContent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDropdownMenuContent, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdDropdownMenuContent, isStandalone: true, selector: "[crsdDropdownMenuContent]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdDropdownMenuContent, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdDropdownMenuContent]',
                    standalone: true,
                }]
        }] });

class CrsdContextMenuPortal {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdContextMenuPortal, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdContextMenuPortal, isStandalone: true, selector: "[crsdContextMenuPortal]", host: { styleAttribute: "display: none" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdContextMenuPortal, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdContextMenuPortal]',
                    standalone: true,
                    host: { style: 'display: none' },
                }]
        }] });
class CrsdContextMenuTrigger {
    menu = inject(CrsdContextMenu);
    destroyRef = inject(DestroyRef);
    constructor() {
        fromEvent(document, 'click')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.menu.close());
    }
    onContextMenu(event) {
        event.preventDefault();
        this.menu.openAt(event.clientX, event.clientY);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdContextMenuTrigger, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdContextMenuTrigger, isStandalone: true, selector: "[crsdContextMenuTrigger]", host: { listeners: { "contextmenu": "onContextMenu($event)" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdContextMenuTrigger, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdContextMenuTrigger]',
                    standalone: true,
                    host: {
                        '(contextmenu)': 'onContextMenu($event)',
                    },
                }]
        }], ctorParameters: () => [] });
class CrsdContextMenu {
    state = model('closed', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    stateChanged = output();
    portalTemplate = contentChild(CrsdContextMenuPortal, { ...(ngDevMode ? { debugName: "portalTemplate" } : /* istanbul ignore next */ {}), read: TemplateRef });
    triggerRef = contentChild(CrsdContextMenuTrigger, { ...(ngDevMode ? { debugName: "triggerRef" } : /* istanbul ignore next */ {}), read: ElementRef });
    overlayService = inject(CrsdOverlayService);
    viewContainer = inject(ViewContainerRef);
    destroyRef = inject(DestroyRef);
    overlayRef = null;
    lastPosition = { x: 0, y: 0 };
    constructor() {
        effect(() => {
            if (this.state() === 'open') {
                this.openOverlay();
            }
            else {
                this.closeOverlay();
            }
        });
    }
    openAt(x, y) {
        this.lastPosition = { x, y };
        this.setState('open');
    }
    close() {
        this.setState('closed');
    }
    setState(next) {
        this.state.set(next);
        this.stateChanged.emit(next);
    }
    openOverlay() {
        const template = this.portalTemplate();
        if (!template || this.overlayRef) {
            return;
        }
        this.overlayRef = this.overlayService.createConnected(this.lastPosition, CRSD_CONNECTED_POSITIONS, { panelClass: 'z-modal', hasBackdrop: false }, { closeOnEscape: true, onClose: () => this.close() }, this.destroyRef);
        this.overlayRef.attachPortal(new TemplatePortal(template, this.viewContainer));
    }
    closeOverlay() {
        this.overlayRef?.close();
        this.overlayRef = null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdContextMenu, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "22.2.3", type: CrsdContextMenu, isStandalone: true, selector: "[crsdContextMenu]", inputs: { state: { classPropertyName: "state", publicName: "state", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { state: "stateChange", stateChanged: "stateChanged" }, queries: [{ propertyName: "portalTemplate", first: true, predicate: CrsdContextMenuPortal, descendants: true, read: TemplateRef, isSignal: true }, { propertyName: "triggerRef", first: true, predicate: CrsdContextMenuTrigger, descendants: true, read: ElementRef, isSignal: true }], exportAs: ["crsdContextMenu"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdContextMenu, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdContextMenu]',
                    standalone: true,
                    exportAs: 'crsdContextMenu',
                }]
        }], ctorParameters: () => [], propDecorators: { state: [{ type: i0.Input, args: [{ isSignal: true, alias: "state", required: false }] }, { type: i0.Output, args: ["stateChange"] }], stateChanged: [{ type: i0.Output, args: ["stateChanged"] }], portalTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => CrsdContextMenuPortal), { ...{ read: TemplateRef }, isSignal: true }] }], triggerRef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => CrsdContextMenuTrigger), { ...{ read: ElementRef }, isSignal: true }] }] } });
class CrsdContextMenuContent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdContextMenuContent, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdContextMenuContent, isStandalone: true, selector: "[crsdContextMenuContent]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdContextMenuContent, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdContextMenuContent]',
                    standalone: true,
                }]
        }] });

const COMBOBOX_TRIGGER_BASE = 'flex min-h-10 w-full cursor-pointer flex-wrap items-center gap-1.5 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background transition-colors hover:bg-muted/50 focus-within:outline-none focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-2 [&_svg]:ml-auto [&_svg]:size-4 [&_svg]:shrink-0';
const COMBOBOX_CHIP_BASE = 'inline-flex items-center gap-1 rounded-md bg-secondary px-2 py-0.5 text-xs font-medium text-secondary-foreground';
const COMBOBOX_PANEL_BASE = 'z-modal w-full overflow-hidden rounded-md border border-border bg-popover text-popover-foreground shadow-md';
const COMBOBOX_CONTENT_BASE = 'max-h-60 w-full overflow-auto p-1';
const COMBOBOX_FILTER_BASE = 'border-b border-border p-2';
const COMBOBOX_ITEM_BASE = 'relative flex w-full cursor-pointer select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none hover:bg-muted focus:bg-muted';
const COMBOBOX_ITEM_SELECTED = "before:absolute before:left-2 before:text-xs before:font-semibold before:content-['✓']";
const COMBOBOX_EMPTY_BASE = 'py-6 text-center text-sm text-muted-foreground';

class CrsdComboboxPortal {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxPortal, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdComboboxPortal, isStandalone: true, selector: "[crsdComboboxPortal]", host: { styleAttribute: "display: none" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxPortal, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdComboboxPortal]',
                    standalone: true,
                    host: { style: 'display: none' },
                }]
        }] });
class CrsdComboboxChip {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(COMBOBOX_CHIP_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxChip, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdComboboxChip, isStandalone: true, selector: "[crsdComboboxChip]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxChip, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdComboboxChip]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdComboboxTriggerHost {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxTriggerHost, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdComboboxTriggerHost, isStandalone: true, selector: "[crsdComboboxTriggerHost]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxTriggerHost, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdComboboxTriggerHost]',
                    standalone: true,
                }]
        }] });
class CrsdComboboxValues {
    templateRef = inject((TemplateRef));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxValues, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdComboboxValues, isStandalone: true, selector: "[crsdComboboxValues]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxValues, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdComboboxValues]',
                    standalone: true,
                }]
        }] });
class CrsdCombobox {
    value = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    valueChanged = output();
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    state = model('closed', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    filter = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []));
    options = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "options" }] : /* istanbul ignore next */ []));
    emptyLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "emptyLabel" }] : /* istanbul ignore next */ []));
    itemToString = input((item) => String(item), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "itemToString" }] : /* istanbul ignore next */ []));
    isItemEqualToValue = input((a, b) => Object.is(a, b), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isItemEqualToValue" }] : /* istanbul ignore next */ []));
    labels = signal(new Map(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "labels" }] : /* istanbul ignore next */ []));
    portalTemplate = contentChild(CrsdComboboxPortal, { ...(ngDevMode ? { debugName: "portalTemplate" } : /* istanbul ignore next */ {}), read: TemplateRef });
    triggerRef = contentChild(CrsdComboboxTriggerHost, { ...(ngDevMode ? { debugName: "triggerRef" } : /* istanbul ignore next */ {}), read: ElementRef });
    overlayService = inject(CrsdOverlayService);
    viewContainer = inject(ViewContainerRef);
    destroyRef = inject(DestroyRef);
    overlayRef = null;
    outsideClickSub = null;
    constructor() {
        effect(() => {
            const opts = this.options();
            if (!opts) {
                return;
            }
            for (const option of normalizeOptions(opts)) {
                this.registerItemLabel(option.value, option.label);
            }
        });
        effect(() => {
            if (this.state() === 'open' && !this.disabled()) {
                this.openOverlay();
            }
            else {
                this.closeOverlay();
            }
        });
        fromEvent(document, 'keydown')
            .pipe(filter$1(() => this.state() === 'open'), takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            if (event.key === 'Escape') {
                this.state.set('closed');
            }
        });
    }
    toggle() {
        if (this.disabled()) {
            return;
        }
        this.state.set(this.state() === 'open' ? 'closed' : 'open');
    }
    add(item) {
        if (this.containsValue(item)) {
            return;
        }
        const next = [...this.value(), item];
        this.value.set(next);
        this.valueChanged.emit(next);
    }
    remove(item) {
        const next = this.value().filter((v) => !this.isItemEqualToValue()(v, item));
        this.value.set(next);
        this.valueChanged.emit(next);
    }
    containsValue(item) {
        return this.value().some((v) => this.isItemEqualToValue()(v, item));
    }
    itemKey(item) {
        return this.itemToString()(item);
    }
    setFilter(text) {
        this.filter.set(text);
    }
    clearFilter() {
        this.filter.set('');
    }
    registerItemLabel(value, label) {
        const key = this.itemKey(value);
        this.labels.update((labels) => new Map(labels).set(key, label));
    }
    labelFor(value) {
        return this.labels().get(this.itemKey(value)) ?? this.itemToString()(value);
    }
    openOverlay() {
        const template = this.portalTemplate();
        const trigger = this.triggerRef()?.nativeElement;
        if (!template || !trigger || this.overlayRef) {
            return;
        }
        this.overlayRef = this.overlayService.createConnected(trigger, CRSD_CONNECTED_POSITIONS, { panelClass: 'z-modal', hasBackdrop: false, width: trigger.offsetWidth, minWidth: trigger.offsetWidth }, { closeOnEscape: false, scrollStrategy: 'reposition' }, this.destroyRef);
        this.overlayRef.attachPortal(new TemplatePortal(template, this.viewContainer));
        this.overlayRef.setConnectedWidth(trigger.offsetWidth);
        this.outsideClickSub = this.overlayRef.listenPointerDownOutside(trigger, () => this.state.set('closed'));
    }
    closeOverlay() {
        this.outsideClickSub?.unsubscribe();
        this.outsideClickSub = null;
        this.clearFilter();
        this.overlayRef?.close();
        this.overlayRef = null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdCombobox, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.2.0", version: "22.2.3", type: CrsdCombobox, isStandalone: true, selector: "[crsdCombobox]", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, state: { classPropertyName: "state", publicName: "state", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, emptyLabel: { classPropertyName: "emptyLabel", publicName: "emptyLabel", isSignal: true, isRequired: false, transformFunction: null }, itemToString: { classPropertyName: "itemToString", publicName: "itemToString", isSignal: true, isRequired: false, transformFunction: null }, isItemEqualToValue: { classPropertyName: "isItemEqualToValue", publicName: "isItemEqualToValue", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", valueChanged: "valueChanged", state: "stateChange" }, queries: [{ propertyName: "portalTemplate", first: true, predicate: CrsdComboboxPortal, descendants: true, read: TemplateRef, isSignal: true }, { propertyName: "triggerRef", first: true, predicate: CrsdComboboxTriggerHost, descendants: true, read: ElementRef, isSignal: true }], exportAs: ["crsdCombobox"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdCombobox, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdCombobox]',
                    standalone: true,
                    exportAs: 'crsdCombobox',
                }]
        }], ctorParameters: () => [], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], valueChanged: [{ type: i0.Output, args: ["valueChanged"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], state: [{ type: i0.Input, args: [{ isSignal: true, alias: "state", required: false }] }, { type: i0.Output, args: ["stateChange"] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], emptyLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyLabel", required: false }] }], itemToString: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemToString", required: false }] }], isItemEqualToValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "isItemEqualToValue", required: false }] }], portalTemplate: [{ type: i0.ContentChild, args: [i0.forwardRef(() => CrsdComboboxPortal), { ...{ read: TemplateRef }, isSignal: true }] }], triggerRef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => CrsdComboboxTriggerHost), { ...{ read: ElementRef }, isSignal: true }] }] } });

class CrsdComboboxPanel {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(COMBOBOX_PANEL_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxPanel, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdComboboxPanel, isStandalone: true, selector: "[crsdComboboxPanel]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxPanel, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdComboboxPanel]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdComboboxFilter {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(COMBOBOX_FILTER_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxFilter, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdComboboxFilter, isStandalone: true, selector: "[crsdComboboxFilter]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxFilter, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdComboboxFilter]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdComboboxItem {
    staticClass;
    value = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    combobox = inject((CrsdCombobox));
    elementRef = inject((ElementRef));
    constructor(staticClass) {
        this.staticClass = staticClass;
        effect(() => {
            const label = this.elementRef.nativeElement.textContent?.trim() ?? String(this.value());
            this.combobox.registerItemLabel(this.value(), label);
        });
    }
    selected = computed(() => this.combobox.containsValue(this.value()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selected" }] : /* istanbul ignore next */ []));
    filteredOut = computed(() => {
        const query = this.combobox.filter().trim().toLowerCase();
        if (!query) {
            return false;
        }
        const label = this.elementRef.nativeElement.textContent?.trim().toLowerCase() ?? '';
        return !label.includes(query);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filteredOut" }] : /* istanbul ignore next */ []));
    isFilteredOut() {
        return this.filteredOut();
    }
    hostClasses = computed(() => cn(COMBOBOX_ITEM_BASE, {
        [COMBOBOX_ITEM_SELECTED]: this.selected(),
        'bg-muted font-medium': this.selected(),
    }, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    toggle() {
        if (this.disabled()) {
            return;
        }
        if (this.selected()) {
            this.combobox.remove(this.value());
        }
        else {
            this.combobox.add(this.value());
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxItem, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdComboboxItem, isStandalone: true, selector: "[crsdComboboxItem]", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "option" }, listeners: { "click": "toggle()" }, properties: { "attr.aria-selected": "selected()", "class": "hostClasses()", "hidden": "filteredOut()", "attr.data-disabled": "disabled() ? true : null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxItem, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdComboboxItem]',
                    standalone: true,
                    host: {
                        role: 'option',
                        '[attr.aria-selected]': 'selected()',
                        '[class]': 'hostClasses()',
                        '[hidden]': 'filteredOut()',
                        '[attr.data-disabled]': 'disabled() ? true : null',
                        '(click)': 'toggle()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: true }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdComboboxEmpty {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    combobox = inject(CrsdCombobox);
    content = inject(CrsdComboboxContent);
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    shouldHide = computed(() => {
        const query = this.combobox.filter().trim();
        if (!query) {
            return true;
        }
        return this.content.hasVisibleItems();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "shouldHide" }] : /* istanbul ignore next */ []));
    hostClasses = computed(() => cn(COMBOBOX_EMPTY_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxEmpty, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdComboboxEmpty, isStandalone: true, selector: "[crsdComboboxEmpty]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()", "hidden": "shouldHide()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxEmpty, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdComboboxEmpty]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                        '[hidden]': 'shouldHide()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdComboboxContent {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    options = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "options" }] : /* istanbul ignore next */ []));
    emptyLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "emptyLabel" }] : /* istanbul ignore next */ []));
    combobox = inject((CrsdCombobox));
    items = contentChildren(CrsdComboboxItem, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    constructor(staticClass) {
        this.staticClass = staticClass;
        effect(() => {
            const opts = this.resolvedOptions();
            if (!opts) {
                return;
            }
            for (const option of normalizeOptions(opts)) {
                this.combobox.registerItemLabel(option.value, option.label);
            }
        });
    }
    resolvedOptions = computed(() => this.options() ?? this.combobox.options(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "resolvedOptions" }] : /* istanbul ignore next */ []));
    resolvedEmptyLabel = computed(() => this.emptyLabel() ?? this.combobox.emptyLabel(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "resolvedEmptyLabel" }] : /* istanbul ignore next */ []));
    visibleOptions = computed(() => {
        const opts = this.resolvedOptions();
        if (opts === undefined) {
            return [];
        }
        const normalized = normalizeOptions(opts);
        const query = this.combobox.filter().trim().toLowerCase();
        if (!query) {
            return normalized;
        }
        return normalized.filter((option) => option.label.toLowerCase().includes(query));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visibleOptions" }] : /* istanbul ignore next */ []));
    hasVisibleItems = computed(() => {
        if (this.resolvedOptions() !== undefined) {
            return this.visibleOptions().length > 0;
        }
        return this.items().some((item) => !item.isFilteredOut());
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasVisibleItems" }] : /* istanbul ignore next */ []));
    hostClasses = computed(() => cn(COMBOBOX_CONTENT_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxContent, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.2.3", type: CrsdComboboxContent, isStandalone: true, selector: "[crsdComboboxContent]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, emptyLabel: { classPropertyName: "emptyLabel", publicName: "emptyLabel", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "listbox" }, properties: { "class": "hostClasses()" } }, queries: [{ propertyName: "items", predicate: CrsdComboboxItem, isSignal: true }], ngImport: i0, template: `
    @if (resolvedOptions(); as opts) {
      @for (option of visibleOptions(); track option.value) {
        <li crsdComboboxItem [value]="option.value" [disabled]="option.disabled ?? false">
          {{ option.label }}
        </li>
      }
      @if (resolvedEmptyLabel()) {
        <li crsdComboboxEmpty>{{ resolvedEmptyLabel() }}</li>
      }
    } @else {
      <ng-content />
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: CrsdComboboxItem, selector: "[crsdComboboxItem]", inputs: ["value", "disabled", "class"] }, { kind: "directive", type: CrsdComboboxEmpty, selector: "[crsdComboboxEmpty]", inputs: ["class"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxContent, decorators: [{
            type: Component,
            args: [{
                    selector: '[crsdComboboxContent]',
                    standalone: true,
                    imports: [CrsdComboboxItem, CrsdComboboxEmpty],
                    host: {
                        role: 'listbox',
                        '[class]': 'hostClasses()',
                    },
                    template: `
    @if (resolvedOptions(); as opts) {
      @for (option of visibleOptions(); track option.value) {
        <li crsdComboboxItem [value]="option.value" [disabled]="option.disabled ?? false">
          {{ option.label }}
        </li>
      }
      @if (resolvedEmptyLabel()) {
        <li crsdComboboxEmpty>{{ resolvedEmptyLabel() }}</li>
      }
    } @else {
      <ng-content />
    }
  `,
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], emptyLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyLabel", required: false }] }], items: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => CrsdComboboxItem), { isSignal: true }] }] } });
class CrsdComboboxInput {
    combobox = inject(CrsdCombobox);
    onInput(event) {
        this.combobox.setFilter(event.target.value);
        this.combobox.state.set('open');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxInput, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdComboboxInput, isStandalone: true, selector: "[crsdComboboxInput]", host: { listeners: { "click": "$event.stopPropagation()", "input": "onInput($event)", "keydown.escape": "combobox.state.set(\"closed\")" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxInput, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdComboboxInput]',
                    standalone: true,
                    host: {
                        '(click)': '$event.stopPropagation()',
                        '(input)': 'onInput($event)',
                        '(keydown.escape)': 'combobox.state.set("closed")',
                    },
                }]
        }] });
class CrsdComboboxChipInput {
    combobox = inject(CrsdCombobox);
    onInput(event) {
        this.combobox.setFilter(event.target.value);
        this.combobox.state.set('open');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxChipInput, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdComboboxChipInput, isStandalone: true, selector: "[crsdComboboxChipInput]", host: { listeners: { "click": "$event.stopPropagation()", "input": "onInput($event)", "keydown.escape": "combobox.state.set(\"closed\")" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxChipInput, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdComboboxChipInput]',
                    standalone: true,
                    host: {
                        '(click)': '$event.stopPropagation()',
                        '(input)': 'onInput($event)',
                        '(keydown.escape)': 'combobox.state.set("closed")',
                    },
                }]
        }] });

class CrsdComboboxTrigger {
    staticClass;
    combobox = inject(CrsdCombobox);
    placeholder = input('Select…', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    custom = input(false, { ...(ngDevMode ? { debugName: "custom" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    valuesTemplateRef = contentChild(CrsdComboboxValues, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "valuesTemplateRef" }] : /* istanbul ignore next */ []));
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(COMBOBOX_TRIGGER_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    valuesTemplate = computed(() => this.valuesTemplateRef() ?? null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "valuesTemplate" }] : /* istanbul ignore next */ []));
    removeItem(item) {
        this.combobox.remove(item);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxTrigger, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.2.3", type: CrsdComboboxTrigger, isStandalone: true, selector: "[crsdComboboxTrigger]", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, custom: { classPropertyName: "custom", publicName: "custom", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "combobox" }, listeners: { "click": "combobox.toggle()" }, properties: { "attr.aria-expanded": "combobox.state() === \"open\"", "class": "hostClasses()" } }, queries: [{ propertyName: "valuesTemplateRef", first: true, predicate: CrsdComboboxValues, descendants: true, isSignal: true }], hostDirectives: [{ directive: CrsdComboboxTriggerHost }], ngImport: i0, template: `
    @if (custom()) {
      <ng-content />
    } @else if (valuesTemplate()) {
      @if (combobox.value().length === 0) {
        <span class="text-muted-foreground">{{ placeholder() }}</span>
      } @else {
        @for (item of combobox.value(); track combobox.itemKey(item)) {
          <ng-container
            *ngTemplateOutlet="
              valuesTemplate()!.templateRef;
              context: {
                $implicit: item,
                label: combobox.labelFor(item),
                remove: removeItem.bind(this, item),
              }
            "
          />
        }
      }
      <crsd-icon name="chevron-down" class="ml-auto opacity-50" />
    } @else {
      @if (combobox.value().length === 0) {
        <span class="text-muted-foreground">{{ placeholder() }}</span>
      } @else {
        @for (item of combobox.value(); track combobox.itemKey(item)) {
          <span crsdComboboxChip class="gap-0 py-0 pl-1.5 pr-0">
            {{ combobox.labelFor(item) }}
            <button
              crsdBadgeDismiss
              [removeLabel]="'Remove ' + combobox.labelFor(item)"
              (dismiss)="removeItem(item)"
            ></button>
          </span>
        }
      }
      <crsd-icon name="chevron-down" class="ml-auto opacity-50" />
    }
  `, isInline: true, dependencies: [{ kind: "component", type: CrsdBadgeDismiss, selector: "button[crsdBadgeDismiss]", inputs: ["removeLabel", "variant", "color", "size", "disabled"], outputs: ["dismiss"] }, { kind: "directive", type: CrsdComboboxChip, selector: "[crsdComboboxChip]", inputs: ["class"] }, { kind: "component", type: CrsdIcon, selector: "crsd-icon", inputs: ["name", "size", "strokeWidth", "spin", "label", "class"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxTrigger, decorators: [{
            type: Component,
            args: [{
                    selector: '[crsdComboboxTrigger]',
                    standalone: true,
                    imports: [CrsdBadgeDismiss, CrsdComboboxChip, CrsdIcon, NgTemplateOutlet],
                    hostDirectives: [CrsdComboboxTriggerHost],
                    host: {
                        role: 'combobox',
                        '[attr.aria-expanded]': 'combobox.state() === "open"',
                        '[class]': 'hostClasses()',
                        '(click)': 'combobox.toggle()',
                    },
                    template: `
    @if (custom()) {
      <ng-content />
    } @else if (valuesTemplate()) {
      @if (combobox.value().length === 0) {
        <span class="text-muted-foreground">{{ placeholder() }}</span>
      } @else {
        @for (item of combobox.value(); track combobox.itemKey(item)) {
          <ng-container
            *ngTemplateOutlet="
              valuesTemplate()!.templateRef;
              context: {
                $implicit: item,
                label: combobox.labelFor(item),
                remove: removeItem.bind(this, item),
              }
            "
          />
        }
      }
      <crsd-icon name="chevron-down" class="ml-auto opacity-50" />
    } @else {
      @if (combobox.value().length === 0) {
        <span class="text-muted-foreground">{{ placeholder() }}</span>
      } @else {
        @for (item of combobox.value(); track combobox.itemKey(item)) {
          <span crsdComboboxChip class="gap-0 py-0 pl-1.5 pr-0">
            {{ combobox.labelFor(item) }}
            <button
              crsdBadgeDismiss
              [removeLabel]="'Remove ' + combobox.labelFor(item)"
              (dismiss)="removeItem(item)"
            ></button>
          </span>
        }
      }
      <crsd-icon name="chevron-down" class="ml-auto opacity-50" />
    }
  `,
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], custom: [{ type: i0.Input, args: [{ isSignal: true, alias: "custom", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], valuesTemplateRef: [{ type: i0.ContentChild, args: [i0.forwardRef(() => CrsdComboboxValues), { isSignal: true }] }] } });

class CrsdComboboxComponent {
    value = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    options = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    placeholder = input('Select…', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    filterPlaceholder = input('Filter…', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterPlaceholder" }] : /* istanbul ignore next */ []));
    emptyLabel = input('No results found', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyLabel" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    hostClasses = computed(() => cn('block', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.2.3", type: CrsdComboboxComponent, isStandalone: true, selector: "crsd-combobox", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, filterPlaceholder: { classPropertyName: "filterPlaceholder", publicName: "filterPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, emptyLabel: { classPropertyName: "emptyLabel", publicName: "emptyLabel", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0, template: `
    <div
      crsdCombobox
      [(value)]="value"
      [options]="options()"
      [emptyLabel]="emptyLabel()"
      [disabled]="disabled()"
    >
      <div crsdComboboxTrigger [placeholder]="placeholder()"></div>
      <ng-template crsdComboboxPortal>
        <div crsdComboboxPanel>
          <div crsdComboboxFilter>
            <input
              crsdComboboxInput
              crsdInput
              class="h-8 w-full"
              [placeholder]="filterPlaceholder()"
            />
          </div>
          <ul crsdComboboxContent></ul>
        </div>
      </ng-template>
    </div>
  `, isInline: true, dependencies: [{ kind: "directive", type: CrsdCombobox, selector: "[crsdCombobox]", inputs: ["value", "disabled", "state", "options", "emptyLabel", "itemToString", "isItemEqualToValue"], outputs: ["valueChange", "valueChanged", "stateChange"], exportAs: ["crsdCombobox"] }, { kind: "component", type: CrsdComboboxTrigger, selector: "[crsdComboboxTrigger]", inputs: ["placeholder", "custom", "class"] }, { kind: "directive", type: CrsdComboboxPortal, selector: "[crsdComboboxPortal]" }, { kind: "directive", type: CrsdComboboxPanel, selector: "[crsdComboboxPanel]", inputs: ["class"] }, { kind: "directive", type: CrsdComboboxFilter, selector: "[crsdComboboxFilter]", inputs: ["class"] }, { kind: "directive", type: CrsdComboboxInput, selector: "[crsdComboboxInput]" }, { kind: "component", type: CrsdComboboxContent, selector: "[crsdComboboxContent]", inputs: ["class", "options", "emptyLabel"] }, { kind: "directive", type: CrsdInput, selector: "[crsdInput]", inputs: ["value", "disabled", "readonly", "invalid", "class"], outputs: ["valueChange"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdComboboxComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'crsd-combobox',
                    standalone: true,
                    imports: [
                        CrsdCombobox,
                        CrsdComboboxTrigger,
                        CrsdComboboxPortal,
                        CrsdComboboxPanel,
                        CrsdComboboxFilter,
                        CrsdComboboxInput,
                        CrsdComboboxContent,
                        CrsdInput,
                    ],
                    host: {
                        '[class]': 'hostClasses()',
                    },
                    template: `
    <div
      crsdCombobox
      [(value)]="value"
      [options]="options()"
      [emptyLabel]="emptyLabel()"
      [disabled]="disabled()"
    >
      <div crsdComboboxTrigger [placeholder]="placeholder()"></div>
      <ng-template crsdComboboxPortal>
        <div crsdComboboxPanel>
          <div crsdComboboxFilter>
            <input
              crsdComboboxInput
              crsdInput
              class="h-8 w-full"
              [placeholder]="filterPlaceholder()"
            />
          </div>
          <ul crsdComboboxContent></ul>
        </div>
      </ng-template>
    </div>
  `,
                }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: true }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], filterPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterPlaceholder", required: false }] }], emptyLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyLabel", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

class CrsdSidebarService {
    state = signal('expanded', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    toggleSidebar() {
        this.state.update((current) => (current === 'expanded' ? 'collapsed' : 'expanded'));
    }
    expand() {
        this.state.set('expanded');
    }
    collapse() {
        this.state.set('collapsed');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const SIDEBAR_BASE = 'flex h-full w-[var(--crsd-sidebar-width)] flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground transition-[width] duration-200 ease-linear';
const SIDEBAR_WRAPPER_BASE = 'flex min-h-svh w-full';
const SIDEBAR_HEADER_BASE = 'flex flex-col gap-2 p-2';
const SIDEBAR_CONTENT_BASE = 'flex flex-1 flex-col gap-2 overflow-auto p-2';
const SIDEBAR_FOOTER_BASE = 'flex flex-col gap-2 p-2';
const SIDEBAR_MENU_BASE = 'flex w-full min-w-0 flex-col gap-1';
const SIDEBAR_MENU_ITEM_BASE = 'group/menu-item relative';
const SIDEBAR_MENU_BUTTON_BASE = 'flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm outline-none hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 focus-visible:ring-sidebar-ring disabled:pointer-events-none disabled:opacity-50';
const SIDEBAR_WIDTH_EXPANDED = '16rem';
const SIDEBAR_WIDTH_COLLAPSED = '3rem';

class CrsdSidebarWrapper {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    sidebarContainerClass = input('', { ...(ngDevMode ? { debugName: "sidebarContainerClass" } : /* istanbul ignore next */ {}), alias: 'sidebarContainerClass' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(SIDEBAR_WRAPPER_BASE, this.staticClass, this.userClass(), this.sidebarContainerClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarWrapper, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSidebarWrapper, isStandalone: true, selector: "[crsdSidebarWrapper]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null }, sidebarContainerClass: { classPropertyName: "sidebarContainerClass", publicName: "sidebarContainerClass", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarWrapper, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSidebarWrapper]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], sidebarContainerClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "sidebarContainerClass", required: false }] }] } });
class CrsdSidebar {
    staticClass;
    collapsible = input('none', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "collapsible" }] : /* istanbul ignore next */ []));
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    sidebarService = inject(CrsdSidebarService);
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    effectiveState = computed(() => {
        if (this.collapsible() === 'none') {
            return 'expanded';
        }
        return this.sidebarService.state();
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "effectiveState" }] : /* istanbul ignore next */ []));
    sidebarWidth = computed(() => this.effectiveState() === 'collapsed' ? SIDEBAR_WIDTH_COLLAPSED : SIDEBAR_WIDTH_EXPANDED, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sidebarWidth" }] : /* istanbul ignore next */ []));
    hostClasses = computed(() => cn(SIDEBAR_BASE, { 'overflow-hidden': this.effectiveState() === 'collapsed' }, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebar, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSidebar, isStandalone: true, selector: "[crsdSidebar]", inputs: { collapsible: { classPropertyName: "collapsible", publicName: "collapsible", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()", "style.--crsd-sidebar-width": "sidebarWidth()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebar, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSidebar]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                        '[style.--crsd-sidebar-width]': 'sidebarWidth()',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { collapsible: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapsible", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdSidebarHeader {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(SIDEBAR_HEADER_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarHeader, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSidebarHeader, isStandalone: true, selector: "[crsdSidebarHeader]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarHeader, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSidebarHeader]',
                    standalone: true,
                    host: { '[class]': 'hostClasses()' },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdSidebarContent {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(SIDEBAR_CONTENT_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarContent, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSidebarContent, isStandalone: true, selector: "[crsdSidebarContent]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarContent, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSidebarContent]',
                    standalone: true,
                    host: { '[class]': 'hostClasses()' },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdSidebarFooter {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(SIDEBAR_FOOTER_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarFooter, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSidebarFooter, isStandalone: true, selector: "[crsdSidebarFooter]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarFooter, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSidebarFooter]',
                    standalone: true,
                    host: { '[class]': 'hostClasses()' },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdSidebarMenu {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    sidebarService = inject(CrsdSidebarService);
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(SIDEBAR_MENU_BASE, { 'items-center': this.sidebarService.state() === 'collapsed' }, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarMenu, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSidebarMenu, isStandalone: true, selector: "[crsdSidebarMenu]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarMenu, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSidebarMenu]',
                    standalone: true,
                    host: { '[class]': 'hostClasses()' },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdSidebarMenuItem {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    hostClasses = computed(() => cn(SIDEBAR_MENU_ITEM_BASE, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarMenuItem, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSidebarMenuItem, isStandalone: true, selector: "[crsdSidebarMenuItem]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarMenuItem, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSidebarMenuItem]',
                    standalone: true,
                    host: { '[class]': 'hostClasses()' },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });
class CrsdSidebarMenuLabel {
    sidebarService = inject(CrsdSidebarService);
    isCollapsed = computed(() => this.sidebarService.state() === 'collapsed', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isCollapsed" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarMenuLabel, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.2.3", type: CrsdSidebarMenuLabel, isStandalone: true, selector: "[crsdSidebarMenuLabel]", host: { properties: { "class.hidden": "isCollapsed()" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarMenuLabel, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSidebarMenuLabel]',
                    standalone: true,
                    host: {
                        '[class.hidden]': 'isCollapsed()',
                    },
                }]
        }] });
class CrsdSidebarMenuButton {
    staticClass;
    tooltip = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltip" }] : /* istanbul ignore next */ []));
    isActive = input(false, { ...(ngDevMode ? { debugName: "isActive" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    sidebarService = inject(CrsdSidebarService);
    elementRef = inject((ElementRef));
    overlayService = inject(CrsdOverlayService);
    idService = inject(CrsdIdService);
    destroyRef = inject(DestroyRef);
    overlayRef = null;
    constructor(staticClass) {
        this.staticClass = staticClass;
        const host = this.elementRef.nativeElement;
        merge(fromEvent(host, 'mouseenter'), fromEvent(host, 'focusin'))
            .pipe(filter$1(() => this.isCollapsed() && !!this.tooltip()), switchMap(() => timer(300)), takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.openTooltip());
        merge(fromEvent(host, 'mouseleave'), fromEvent(host, 'focusout'))
            .pipe(switchMap(() => timer(0)), takeUntilDestroyed(this.destroyRef))
            .subscribe(() => this.closeTooltip());
    }
    isCollapsed = computed(() => this.sidebarService.state() === 'collapsed', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isCollapsed" }] : /* istanbul ignore next */ []));
    hostClasses = computed(() => cn(SIDEBAR_MENU_BUTTON_BASE, {
        'size-8 shrink-0 justify-center p-2': this.isCollapsed(),
    }, this.staticClass, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    openTooltip() {
        if (this.overlayRef || !this.isCollapsed() || !this.tooltip()) {
            return;
        }
        this.overlayRef = this.overlayService.createConnected(this.elementRef.nativeElement, CRSD_CONNECTED_POSITIONS, { panelClass: 'z-tooltip', hasBackdrop: false }, { closeOnEscape: false }, this.destroyRef);
        const el = document.createElement('div');
        el.setAttribute('role', 'tooltip');
        el.className = TOOLTIP_CONTENT_BASE;
        applyTooltipContentStyles(el);
        el.textContent = this.tooltip();
        this.overlayRef.attachDomElement(el);
        this.overlayRef.overlayElement.style.pointerEvents = 'none';
        this.overlayRef.updatePosition();
    }
    closeTooltip() {
        this.overlayRef?.close();
        this.overlayRef = null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarMenuButton, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdSidebarMenuButton, isStandalone: true, selector: "[crsdSidebarMenuButton]", inputs: { tooltip: { classPropertyName: "tooltip", publicName: "tooltip", isSignal: true, isRequired: false, transformFunction: null }, isActive: { classPropertyName: "isActive", publicName: "isActive", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()", "attr.data-collapsed": "isCollapsed() ? true : null", "attr.data-active": "isActive() ? \"true\" : null", "attr.aria-current": "isActive() ? \"page\" : null", "attr.aria-label": "isCollapsed() && tooltip() ? tooltip() : null" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSidebarMenuButton, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdSidebarMenuButton]',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                        '[attr.data-collapsed]': 'isCollapsed() ? true : null',
                        '[attr.data-active]': 'isActive() ? "true" : null',
                        '[attr.aria-current]': 'isActive() ? "page" : null',
                        '[attr.aria-label]': 'isCollapsed() && tooltip() ? tooltip() : null',
                    },
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { tooltip: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltip", required: false }] }], isActive: [{ type: i0.Input, args: [{ isSignal: true, alias: "isActive", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

class CrsdIconMultiselect {
    label = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    labelId = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "labelId" }] : /* istanbul ignore next */ []));
    placeholder = input('Filter…', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    emptyLabel = input('No matches.', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyLabel" }] : /* istanbul ignore next */ []));
    options = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    value = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    hostClasses = computed(() => cn('block w-full', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    itemToString = (option) => option.key;
    isItemEqualToValue = (a, b) => a.key === b.key;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdIconMultiselect, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.2.3", type: CrsdIconMultiselect, isStandalone: true, selector: "crsd-icon-multiselect", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, labelId: { classPropertyName: "labelId", publicName: "labelId", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, emptyLabel: { classPropertyName: "emptyLabel", publicName: "emptyLabel", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange" }, host: { attributes: { "role": "group" }, properties: { "class": "hostClasses()", "attr.aria-labelledby": "labelId() || null" } }, ngImport: i0, template: `
    @if (label()) {
      <span [id]="labelId()" class="mb-2 block text-sm font-medium">{{ label() }}</span>
    }

    <div
      crsdCombobox
      class="w-full"
      [(value)]="value"
      [options]="options()"
      [disabled]="disabled()"
      [itemToString]="itemToString"
      [isItemEqualToValue]="isItemEqualToValue"
    >
      <div crsdComboboxTrigger [custom]="true" class="flex min-h-10 w-full flex-wrap items-center gap-1.5">
        @for (option of value(); track option.key) {
          <span crsdComboboxChip>
            <span class="inline-flex min-w-0 items-center gap-2">
              <img
                [src]="option.iconUrl"
                alt=""
                class="size-[22px] shrink-0 rounded-full object-cover"
                [style.box-shadow]="
                  option.accent ? 'inset 0 0 0 2px ' + option.accent : null
                "
              />
              <span class="truncate">{{ option.name }}</span>
            </span>
          </span>
        }
        <input
          crsdComboboxChipInput
          class="min-w-[120px] flex-1 border-0 bg-transparent p-0 text-sm outline-none"
          [placeholder]="placeholder()"
          [attr.aria-label]="label() || placeholder()"
        />
      </div>

      <ng-template crsdComboboxPortal>
        <ul crsdComboboxContent [emptyLabel]="emptyLabel()">
          @for (option of options(); track option.key) {
            <li crsdComboboxItem [value]="option">
              <span class="inline-flex min-w-0 items-center gap-2">
                <img
                  [src]="option.iconUrl"
                  alt=""
                  class="size-[22px] shrink-0 rounded-full object-cover"
                  [style.box-shadow]="
                    option.accent ? 'inset 0 0 0 2px ' + option.accent : null
                  "
                  loading="lazy"
                />
                <span class="truncate">{{ option.name }}</span>
              </span>
            </li>
          }
        </ul>
      </ng-template>
    </div>
  `, isInline: true, dependencies: [{ kind: "directive", type: CrsdCombobox, selector: "[crsdCombobox]", inputs: ["value", "disabled", "state", "options", "emptyLabel", "itemToString", "isItemEqualToValue"], outputs: ["valueChange", "valueChanged", "stateChange"], exportAs: ["crsdCombobox"] }, { kind: "component", type: CrsdComboboxTrigger, selector: "[crsdComboboxTrigger]", inputs: ["placeholder", "custom", "class"] }, { kind: "directive", type: CrsdComboboxChip, selector: "[crsdComboboxChip]", inputs: ["class"] }, { kind: "directive", type: CrsdComboboxChipInput, selector: "[crsdComboboxChipInput]" }, { kind: "directive", type: CrsdComboboxPortal, selector: "[crsdComboboxPortal]" }, { kind: "component", type: CrsdComboboxContent, selector: "[crsdComboboxContent]", inputs: ["class", "options", "emptyLabel"] }, { kind: "directive", type: CrsdComboboxItem, selector: "[crsdComboboxItem]", inputs: ["value", "disabled", "class"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdIconMultiselect, decorators: [{
            type: Component,
            args: [{
                    selector: 'crsd-icon-multiselect',
                    standalone: true,
                    imports: [
                        CrsdCombobox,
                        CrsdComboboxTrigger,
                        CrsdComboboxChip,
                        CrsdComboboxChipInput,
                        CrsdComboboxPortal,
                        CrsdComboboxContent,
                        CrsdComboboxItem,
                    ],
                    host: {
                        '[class]': 'hostClasses()',
                        role: 'group',
                        '[attr.aria-labelledby]': 'labelId() || null',
                    },
                    template: `
    @if (label()) {
      <span [id]="labelId()" class="mb-2 block text-sm font-medium">{{ label() }}</span>
    }

    <div
      crsdCombobox
      class="w-full"
      [(value)]="value"
      [options]="options()"
      [disabled]="disabled()"
      [itemToString]="itemToString"
      [isItemEqualToValue]="isItemEqualToValue"
    >
      <div crsdComboboxTrigger [custom]="true" class="flex min-h-10 w-full flex-wrap items-center gap-1.5">
        @for (option of value(); track option.key) {
          <span crsdComboboxChip>
            <span class="inline-flex min-w-0 items-center gap-2">
              <img
                [src]="option.iconUrl"
                alt=""
                class="size-[22px] shrink-0 rounded-full object-cover"
                [style.box-shadow]="
                  option.accent ? 'inset 0 0 0 2px ' + option.accent : null
                "
              />
              <span class="truncate">{{ option.name }}</span>
            </span>
          </span>
        }
        <input
          crsdComboboxChipInput
          class="min-w-[120px] flex-1 border-0 bg-transparent p-0 text-sm outline-none"
          [placeholder]="placeholder()"
          [attr.aria-label]="label() || placeholder()"
        />
      </div>

      <ng-template crsdComboboxPortal>
        <ul crsdComboboxContent [emptyLabel]="emptyLabel()">
          @for (option of options(); track option.key) {
            <li crsdComboboxItem [value]="option">
              <span class="inline-flex min-w-0 items-center gap-2">
                <img
                  [src]="option.iconUrl"
                  alt=""
                  class="size-[22px] shrink-0 rounded-full object-cover"
                  [style.box-shadow]="
                    option.accent ? 'inset 0 0 0 2px ' + option.accent : null
                  "
                  loading="lazy"
                />
                <span class="truncate">{{ option.name }}</span>
              </span>
            </li>
          }
        </ul>
      </ng-template>
    </div>
  `,
                }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], labelId: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelId", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], emptyLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyLabel", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: true }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }, { type: i0.Output, args: ["valueChange"] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

class CrsdSearchPicker {
    options = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    selectedId = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedId" }] : /* istanbul ignore next */ []));
    placeholder = input('Search…', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    emptyLabel = input('— Empty —', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyLabel" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    elementRef = inject((ElementRef));
    open = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []));
    query = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []));
    panelAbove = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelAbove" }] : /* istanbul ignore next */ []));
    panelMaxHeight = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelMaxHeight" }] : /* istanbul ignore next */ []));
    listMaxHeight = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "listMaxHeight" }] : /* istanbul ignore next */ []));
    panelTop = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelTop" }] : /* istanbul ignore next */ []));
    panelLeft = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelLeft" }] : /* istanbul ignore next */ []));
    panelWidth = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelWidth" }] : /* istanbul ignore next */ []));
    static VIEWPORT_EDGE_PADDING_PX = 16;
    static PANEL_GAP_PX = 4;
    static PANEL_CHROME_PX = 72;
    static DEFAULT_LIST_MAX_HEIGHT_PX = 240;
    hostClasses = computed(() => cn('relative block w-full', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    selectedOption = computed(() => {
        const id = this.selectedId();
        if (id == null) {
            return null;
        }
        return this.options().find((option) => option.id === id) ?? null;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedOption" }] : /* istanbul ignore next */ []));
    filteredOptions = computed(() => {
        const q = this.query().trim().toLowerCase();
        const list = this.options();
        if (!q) {
            return list;
        }
        return list.filter((option) => option.label.toLowerCase().includes(q));
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filteredOptions" }] : /* istanbul ignore next */ []));
    constructor() {
        effect((onCleanup) => {
            if (!this.open()) {
                return;
            }
            const listener = (event) => this.onDocumentScroll(event);
            document.addEventListener('scroll', listener, true);
            onCleanup(() => document.removeEventListener('scroll', listener, true));
        });
    }
    toggleOpen(event) {
        event.stopPropagation();
        if (this.disabled()) {
            return;
        }
        this.open.update((value) => !value);
        if (this.open()) {
            this.query.set('');
            queueMicrotask(() => this.updatePanelLayout());
        }
        else {
            this.resetPanelLayout();
        }
    }
    selectOption(id, event) {
        event.stopPropagation();
        this.selectedId.set(id);
        this.close();
    }
    close() {
        this.open.set(false);
        this.query.set('');
        this.resetPanelLayout();
    }
    onQueryInput(event) {
        this.query.set(event.target.value);
    }
    onDocumentClick(event) {
        if (!this.open()) {
            return;
        }
        const target = event.target;
        if (target && !this.elementRef.nativeElement.contains(target)) {
            this.close();
        }
    }
    onDocumentScroll(event) {
        if (!this.open()) {
            return;
        }
        const target = event.target;
        if (target instanceof Node && this.elementRef.nativeElement.contains(target)) {
            return;
        }
        this.close();
    }
    updatePanelLayout() {
        const trigger = this.elementRef.nativeElement.querySelector('button');
        if (!trigger) {
            return;
        }
        const rect = trigger.getBoundingClientRect();
        const edgePadding = CrsdSearchPicker.VIEWPORT_EDGE_PADDING_PX;
        const gap = CrsdSearchPicker.PANEL_GAP_PX;
        const chrome = CrsdSearchPicker.PANEL_CHROME_PX;
        const defaultListMax = CrsdSearchPicker.DEFAULT_LIST_MAX_HEIGHT_PX;
        const spaceBelow = window.innerHeight - rect.bottom - gap - edgePadding;
        const spaceAbove = rect.top - gap - edgePadding;
        const openAbove = spaceBelow < 180 && spaceAbove > spaceBelow;
        const availableSpace = Math.max(120, openAbove ? spaceAbove : spaceBelow);
        const panelMaxHeight = Math.min(320, availableSpace);
        const listMaxHeight = Math.max(80, Math.min(defaultListMax, panelMaxHeight - chrome));
        this.panelAbove.set(openAbove);
        this.panelMaxHeight.set(panelMaxHeight);
        this.listMaxHeight.set(listMaxHeight);
        this.panelLeft.set(rect.left);
        this.panelWidth.set(rect.width);
        this.panelTop.set(Math.max(edgePadding, openAbove ? rect.top - gap - panelMaxHeight : rect.bottom + gap));
    }
    resetPanelLayout() {
        this.panelAbove.set(false);
        this.panelMaxHeight.set(null);
        this.listMaxHeight.set(null);
        this.panelTop.set(null);
        this.panelLeft.set(null);
        this.panelWidth.set(null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSearchPicker, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.2.3", type: CrsdSearchPicker, isStandalone: true, selector: "crsd-search-picker", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, selectedId: { classPropertyName: "selectedId", publicName: "selectedId", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, emptyLabel: { classPropertyName: "emptyLabel", publicName: "emptyLabel", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectedId: "selectedIdChange" }, host: { listeners: { "document:click": "onDocumentClick($event)", "document:keydown.escape": "close()" }, properties: { "class": "hostClasses()" } }, ngImport: i0, template: `
    <button
      type="button"
      class="flex h-10 w-full items-center gap-2 rounded-md border border-input bg-background px-3 py-2 text-left text-sm transition-colors hover:bg-muted/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
      [disabled]="disabled()"
      [attr.aria-expanded]="open()"
      aria-haspopup="listbox"
      (click)="toggleOpen($event)"
    >
      @if (selectedOption(); as option) {
        @if (option.imageUrl) {
          <img [src]="option.imageUrl" alt="" class="size-7 shrink-0 rounded object-cover" />
        }
        <span class="min-w-0 flex-1 truncate">{{ option.label }}</span>
      } @else {
        <span class="min-w-0 flex-1 truncate text-muted-foreground">{{ emptyLabel() }}</span>
      }
      <crsd-icon name="chevron-down" class="size-4 shrink-0 opacity-50" />
    </button>

    @if (open()) {
      <div
        class="fixed z-modal overflow-hidden rounded-md border border-border bg-popover text-popover-foreground shadow-md"
        [class]="panelAbove() ? 'origin-bottom' : 'origin-top'"
        [style.max-height.px]="panelMaxHeight()"
        [style.top.px]="panelTop()"
        [style.left.px]="panelLeft()"
        [style.width.px]="panelWidth()"
        (click)="$event.stopPropagation()"
      >
        <div class="border-b border-border p-2">
          <input
            crsdInput
            type="search"
            class="h-8 w-full"
            [placeholder]="placeholder()"
            [value]="query()"
            (input)="onQueryInput($event)"
            aria-label="Search options"
          />
        </div>

        <ul
          class="max-h-60 overflow-auto p-1"
          role="listbox"
          aria-label="Options"
          [style.max-height.px]="listMaxHeight()"
        >
          <li role="presentation">
            <button
              type="button"
              class="flex w-full items-center gap-2 rounded-sm px-2 py-1.5 text-left text-sm hover:bg-muted"
              role="option"
              [attr.aria-selected]="selectedId() == null"
              [class.bg-muted]="selectedId() == null"
              (click)="selectOption(null, $event)"
            >
              <span class="text-muted-foreground">{{ emptyLabel() }}</span>
            </button>
          </li>

          @for (option of filteredOptions(); track option.id) {
            <li role="presentation">
              <button
                type="button"
                class="flex w-full items-center gap-2 rounded-sm px-2 py-1.5 text-left text-sm hover:bg-muted"
                role="option"
                [attr.aria-selected]="selectedId() === option.id"
                [class.bg-muted]="selectedId() === option.id"
                (click)="selectOption(option.id, $event)"
              >
                @if (option.imageUrl) {
                  <img [src]="option.imageUrl" alt="" class="size-7 shrink-0 rounded object-cover" />
                }
                <span class="min-w-0 truncate">{{ option.label }}</span>
              </button>
            </li>
          } @empty {
            <li class="px-2 py-6 text-center text-sm text-muted-foreground" role="status">
              No matches.
            </li>
          }
        </ul>
      </div>
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: CrsdInput, selector: "[crsdInput]", inputs: ["value", "disabled", "readonly", "invalid", "class"], outputs: ["valueChange"] }, { kind: "component", type: CrsdIcon, selector: "crsd-icon", inputs: ["name", "size", "strokeWidth", "spin", "label", "class"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSearchPicker, decorators: [{
            type: Component,
            args: [{
                    selector: 'crsd-search-picker',
                    standalone: true,
                    imports: [CrsdInput, CrsdIcon],
                    host: {
                        '[class]': 'hostClasses()',
                        '(document:click)': 'onDocumentClick($event)',
                        '(document:keydown.escape)': 'close()',
                    },
                    template: `
    <button
      type="button"
      class="flex h-10 w-full items-center gap-2 rounded-md border border-input bg-background px-3 py-2 text-left text-sm transition-colors hover:bg-muted/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
      [disabled]="disabled()"
      [attr.aria-expanded]="open()"
      aria-haspopup="listbox"
      (click)="toggleOpen($event)"
    >
      @if (selectedOption(); as option) {
        @if (option.imageUrl) {
          <img [src]="option.imageUrl" alt="" class="size-7 shrink-0 rounded object-cover" />
        }
        <span class="min-w-0 flex-1 truncate">{{ option.label }}</span>
      } @else {
        <span class="min-w-0 flex-1 truncate text-muted-foreground">{{ emptyLabel() }}</span>
      }
      <crsd-icon name="chevron-down" class="size-4 shrink-0 opacity-50" />
    </button>

    @if (open()) {
      <div
        class="fixed z-modal overflow-hidden rounded-md border border-border bg-popover text-popover-foreground shadow-md"
        [class]="panelAbove() ? 'origin-bottom' : 'origin-top'"
        [style.max-height.px]="panelMaxHeight()"
        [style.top.px]="panelTop()"
        [style.left.px]="panelLeft()"
        [style.width.px]="panelWidth()"
        (click)="$event.stopPropagation()"
      >
        <div class="border-b border-border p-2">
          <input
            crsdInput
            type="search"
            class="h-8 w-full"
            [placeholder]="placeholder()"
            [value]="query()"
            (input)="onQueryInput($event)"
            aria-label="Search options"
          />
        </div>

        <ul
          class="max-h-60 overflow-auto p-1"
          role="listbox"
          aria-label="Options"
          [style.max-height.px]="listMaxHeight()"
        >
          <li role="presentation">
            <button
              type="button"
              class="flex w-full items-center gap-2 rounded-sm px-2 py-1.5 text-left text-sm hover:bg-muted"
              role="option"
              [attr.aria-selected]="selectedId() == null"
              [class.bg-muted]="selectedId() == null"
              (click)="selectOption(null, $event)"
            >
              <span class="text-muted-foreground">{{ emptyLabel() }}</span>
            </button>
          </li>

          @for (option of filteredOptions(); track option.id) {
            <li role="presentation">
              <button
                type="button"
                class="flex w-full items-center gap-2 rounded-sm px-2 py-1.5 text-left text-sm hover:bg-muted"
                role="option"
                [attr.aria-selected]="selectedId() === option.id"
                [class.bg-muted]="selectedId() === option.id"
                (click)="selectOption(option.id, $event)"
              >
                @if (option.imageUrl) {
                  <img [src]="option.imageUrl" alt="" class="size-7 shrink-0 rounded object-cover" />
                }
                <span class="min-w-0 truncate">{{ option.label }}</span>
              </button>
            </li>
          } @empty {
            <li class="px-2 py-6 text-center text-sm text-muted-foreground" role="status">
              No matches.
            </li>
          }
        </ul>
      </div>
    }
  `,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: true }] }], selectedId: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedId", required: false }] }, { type: i0.Output, args: ["selectedIdChange"] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], emptyLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyLabel", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

class CrsdAvatarGrid {
    items = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    columns = input(4, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []));
    hostClasses = computed(() => cn('grid gap-4', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    gridTemplateColumns = computed(() => `repeat(${this.columns()}, minmax(0, 1fr))`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "gridTemplateColumns" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdAvatarGrid, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.2.3", type: CrsdAvatarGrid, isStandalone: true, selector: "crsd-avatar-grid", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: true, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "list" }, properties: { "class": "hostClasses()", "style.grid-template-columns": "gridTemplateColumns()" } }, ngImport: i0, template: `
    @for (item of items(); track item.label) {
      <div class="flex flex-col items-center gap-1.5 text-center" role="listitem">
        <img
          [src]="item.imageUrl"
          [alt]="item.label"
          class="size-12 rounded-full object-cover"
          [style.box-shadow]="item.borderColor ? 'inset 0 0 0 2px ' + item.borderColor : null"
        />
        <div class="min-w-0">
          <p class="truncate text-sm font-medium">{{ item.label }}</p>
          @if (item.subtitle) {
            <p class="truncate text-xs text-muted-foreground">{{ item.subtitle }}</p>
          }
        </div>
      </div>
    }
  `, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdAvatarGrid, decorators: [{
            type: Component,
            args: [{
                    selector: 'crsd-avatar-grid',
                    standalone: true,
                    host: {
                        '[class]': 'hostClasses()',
                        '[style.grid-template-columns]': 'gridTemplateColumns()',
                        role: 'list',
                    },
                    template: `
    @for (item of items(); track item.label) {
      <div class="flex flex-col items-center gap-1.5 text-center" role="listitem">
        <img
          [src]="item.imageUrl"
          [alt]="item.label"
          class="size-12 rounded-full object-cover"
          [style.box-shadow]="item.borderColor ? 'inset 0 0 0 2px ' + item.borderColor : null"
        />
        <div class="min-w-0">
          <p class="truncate text-sm font-medium">{{ item.label }}</p>
          @if (item.subtitle) {
            <p class="truncate text-xs text-muted-foreground">{{ item.subtitle }}</p>
          }
        </div>
      </div>
    }
  `,
                }]
        }], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: true }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: false }] }] } });

const FLIP_CARD_HOST = 'group relative block';
const FLIP_CARD_HOST_FLIPPED = 'z-10';
const FLIP_CARD_INNER = 'relative h-full w-full motion-safe:[transform-style:preserve-3d] motion-safe:transition-transform motion-reduce:transition-none';
const FLIP_CARD_INNER_FLIPPED = 'motion-safe:[transform:rotateY(180deg)]';
const FLIP_CARD_FACE = 'absolute inset-0 motion-safe:[backface-visibility:hidden]';
const FLIP_CARD_FACE_FRONT = 'motion-reduce:group-data-[flipped=true]:hidden';
const FLIP_CARD_FACE_BACK = 'motion-safe:[transform:rotateY(180deg)] motion-reduce:hidden motion-reduce:group-data-[flipped=true]:block';
/** Clicks on these inside the card do not trigger flipOnClick. */
const FLIP_CARD_INTERACTIVE_SELECTOR = 'a,button,input,textarea,select,option,summary,label,[role="button"],[role="link"],[contenteditable="true"]';

class CrsdFlipCard {
    flipped = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "flipped" }] : /* istanbul ignore next */ []));
    durationMs = input(500, { ...(ngDevMode ? { debugName: "durationMs" } : /* istanbul ignore next */ {}), alias: 'duration' });
    flipOnClick = input(false, { ...(ngDevMode ? { debugName: "flipOnClick" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    flip() {
        this.flipped.update((value) => !value);
    }
    onHostClick(event) {
        if (!this.flipOnClick()) {
            return;
        }
        const target = event.target;
        if (!(target instanceof Element)) {
            return;
        }
        if (target.closest(FLIP_CARD_INTERACTIVE_SELECTOR)) {
            return;
        }
        this.flip();
    }
    hostClasses = computed(() => cn(FLIP_CARD_HOST, this.flipped() && FLIP_CARD_HOST_FLIPPED, this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    innerClasses = computed(() => cn(FLIP_CARD_INNER, this.flipped() && FLIP_CARD_INNER_FLIPPED), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "innerClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdFlipCard, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.2.3", type: CrsdFlipCard, isStandalone: true, selector: "crsd-flip-card", inputs: { flipped: { classPropertyName: "flipped", publicName: "flipped", isSignal: true, isRequired: false, transformFunction: null }, durationMs: { classPropertyName: "durationMs", publicName: "duration", isSignal: true, isRequired: false, transformFunction: null }, flipOnClick: { classPropertyName: "flipOnClick", publicName: "flipOnClick", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { flipped: "flippedChange" }, host: { listeners: { "click": "onHostClick($event)" }, properties: { "class": "hostClasses()", "style.perspective.px": "1000", "attr.data-flipped": "flipped() ? \"true\" : null" } }, exportAs: ["crsdFlipCard"], ngImport: i0, template: `
    <div
      class="crsd-flip-card__inner"
      [class]="innerClasses()"
      [style.transition-duration.ms]="durationMs()"
    >
      <ng-content select="[crsdFlipCardFront]" />
      <ng-content select="[crsdFlipCardBack]" />
    </div>
  `, isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdFlipCard, decorators: [{
            type: Component,
            args: [{
                    selector: 'crsd-flip-card',
                    standalone: true,
                    exportAs: 'crsdFlipCard',
                    host: {
                        '[class]': 'hostClasses()',
                        '[style.perspective.px]': '1000',
                        '[attr.data-flipped]': 'flipped() ? "true" : null',
                        '(click)': 'onHostClick($event)',
                    },
                    template: `
    <div
      class="crsd-flip-card__inner"
      [class]="innerClasses()"
      [style.transition-duration.ms]="durationMs()"
    >
      <ng-content select="[crsdFlipCardFront]" />
      <ng-content select="[crsdFlipCardBack]" />
    </div>
  `,
                }]
        }], propDecorators: { flipped: [{ type: i0.Input, args: [{ isSignal: true, alias: "flipped", required: false }] }, { type: i0.Output, args: ["flippedChange"] }], durationMs: [{ type: i0.Input, args: [{ isSignal: true, alias: "duration", required: false }] }], flipOnClick: [{ type: i0.Input, args: [{ isSignal: true, alias: "flipOnClick", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

class CrsdFlipCardFront {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    get hostClasses() {
        return cn(FLIP_CARD_FACE, FLIP_CARD_FACE_FRONT, this.staticClass, this.userClass());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdFlipCardFront, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdFlipCardFront, isStandalone: true, selector: "[crsdFlipCardFront]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "this.hostClasses" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdFlipCardFront, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdFlipCardFront]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });
class CrsdFlipCardBack {
    staticClass;
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    constructor(staticClass) {
        this.staticClass = staticClass;
    }
    get hostClasses() {
        return cn(FLIP_CARD_FACE, FLIP_CARD_FACE_BACK, this.staticClass, this.userClass());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdFlipCardBack, deps: [{ token: 'class', attribute: true }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.2.3", type: CrsdFlipCardBack, isStandalone: true, selector: "[crsdFlipCardBack]", inputs: { userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "this.hostClasses" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdFlipCardBack, decorators: [{
            type: Directive,
            args: [{
                    selector: '[crsdFlipCardBack]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['class']
                }] }], propDecorators: { userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], hostClasses: [{
                type: HostBinding,
                args: ['class']
            }] } });

class CrsdSelectableList {
    items = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    selectedIds = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedIds" }] : /* istanbul ignore next */ []));
    selectedId = model(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedId" }] : /* istanbul ignore next */ []));
    multiple = input(false, { ...(ngDevMode ? { debugName: "multiple" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    searchable = input(true, { ...(ngDevMode ? { debugName: "searchable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    placeholder = input('Search…', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    emptyLabel = input('No matches.', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyLabel" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    query = model('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []));
    hostClasses = computed(() => cn('block w-full', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    filteredItems = computed(() => {
        const q = this.query().trim().toLowerCase();
        const list = this.items();
        if (!q) {
            return list;
        }
        return list.filter((item) => {
            const haystack = [item.label, item.subtitle, item.meta, item.badge]
                .filter(Boolean)
                .join(' ')
                .toLowerCase();
            return haystack.includes(q);
        });
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filteredItems" }] : /* istanbul ignore next */ []));
    isSelected(id) {
        if (this.multiple()) {
            return this.selectedIds().includes(id);
        }
        return this.selectedId() === id;
    }
    toggleItem(id) {
        if (this.disabled()) {
            return;
        }
        if (this.multiple()) {
            const current = this.selectedIds();
            this.selectedIds.set(current.includes(id) ? current.filter((value) => value !== id) : [...current, id]);
            return;
        }
        this.selectedId.set(this.selectedId() === id ? null : id);
    }
    onQueryInput(event) {
        this.query.set(event.target.value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectableList, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.2.3", type: CrsdSelectableList, isStandalone: true, selector: "crsd-selectable-list", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: true, transformFunction: null }, selectedIds: { classPropertyName: "selectedIds", publicName: "selectedIds", isSignal: true, isRequired: false, transformFunction: null }, selectedId: { classPropertyName: "selectedId", publicName: "selectedId", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, searchable: { classPropertyName: "searchable", publicName: "searchable", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, emptyLabel: { classPropertyName: "emptyLabel", publicName: "emptyLabel", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null }, query: { classPropertyName: "query", publicName: "query", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectedIds: "selectedIdsChange", selectedId: "selectedIdChange", query: "queryChange" }, host: { attributes: { "role": "group" }, properties: { "class": "hostClasses()" } }, ngImport: i0, template: `
    @if (searchable()) {
      <input
        crsdInput
        type="search"
        class="mb-3 h-9 w-full"
        [placeholder]="placeholder()"
        [value]="query()"
        (input)="onQueryInput($event)"
        aria-label="Search list"
      />
    }

    <ul class="flex max-h-80 flex-col gap-1 overflow-auto" role="listbox" [attr.aria-multiselectable]="multiple()">
      @for (item of filteredItems(); track item.id) {
        <li role="presentation">
          <button
            type="button"
            class="flex w-full items-center gap-3 rounded-md px-2 py-2 text-left text-sm transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            role="option"
            [attr.aria-selected]="isSelected(item.id)"
            [class.bg-muted]="isSelected(item.id)"
            [disabled]="disabled()"
            (click)="toggleItem(item.id)"
          >
            @if (item.imageUrl) {
              <img [src]="item.imageUrl" alt="" class="size-9 shrink-0 rounded-full object-cover" />
            }
            <span class="min-w-0 flex-1">
              <span class="block truncate font-medium">{{ item.label }}</span>
              @if (item.subtitle || item.meta) {
                <span class="block truncate text-xs text-muted-foreground">
                  {{ item.subtitle || item.meta }}
                </span>
              }
            </span>
            @if (item.badge) {
              <span crsdBadge variant="outline" size="sm">{{ item.badge }}</span>
            }
            @if (item.count != null) {
              <span class="text-xs tabular-nums text-muted-foreground">{{ item.count }}</span>
            }
          </button>
        </li>
      } @empty {
        <li class="px-2 py-6 text-center text-sm text-muted-foreground" role="status">
          {{ emptyLabel() }}
        </li>
      }
    </ul>
  `, isInline: true, dependencies: [{ kind: "directive", type: CrsdInput, selector: "[crsdInput]", inputs: ["value", "disabled", "readonly", "invalid", "class"], outputs: ["valueChange"] }, { kind: "directive", type: CrsdBadge, selector: "[crsdBadge]", inputs: ["variant", "color", "size", "class"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdSelectableList, decorators: [{
            type: Component,
            args: [{
                    selector: 'crsd-selectable-list',
                    standalone: true,
                    imports: [CrsdInput, CrsdBadge],
                    host: {
                        '[class]': 'hostClasses()',
                        role: 'group',
                    },
                    template: `
    @if (searchable()) {
      <input
        crsdInput
        type="search"
        class="mb-3 h-9 w-full"
        [placeholder]="placeholder()"
        [value]="query()"
        (input)="onQueryInput($event)"
        aria-label="Search list"
      />
    }

    <ul class="flex max-h-80 flex-col gap-1 overflow-auto" role="listbox" [attr.aria-multiselectable]="multiple()">
      @for (item of filteredItems(); track item.id) {
        <li role="presentation">
          <button
            type="button"
            class="flex w-full items-center gap-3 rounded-md px-2 py-2 text-left text-sm transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            role="option"
            [attr.aria-selected]="isSelected(item.id)"
            [class.bg-muted]="isSelected(item.id)"
            [disabled]="disabled()"
            (click)="toggleItem(item.id)"
          >
            @if (item.imageUrl) {
              <img [src]="item.imageUrl" alt="" class="size-9 shrink-0 rounded-full object-cover" />
            }
            <span class="min-w-0 flex-1">
              <span class="block truncate font-medium">{{ item.label }}</span>
              @if (item.subtitle || item.meta) {
                <span class="block truncate text-xs text-muted-foreground">
                  {{ item.subtitle || item.meta }}
                </span>
              }
            </span>
            @if (item.badge) {
              <span crsdBadge variant="outline" size="sm">{{ item.badge }}</span>
            }
            @if (item.count != null) {
              <span class="text-xs tabular-nums text-muted-foreground">{{ item.count }}</span>
            }
          </button>
        </li>
      } @empty {
        <li class="px-2 py-6 text-center text-sm text-muted-foreground" role="status">
          {{ emptyLabel() }}
        </li>
      }
    </ul>
  `,
                }]
        }], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: true }] }], selectedIds: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedIds", required: false }] }, { type: i0.Output, args: ["selectedIdsChange"] }], selectedId: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedId", required: false }] }, { type: i0.Output, args: ["selectedIdChange"] }], multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], searchable: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchable", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], emptyLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyLabel", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }], query: [{ type: i0.Input, args: [{ isSignal: true, alias: "query", required: false }] }, { type: i0.Output, args: ["queryChange"] }] } });

class CrsdTieredTextPreview {
    data = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "data" }] : /* istanbul ignore next */ []));
    fallbackText = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "fallbackText" }] : /* istanbul ignore next */ []));
    emptyLabel = input('No description available.', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyLabel" }] : /* istanbul ignore next */ []));
    userClass = input('', { ...(ngDevMode ? { debugName: "userClass" } : /* istanbul ignore next */ {}), alias: 'class' });
    hostClasses = computed(() => cn('block', this.userClass()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostClasses" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdTieredTextPreview, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.2.3", type: CrsdTieredTextPreview, isStandalone: true, selector: "crsd-tiered-text-preview", inputs: { data: { classPropertyName: "data", publicName: "data", isSignal: true, isRequired: false, transformFunction: null }, fallbackText: { classPropertyName: "fallbackText", publicName: "fallbackText", isSignal: true, isRequired: false, transformFunction: null }, emptyLabel: { classPropertyName: "emptyLabel", publicName: "emptyLabel", isSignal: true, isRequired: false, transformFunction: null }, userClass: { classPropertyName: "userClass", publicName: "class", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "hostClasses()" } }, ngImport: i0, template: `
    @if (data(); as preview) {
      <div class="space-y-1.5">
        @if (preview.preamble) {
          <p class="text-sm text-muted-foreground">{{ preview.preamble }}</p>
        }
        @for (row of preview.rows; track row.label) {
          <div class="flex items-center gap-2">
            <span crsdBadge variant="outline" size="sm" class="shrink-0 font-mono text-sm">
              {{ row.label }}
            </span>
            <p class="text-sm text-muted-foreground">{{ row.text }}</p>
          </div>
        }
        @if (preview.rules) {
          <p class="mt-2 whitespace-pre-line border-t border-border pt-2 text-xs text-muted-foreground">
            {{ preview.rules }}
          </p>
        }
      </div>
    } @else if (fallbackText()) {
      <p class="text-sm text-muted-foreground">{{ fallbackText() }}</p>
    } @else {
      <p class="text-sm text-muted-foreground">{{ emptyLabel() }}</p>
    }
  `, isInline: true, dependencies: [{ kind: "directive", type: CrsdBadge, selector: "[crsdBadge]", inputs: ["variant", "color", "size", "class"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdTieredTextPreview, decorators: [{
            type: Component,
            args: [{
                    selector: 'crsd-tiered-text-preview',
                    standalone: true,
                    imports: [CrsdBadge],
                    host: {
                        '[class]': 'hostClasses()',
                    },
                    template: `
    @if (data(); as preview) {
      <div class="space-y-1.5">
        @if (preview.preamble) {
          <p class="text-sm text-muted-foreground">{{ preview.preamble }}</p>
        }
        @for (row of preview.rows; track row.label) {
          <div class="flex items-center gap-2">
            <span crsdBadge variant="outline" size="sm" class="shrink-0 font-mono text-sm">
              {{ row.label }}
            </span>
            <p class="text-sm text-muted-foreground">{{ row.text }}</p>
          </div>
        }
        @if (preview.rules) {
          <p class="mt-2 whitespace-pre-line border-t border-border pt-2 text-xs text-muted-foreground">
            {{ preview.rules }}
          </p>
        }
      </div>
    } @else if (fallbackText()) {
      <p class="text-sm text-muted-foreground">{{ fallbackText() }}</p>
    } @else {
      <p class="text-sm text-muted-foreground">{{ emptyLabel() }}</p>
    }
  `,
                }]
        }], propDecorators: { data: [{ type: i0.Input, args: [{ isSignal: true, alias: "data", required: false }] }], fallbackText: [{ type: i0.Input, args: [{ isSignal: true, alias: "fallbackText", required: false }] }], emptyLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyLabel", required: false }] }], userClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "class", required: false }] }] } });

const COLOR_MODE_STORAGE_KEY = 'crsd-color-mode';
function readSystemDark() {
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') {
        return false;
    }
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
}
function resolveColorMode(mode, systemDark) {
    if (mode === 'light') {
        return 'light';
    }
    if (mode === 'dark') {
        return 'dark';
    }
    return systemDark ? 'dark' : 'light';
}
class CrsdColorModeService {
    mode = signal('system', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []));
    systemDark = signal(readSystemDark(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "systemDark" }] : /* istanbul ignore next */ []));
    resolved = computed(() => resolveColorMode(this.mode(), this.systemDark()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "resolved" }] : /* istanbul ignore next */ []));
    isDark = computed(() => this.resolved() === 'dark', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDark" }] : /* istanbul ignore next */ []));
    constructor() {
        this.restoreFromStorage();
        this.apply();
        this.watchSystemPreference();
    }
    setMode(mode) {
        this.mode.set(mode);
        this.persist();
        this.apply();
    }
    toggle() {
        this.setMode(this.resolved() === 'dark' ? 'light' : 'dark');
    }
    restoreFromStorage() {
        if (typeof localStorage === 'undefined') {
            return;
        }
        const stored = localStorage.getItem(COLOR_MODE_STORAGE_KEY);
        if (stored === 'light' || stored === 'dark' || stored === 'system') {
            this.mode.set(stored);
        }
    }
    persist() {
        if (typeof localStorage === 'undefined') {
            return;
        }
        localStorage.setItem(COLOR_MODE_STORAGE_KEY, this.mode());
    }
    apply() {
        if (typeof document === 'undefined') {
            return;
        }
        const root = document.documentElement;
        const mode = this.mode();
        if (mode === 'system') {
            delete root.dataset['crsdColorScheme'];
        }
        else {
            root.dataset['crsdColorScheme'] = mode;
        }
        root.style.colorScheme = this.resolved();
    }
    watchSystemPreference() {
        if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') {
            return;
        }
        const media = window.matchMedia('(prefers-color-scheme: dark)');
        const onChange = (event) => {
            this.systemDark.set(event.matches);
            if (this.mode() === 'system') {
                this.apply();
            }
        };
        if (typeof media.addEventListener === 'function') {
            media.addEventListener('change', onChange);
            return;
        }
        media.addListener(onChange);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdColorModeService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdColorModeService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.2.3", ngImport: i0, type: CrsdColorModeService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });
function applyCrsdColorModeFromStorage() {
    if (typeof document === 'undefined' || typeof localStorage === 'undefined') {
        return;
    }
    const stored = localStorage.getItem(COLOR_MODE_STORAGE_KEY);
    if (stored !== 'light' && stored !== 'dark') {
        return;
    }
    document.documentElement.dataset['crsdColorScheme'] = stored;
    document.documentElement.style.colorScheme = stored;
}

const CURSED_EMPTY_MESSAGES = {
    titles: [
        'Nothing here.',
        'The void stares back.',
        'No results.',
        'Empty. Suspiciously empty.',
        'This page has been abandoned.',
    ],
    descriptions: [
        'Probably for the best.',
        'The void is listening.',
        'Try again. Or do not.',
        'Create something before it notices.',
        'Your data may have been consumed.',
    ],
};
function pickCursedEmptyMessage() {
    const { titles, descriptions } = CURSED_EMPTY_MESSAGES;
    return {
        title: titles[Math.floor(Math.random() * titles.length)] ?? titles[0],
        description: descriptions[Math.floor(Math.random() * descriptions.length)] ?? descriptions[0],
    };
}

const BLESSED_EMPTY_MESSAGES = {
    titles: [
        'All is calm.',
        'Room for something beautiful.',
        'A quiet moment.',
        'Nothing here yet.',
        'Space awaits your light.',
    ],
    descriptions: [
        'Create when you are ready.',
        'The page is resting peacefully.',
        'Something wonderful could go here.',
        'Begin with a single step.',
        'Grace grows in empty places.',
    ],
};
function pickBlessedEmptyMessage() {
    const { titles, descriptions } = BLESSED_EMPTY_MESSAGES;
    return {
        title: titles[Math.floor(Math.random() * titles.length)] ?? titles[0],
        description: descriptions[Math.floor(Math.random() * descriptions.length)] ?? descriptions[0],
    };
}

const crsdTailwindPreset = {
    theme: {
        extend: {
            colors: {
                background: 'hsl(var(--crsd-background) / <alpha-value>)',
                foreground: 'hsl(var(--crsd-foreground) / <alpha-value>)',
                card: {
                    DEFAULT: 'hsl(var(--crsd-card) / <alpha-value>)',
                    foreground: 'hsl(var(--crsd-card-foreground) / <alpha-value>)',
                },
                primary: {
                    DEFAULT: 'hsl(var(--crsd-primary) / <alpha-value>)',
                    foreground: 'hsl(var(--crsd-primary-foreground) / <alpha-value>)',
                },
                secondary: {
                    DEFAULT: 'hsl(var(--crsd-secondary) / <alpha-value>)',
                    foreground: 'hsl(var(--crsd-secondary-foreground) / <alpha-value>)',
                },
                destructive: {
                    DEFAULT: 'hsl(var(--crsd-destructive) / <alpha-value>)',
                    foreground: 'hsl(var(--crsd-destructive-foreground) / <alpha-value>)',
                },
                success: {
                    DEFAULT: 'hsl(var(--crsd-success) / <alpha-value>)',
                    foreground: 'hsl(var(--crsd-success-foreground) / <alpha-value>)',
                },
                warning: {
                    DEFAULT: 'hsl(var(--crsd-warning) / <alpha-value>)',
                    foreground: 'hsl(var(--crsd-warning-foreground) / <alpha-value>)',
                },
                info: {
                    DEFAULT: 'hsl(var(--crsd-info) / <alpha-value>)',
                    foreground: 'hsl(var(--crsd-info-foreground) / <alpha-value>)',
                },
                muted: {
                    DEFAULT: 'hsl(var(--crsd-muted) / <alpha-value>)',
                    foreground: 'hsl(var(--crsd-muted-foreground) / <alpha-value>)',
                },
                border: 'hsl(var(--crsd-border) / <alpha-value>)',
                input: 'hsl(var(--crsd-input) / <alpha-value>)',
                ring: 'hsl(var(--crsd-ring) / <alpha-value>)',
                popover: {
                    DEFAULT: 'hsl(var(--crsd-popover) / <alpha-value>)',
                    foreground: 'hsl(var(--crsd-popover-foreground) / <alpha-value>)',
                },
                sidebar: {
                    DEFAULT: 'hsl(var(--crsd-sidebar) / <alpha-value>)',
                    foreground: 'hsl(var(--crsd-sidebar-foreground) / <alpha-value>)',
                    primary: 'hsl(var(--crsd-sidebar-primary) / <alpha-value>)',
                    'primary-foreground': 'hsl(var(--crsd-sidebar-primary-foreground) / <alpha-value>)',
                    accent: 'hsl(var(--crsd-sidebar-accent) / <alpha-value>)',
                    'accent-foreground': 'hsl(var(--crsd-sidebar-accent-foreground) / <alpha-value>)',
                    border: 'hsl(var(--crsd-sidebar-border) / <alpha-value>)',
                    ring: 'hsl(var(--crsd-sidebar-ring) / <alpha-value>)',
                },
            },
            borderRadius: {
                lg: 'var(--crsd-radius)',
                md: 'calc(var(--crsd-radius) - 2px)',
                sm: 'calc(var(--crsd-radius) - 4px)',
            },
            zIndex: {
                overlay: 'var(--crsd-z-overlay)',
                modal: 'var(--crsd-z-modal)',
                toast: 'var(--crsd-z-toast)',
                tooltip: 'var(--crsd-z-tooltip)',
            },
        },
    },
};

/**
 * Generated bundle index. Do not edit.
 */

export { ALERT_BASE, ALERT_DESCRIPTION_BASE, ALERT_TITLE_BASE, ALERT_VARIANTS, BADGE_BASE, BADGE_DISMISS_BTN, BADGE_SIZES, BLESSED_EMPTY_MESSAGES, BLESSED_ICON_SHAPES, BLESSED_TOAST_MESSAGES, BUTTON_BASE, BUTTON_ICON_TYPO, BUTTON_SIZES, CARD_BASE, CARD_CONTENT, CARD_DESCRIPTION, CARD_FOOTER, CARD_HEADER, CARD_TITLE, CARD_VARIANTS, COMBOBOX_CHIP_BASE, COMBOBOX_CONTENT_BASE, COMBOBOX_FILTER_BASE, COMBOBOX_PANEL_BASE, COMBOBOX_TRIGGER_BASE, CRSD_THEME_CONFIG, CRSD_THEME_FEATURES, CURSED_EMPTY_MESSAGES, CURSED_ICON_SHAPES, CURSED_SKELETON_LABELS, CURSED_TOAST_MESSAGES, CrsdAlert, CrsdAlertDescription, CrsdAlertTitle, CrsdAvatarGrid, CrsdBadge, CrsdBadgeDismiss, CrsdBtn, CrsdCard, CrsdCardContent, CrsdCardDescription, CrsdCardFooter, CrsdCardHeader, CrsdCardTitle, CrsdColorModeService, CrsdCombobox, CrsdComboboxChip, CrsdComboboxChipInput, CrsdComboboxComponent, CrsdComboboxContent, CrsdComboboxEmpty, CrsdComboboxFilter, CrsdComboboxInput, CrsdComboboxItem, CrsdComboboxPanel, CrsdComboboxPortal, CrsdComboboxTrigger, CrsdComboboxTriggerHost, CrsdComboboxValues, CrsdConfirmDialog, CrsdContextMenu, CrsdContextMenuContent, CrsdContextMenuPortal, CrsdContextMenuTrigger, CrsdDialog, CrsdDialogClose, CrsdDialogContent, CrsdDialogDescription, CrsdDialogFooter, CrsdDialogHeader, CrsdDialogPortal, CrsdDialogTitle, CrsdDialogTrigger, CrsdDropdownMenu, CrsdDropdownMenuContent, CrsdDropdownMenuPortal, CrsdDropdownMenuTrigger, CrsdEmpty, CrsdEmptyDescription, CrsdEmptyHeader, CrsdEmptyMedia, CrsdEmptyTitle, CrsdField, CrsdFieldDescription, CrsdFieldError, CrsdFlipCard, CrsdFlipCardBack, CrsdFlipCardFront, CrsdFocusTrap, CrsdIcon, CrsdIconMultiselect, CrsdInput, CrsdLabel, CrsdMenu, CrsdMenuGroup, CrsdMenuItem, CrsdMenuLabel, CrsdMenuRadioGroup, CrsdMenuRadioIndicator, CrsdMenuRadioItem, CrsdRemovableBadge, CrsdSearchPicker, CrsdSelect, CrsdSelectContent, CrsdSelectItem, CrsdSelectPlaceholder, CrsdSelectPortal, CrsdSelectTrigger, CrsdSelectTriggerHost, CrsdSelectValue, CrsdSelectValueTemplate, CrsdSelectableList, CrsdSheet, CrsdSheetClose, CrsdSheetContent, CrsdSheetDescription, CrsdSheetFooter, CrsdSheetHeader, CrsdSheetPortal, CrsdSheetTitle, CrsdSheetTrigger, CrsdSidebar, CrsdSidebarContent, CrsdSidebarFooter, CrsdSidebarHeader, CrsdSidebarMenu, CrsdSidebarMenuButton, CrsdSidebarMenuItem, CrsdSidebarMenuLabel, CrsdSidebarService, CrsdSidebarWrapper, CrsdSpinner, CrsdSwitch, CrsdTable, CrsdTextarea, CrsdThemeService, CrsdTieredTextPreview, CrsdToastService, CrsdToaster, CrsdTooltip, CrsdTooltipPortal, DEFAULT_THEME_FEATURES, DIALOG_CONTENT_BASE, DIALOG_DESCRIPTION_BASE, DIALOG_FOOTER_BASE, DIALOG_HEADER_BASE, DIALOG_TITLE_BASE, EMPTY_BASE, EMPTY_DESCRIPTION_BASE, EMPTY_HEADER_BASE, EMPTY_MEDIA_BASE, EMPTY_MEDIA_ICON_VARIANT, EMPTY_TITLE_BASE, FIELD_BASE, FIELD_DESCRIPTION_BASE, FIELD_ERROR_BASE, FLIP_CARD_FACE, FLIP_CARD_FACE_BACK, FLIP_CARD_FACE_FRONT, FLIP_CARD_HOST, FLIP_CARD_HOST_FLIPPED, FLIP_CARD_INNER, FLIP_CARD_INNER_FLIPPED, ICON_BASE, ICON_SHAPES, ICON_SIZES, INPUT_BASE, LABEL_BASE, MENU_CONTENT_BASE, MENU_ITEM_BASE, MENU_LABEL_BASE, REMOVABLE_BADGE_LAYOUT, SELECT_CONTENT_BASE, SELECT_ITEM_BASE, SELECT_PLACEHOLDER_BASE, SELECT_TRIGGER_BASE, SELECT_TRIGGER_SIZES, SHEET_CONTENT_BASE, SHEET_SIDES, SIDEBAR_BASE, SIDEBAR_MENU_BUTTON_BASE, SPINNER_BASE, SPINNER_SIZES, SWITCH_TRACK_BASE, SWITCH_TRACK_SIZES, TEXTAREA_BASE, TOASTER_BASE, TOAST_BASE, TOAST_RICH_VARIANTS, TOAST_VARIANTS, TOOLTIP_CONTENT_BASE, applyCrsdColorModeFromStorage, applyCrsdThemeFromStorage, badgeClasses, buttonClasses, cn, crsdTailwindPreset, crsdTailwindPreset as crsdTailwindPresetDefault, iconShapes, isIconBtnSize, mergeThemeFeatures, normalizeOptions, pickBlessedEmptyMessage, pickBlessedToastMessage, pickCursedEmptyMessage, pickCursedSkeletonLabel, pickCursedToastMessage, provideCrsdTheme, resolveIconShapes, sortRows, toast, toggleSortDirection };
//# sourceMappingURL=mentros-crsd-ui.mjs.map
