# @mentros/crsd-ui

Standalone Angular 22 UI components styled with Tailwind CSS v4. Every supported public API is
exported from `@mentros/crsd-ui`; token styles are available under
`@mentros/crsd-ui/tokens/*.css`.

## Development

Run commands from the repository root:

```bash
npm test
npm run lint
npm run build
npm run consumer:test
```

## Building

Use `npm run build`, not `ng build ui`, because the repository build also writes the supported CSS
subpath exports into `dist/ui/package.json`.

## Consumer setup

Consumers need Angular 22, `@angular/cdk`, Tailwind CSS v4, and the base token import:

```css
@import 'tailwindcss';
@import '@mentros/crsd-ui/tokens/tokens.css';
@source '../../node_modules/@mentros/crsd-ui/**/*.mjs';
```

Overlay-based components also require `OverlayModule` providers. See the repository
[`README.md`](../../README.md) and `examples/consumer-app` for complete setup.

## Publishing

Releases are built and published by CI from `vX.Y.Z` tags. The tag must match the versions in the
root and library package manifests; do not publish `dist/ui` manually.
