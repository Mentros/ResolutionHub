import * as _angular_core from '@angular/core';
import { InjectionToken, OnInit, OnDestroy, TemplateRef } from '@angular/core';
import * as _mentros_crsd_ui from '@mentros/crsd-ui';
import { ClassValue } from 'clsx';

declare const BUTTON_BASE = "inline-flex cursor-pointer items-center justify-center gap-2 rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none";
type CrsdBtnVariant = 'solid' | 'outline' | 'ghost' | 'link' | 'soft';
type CrsdBtnColor = 'primary' | 'secondary' | 'success' | 'warning' | 'info' | 'destructive' | 'inherit';
declare function buttonClasses(variant: CrsdBtnVariant, color: CrsdBtnColor): string;
declare const BUTTON_SIZES: {
    readonly sm: "h-8 px-3 text-xs";
    readonly md: "h-10 px-4 py-2";
    readonly lg: "h-11 px-8";
    readonly 'icon-xs': "size-3.5 shrink-0 p-0 min-h-0 min-w-0 ring-offset-0 [&_.crsd-icon-graphic]:size-2.5";
    readonly 'icon-sm': "size-5 shrink-0 p-0 min-h-0 min-w-0 ring-offset-0 [&_.crsd-icon-graphic]:size-3";
    readonly icon: "size-10 shrink-0 p-0 ring-offset-0 [&_.crsd-icon-graphic]:size-4";
};
type CrsdBtnSize = keyof typeof BUTTON_SIZES;
/** Icon-only button sizes — do not pair with visible text labels. */
declare function isIconBtnSize(size: CrsdBtnSize): boolean;
/** Neutralizes BUTTON_BASE typography so fixed icon box sizes stay square. */
declare const BUTTON_ICON_TYPO = "gap-0 text-[0] leading-none font-normal";

declare class CrsdBtn {
    private readonly staticClass;
    readonly variant: _angular_core.InputSignal<CrsdBtnVariant>;
    readonly color: _angular_core.InputSignal<CrsdBtnColor>;
    readonly size: _angular_core.InputSignal<"sm" | "md" | "lg" | "icon-xs" | "icon-sm" | "icon">;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    get hostClasses(): string;
    onClick(event: Event): void;
    onKeydown(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdBtn, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdBtn, "[crsdBtn]", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const ICON_BASE = "shrink-0 pointer-events-none";
declare const ICON_SIZES: {
    readonly xs: "size-3";
    readonly sm: "size-4";
    readonly md: "size-5";
    readonly lg: "size-6";
};
type CrsdIconSize = keyof typeof ICON_SIZES;
type CrsdIconShape = {
    type: 'path';
    d: string;
} | {
    type: 'circle';
    cx: string;
    cy: string;
    r: string;
} | {
    type: 'line';
    x1: string;
    y1: string;
    x2: string;
    y2: string;
} | {
    type: 'polyline';
    points: string;
} | {
    type: 'rect';
    x: string;
    y: string;
    width: string;
    height: string;
    rx?: string;
};
declare const ICON_SHAPES: {
    readonly plus: readonly [{
        readonly type: "path";
        readonly d: "M5 12h14";
    }, {
        readonly type: "path";
        readonly d: "M12 5v14";
    }];
    readonly minus: readonly [{
        readonly type: "path";
        readonly d: "M5 12h14";
    }];
    readonly x: readonly [{
        readonly type: "path";
        readonly d: "M18 6 6 18";
    }, {
        readonly type: "path";
        readonly d: "m6 6 12 12";
    }];
    readonly check: readonly [{
        readonly type: "path";
        readonly d: "M20 6 9 17l-5-5";
    }];
    readonly 'chevron-up': readonly [{
        readonly type: "path";
        readonly d: "m18 15-6-6-6 6";
    }];
    readonly 'chevron-down': readonly [{
        readonly type: "path";
        readonly d: "m6 9 6 6 6-6";
    }];
    readonly 'chevron-left': readonly [{
        readonly type: "path";
        readonly d: "m15 18-6-6 6-6";
    }];
    readonly 'chevron-right': readonly [{
        readonly type: "path";
        readonly d: "m9 18 6-6-6-6";
    }];
    readonly 'arrow-up': readonly [{
        readonly type: "path";
        readonly d: "m5 12 7-7 7 7";
    }, {
        readonly type: "path";
        readonly d: "M12 19V5";
    }];
    readonly 'arrow-down': readonly [{
        readonly type: "path";
        readonly d: "M12 5v14";
    }, {
        readonly type: "path";
        readonly d: "m19 12-7 7-7-7";
    }];
    readonly 'arrow-left': readonly [{
        readonly type: "path";
        readonly d: "m12 19-7-7 7-7";
    }, {
        readonly type: "path";
        readonly d: "M19 12H5";
    }];
    readonly 'arrow-right': readonly [{
        readonly type: "path";
        readonly d: "M5 12h14";
    }, {
        readonly type: "path";
        readonly d: "m12 5 7 7-7 7";
    }];
    readonly search: readonly [{
        readonly type: "circle";
        readonly cx: "11";
        readonly cy: "11";
        readonly r: "8";
    }, {
        readonly type: "path";
        readonly d: "m21 21-4.3-4.3";
    }];
    readonly settings: readonly [{
        readonly type: "path";
        readonly d: "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z";
    }, {
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "12";
        readonly r: "3";
    }];
    readonly menu: readonly [{
        readonly type: "path";
        readonly d: "M4 12h16";
    }, {
        readonly type: "path";
        readonly d: "M4 6h16";
    }, {
        readonly type: "path";
        readonly d: "M4 18h16";
    }];
    readonly user: readonly [{
        readonly type: "path";
        readonly d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2";
    }, {
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "7";
        readonly r: "4";
    }];
    readonly mail: readonly [{
        readonly type: "rect";
        readonly x: "2";
        readonly y: "4";
        readonly width: "20";
        readonly height: "16";
        readonly rx: "2";
    }, {
        readonly type: "path";
        readonly d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7";
    }];
    readonly bell: readonly [{
        readonly type: "path";
        readonly d: "M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9";
    }, {
        readonly type: "path";
        readonly d: "M10.3 21a1.94 1.94 0 0 0 3.4 0";
    }];
    readonly trash: readonly [{
        readonly type: "path";
        readonly d: "M3 6h18";
    }, {
        readonly type: "path";
        readonly d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6";
    }, {
        readonly type: "path";
        readonly d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2";
    }];
    readonly pencil: readonly [{
        readonly type: "path";
        readonly d: "M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z";
    }, {
        readonly type: "path";
        readonly d: "m15 5 4 4";
    }];
    readonly copy: readonly [{
        readonly type: "rect";
        readonly x: "9";
        readonly y: "9";
        readonly width: "13";
        readonly height: "13";
        readonly rx: "2";
    }, {
        readonly type: "path";
        readonly d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1";
    }];
    readonly download: readonly [{
        readonly type: "path";
        readonly d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4";
    }, {
        readonly type: "polyline";
        readonly points: "7 10 12 15 17 10";
    }, {
        readonly type: "path";
        readonly d: "M12 15V3";
    }];
    readonly upload: readonly [{
        readonly type: "path";
        readonly d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4";
    }, {
        readonly type: "polyline";
        readonly points: "17 8 12 3 7 8";
    }, {
        readonly type: "path";
        readonly d: "M12 3v12";
    }];
    readonly 'external-link': readonly [{
        readonly type: "path";
        readonly d: "M15 3h6v6";
    }, {
        readonly type: "path";
        readonly d: "M10 14 21 3";
    }, {
        readonly type: "path";
        readonly d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6";
    }];
    readonly info: readonly [{
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "12";
        readonly r: "10";
    }, {
        readonly type: "path";
        readonly d: "M12 16v-4";
    }, {
        readonly type: "path";
        readonly d: "M12 8h.01";
    }];
    readonly 'alert-triangle': readonly [{
        readonly type: "path";
        readonly d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3";
    }, {
        readonly type: "path";
        readonly d: "M12 9v4";
    }, {
        readonly type: "path";
        readonly d: "M12 17h.01";
    }];
    readonly 'alert-circle': readonly [{
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "12";
        readonly r: "10";
    }, {
        readonly type: "path";
        readonly d: "M12 8v4";
    }, {
        readonly type: "path";
        readonly d: "M12 16h.01";
    }];
    readonly loader: readonly [{
        readonly type: "path";
        readonly d: "M21 12a9 9 0 1 1-6.219-8.56";
    }];
    readonly home: readonly [{
        readonly type: "path";
        readonly d: "m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z";
    }, {
        readonly type: "polyline";
        readonly points: "9 22 9 12 15 12 15 22";
    }];
    readonly heart: readonly [{
        readonly type: "path";
        readonly d: "M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z";
    }];
    readonly star: readonly [{
        readonly type: "path";
        readonly d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z";
    }];
    readonly eye: readonly [{
        readonly type: "path";
        readonly d: "M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z";
    }, {
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "12";
        readonly r: "3";
    }];
    readonly 'eye-off': readonly [{
        readonly type: "path";
        readonly d: "M9.88 9.88a3 3 0 1 0 4.24 4.24";
    }, {
        readonly type: "path";
        readonly d: "M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68";
    }, {
        readonly type: "path";
        readonly d: "M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61";
    }, {
        readonly type: "line";
        readonly x1: "2";
        readonly y1: "2";
        readonly x2: "22";
        readonly y2: "22";
    }];
    readonly lock: readonly [{
        readonly type: "rect";
        readonly x: "3";
        readonly y: "11";
        readonly width: "18";
        readonly height: "11";
        readonly rx: "2";
    }, {
        readonly type: "path";
        readonly d: "M7 11V7a5 5 0 0 1 10 0v4";
    }];
    readonly unlock: readonly [{
        readonly type: "rect";
        readonly x: "3";
        readonly y: "11";
        readonly width: "18";
        readonly height: "11";
        readonly rx: "2";
    }, {
        readonly type: "path";
        readonly d: "M7 11V7a5 5 0 0 1 9.9-1";
    }];
    readonly calendar: readonly [{
        readonly type: "rect";
        readonly x: "3";
        readonly y: "4";
        readonly width: "18";
        readonly height: "18";
        readonly rx: "2";
    }, {
        readonly type: "path";
        readonly d: "M16 2v4";
    }, {
        readonly type: "path";
        readonly d: "M8 2v4";
    }, {
        readonly type: "path";
        readonly d: "M3 10h18";
    }];
    readonly clock: readonly [{
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "12";
        readonly r: "10";
    }, {
        readonly type: "polyline";
        readonly points: "12 6 12 12 16 14";
    }];
    readonly sun: readonly [{
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "12";
        readonly r: "4";
    }, {
        readonly type: "path";
        readonly d: "M12 2v2";
    }, {
        readonly type: "path";
        readonly d: "M12 20v2";
    }, {
        readonly type: "path";
        readonly d: "m4.93 4.93 1.41 1.41";
    }, {
        readonly type: "path";
        readonly d: "m17.66 17.66 1.41 1.41";
    }, {
        readonly type: "path";
        readonly d: "M2 12h2";
    }, {
        readonly type: "path";
        readonly d: "M20 12h2";
    }, {
        readonly type: "path";
        readonly d: "m6.34 17.66-1.41 1.41";
    }, {
        readonly type: "path";
        readonly d: "m19.07 4.93-1.41 1.41";
    }];
    readonly moon: readonly [{
        readonly type: "path";
        readonly d: "M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z";
    }];
    readonly filter: readonly [{
        readonly type: "path";
        readonly d: "M22 3H2l8 9.46V19l4 2v-8.54L22 3z";
    }];
    readonly 'more-horizontal': readonly [{
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "12";
        readonly r: "1";
    }, {
        readonly type: "circle";
        readonly cx: "19";
        readonly cy: "12";
        readonly r: "1";
    }, {
        readonly type: "circle";
        readonly cx: "5";
        readonly cy: "12";
        readonly r: "1";
    }];
    readonly 'more-vertical': readonly [{
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "12";
        readonly r: "1";
    }, {
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "5";
        readonly r: "1";
    }, {
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "19";
        readonly r: "1";
    }];
    readonly refresh: readonly [{
        readonly type: "path";
        readonly d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8";
    }, {
        readonly type: "path";
        readonly d: "M21 3v5h-5";
    }, {
        readonly type: "path";
        readonly d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16";
    }, {
        readonly type: "path";
        readonly d: "M8 16H3v5";
    }];
    readonly link: readonly [{
        readonly type: "path";
        readonly d: "M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71";
    }, {
        readonly type: "path";
        readonly d: "M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71";
    }];
    readonly folder: readonly [{
        readonly type: "path";
        readonly d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z";
    }];
    readonly file: readonly [{
        readonly type: "path";
        readonly d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z";
    }, {
        readonly type: "path";
        readonly d: "M14 2v4a2 2 0 0 0 2 2h4";
    }];
    readonly share: readonly [{
        readonly type: "path";
        readonly d: "M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8";
    }, {
        readonly type: "polyline";
        readonly points: "16 6 12 2 8 6";
    }, {
        readonly type: "path";
        readonly d: "M12 2v13";
    }];
    readonly 'log-in': readonly [{
        readonly type: "path";
        readonly d: "M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4";
    }, {
        readonly type: "polyline";
        readonly points: "10 17 15 12 10 7";
    }, {
        readonly type: "path";
        readonly d: "M15 12H3";
    }];
    readonly 'log-out': readonly [{
        readonly type: "path";
        readonly d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4";
    }, {
        readonly type: "polyline";
        readonly points: "16 17 21 12 16 7";
    }, {
        readonly type: "path";
        readonly d: "M21 12H9";
    }];
};
type CrsdIconName = keyof typeof ICON_SHAPES;
declare function iconShapes(name: CrsdIconName): readonly CrsdIconShape[];
declare function resolveIconShapes(name: CrsdIconName, theme: 'default' | 'cursed' | 'blessed'): readonly CrsdIconShape[];

declare class CrsdIcon {
    readonly name: _angular_core.InputSignal<"link" | "info" | "copy" | "check" | "x" | "star" | "alert-triangle" | "loader" | "heart" | "settings" | "user" | "home" | "search" | "bell" | "plus" | "minus" | "chevron-up" | "chevron-down" | "chevron-left" | "chevron-right" | "arrow-up" | "arrow-down" | "arrow-left" | "arrow-right" | "menu" | "mail" | "trash" | "pencil" | "download" | "upload" | "external-link" | "alert-circle" | "eye" | "eye-off" | "lock" | "unlock" | "calendar" | "clock" | "sun" | "moon" | "filter" | "more-horizontal" | "more-vertical" | "refresh" | "folder" | "file" | "share" | "log-in" | "log-out">;
    readonly size: _angular_core.InputSignal<"sm" | "md" | "lg" | "xs">;
    readonly strokeWidth: _angular_core.InputSignal<number>;
    readonly spin: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly label: _angular_core.InputSignal<string>;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly themeService;
    get hostClasses(): string;
    readonly shapes: _angular_core.Signal<readonly CrsdIconShape[]>;
    readonly svgClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdIcon, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdIcon, "crsd-icon", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "strokeWidth": { "alias": "strokeWidth"; "required": false; "isSignal": true; }; "spin": { "alias": "spin"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class CrsdInput {
    private readonly staticClass;
    readonly value: _angular_core.ModelSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly fieldContext;
    private readonly validFlash;
    constructor(staticClass: string | null);
    readonly controlId: _angular_core.Signal<string | null>;
    readonly describedBy: _angular_core.Signal<string | null>;
    readonly isInvalid: _angular_core.Signal<boolean>;
    get hostClasses(): string;
    get hostValue(): string;
    onInput(event: Event): void;
    onBlur(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdInput, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdInput, "[crsdInput]", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

declare const INPUT_BASE = "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50";

declare class CrsdTextarea {
    private readonly staticClass;
    readonly value: _angular_core.ModelSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly fieldContext;
    private readonly validFlash;
    constructor(staticClass: string | null);
    readonly controlId: _angular_core.Signal<string | null>;
    readonly describedBy: _angular_core.Signal<string | null>;
    readonly isInvalid: _angular_core.Signal<boolean>;
    get hostClasses(): string;
    get hostValue(): string;
    onInput(event: Event): void;
    onBlur(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdTextarea, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdTextarea, "[crsdTextarea]", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

/** Multiline control styling aligned with {@link INPUT_BASE}. */
declare const TEXTAREA_BASE: string;

declare const SWITCH_TRACK_BASE = "relative shrink-0 cursor-pointer rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50";
type CrsdSwitchSize = 'sm' | 'md' | 'lg';
type CrsdSwitchVariant = 'default' | 'icon';
declare const SWITCH_TRACK_SIZES: Record<CrsdSwitchSize, string>;

declare class CrsdSwitch {
    readonly checked: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly variant: _angular_core.InputSignal<CrsdSwitchVariant>;
    readonly size: _angular_core.InputSignal<CrsdSwitchSize>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly offLabel: _angular_core.InputSignal<string>;
    readonly onLabel: _angular_core.InputSignal<string>;
    readonly checkedIcon: _angular_core.InputSignal<"link" | "info" | "copy" | "check" | "x" | "star" | "alert-triangle" | "loader" | "heart" | "settings" | "user" | "home" | "search" | "bell" | "plus" | "minus" | "chevron-up" | "chevron-down" | "chevron-left" | "chevron-right" | "arrow-up" | "arrow-down" | "arrow-left" | "arrow-right" | "menu" | "mail" | "trash" | "pencil" | "download" | "upload" | "external-link" | "alert-circle" | "eye" | "eye-off" | "lock" | "unlock" | "calendar" | "clock" | "sun" | "moon" | "filter" | "more-horizontal" | "more-vertical" | "refresh" | "folder" | "file" | "share" | "log-in" | "log-out">;
    readonly uncheckedIcon: _angular_core.InputSignal<"link" | "info" | "copy" | "check" | "x" | "star" | "alert-triangle" | "loader" | "heart" | "settings" | "user" | "home" | "search" | "bell" | "plus" | "minus" | "chevron-up" | "chevron-down" | "chevron-left" | "chevron-right" | "arrow-up" | "arrow-down" | "arrow-left" | "arrow-right" | "menu" | "mail" | "trash" | "pencil" | "download" | "upload" | "external-link" | "alert-circle" | "eye" | "eye-off" | "lock" | "unlock" | "calendar" | "clock" | "sun" | "moon" | "filter" | "more-horizontal" | "more-vertical" | "refresh" | "folder" | "file" | "share" | "log-in" | "log-out">;
    readonly userClass: _angular_core.InputSignal<string>;
    readonly checkedChange: _angular_core.OutputEmitterRef<boolean>;
    readonly iconSize: _angular_core.Signal<"sm" | "xs">;
    readonly activeIcon: _angular_core.Signal<"link" | "info" | "copy" | "check" | "x" | "star" | "alert-triangle" | "loader" | "heart" | "settings" | "user" | "home" | "search" | "bell" | "plus" | "minus" | "chevron-up" | "chevron-down" | "chevron-left" | "chevron-right" | "arrow-up" | "arrow-down" | "arrow-left" | "arrow-right" | "menu" | "mail" | "trash" | "pencil" | "download" | "upload" | "external-link" | "alert-circle" | "eye" | "eye-off" | "lock" | "unlock" | "calendar" | "clock" | "sun" | "moon" | "filter" | "more-horizontal" | "more-vertical" | "refresh" | "folder" | "file" | "share" | "log-in" | "log-out">;
    readonly trackClasses: _angular_core.Signal<string>;
    readonly thumbClasses: _angular_core.Signal<string>;
    readonly iconSlotClasses: _angular_core.Signal<string>;
    toggle(): void;
    private isIconVariant;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSwitch, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdSwitch, "crsd-switch", never, { "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "offLabel": { "alias": "offLabel"; "required": false; "isSignal": true; }; "onLabel": { "alias": "onLabel"; "required": false; "isSignal": true; }; "checkedIcon": { "alias": "checkedIcon"; "required": false; "isSignal": true; }; "uncheckedIcon": { "alias": "uncheckedIcon"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, { "checkedChange": "checkedChange"; }, never, never, true, never>;
}

declare class CrsdCard {
    private readonly staticClass;
    readonly variant: _angular_core.InputSignal<"default" | "elevated">;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    get hostClasses(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdCard, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdCard, "[crsdCard]", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdCardHeader {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    get hostClasses(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdCardHeader, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdCardHeader, "[crsdCardHeader]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdCardTitle {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    get hostClasses(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdCardTitle, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdCardTitle, "[crsdCardTitle]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdCardDescription {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    get hostClasses(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdCardDescription, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdCardDescription, "[crsdCardDescription]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdCardContent {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    get hostClasses(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdCardContent, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdCardContent, "[crsdCardContent]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdCardFooter {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    get hostClasses(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdCardFooter, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdCardFooter, "[crsdCardFooter]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const CARD_BASE = "rounded-lg border border-border bg-background text-foreground";
declare const CARD_VARIANTS: {
    readonly default: "";
    readonly elevated: "shadow-md";
};
type CrsdCardVariant = keyof typeof CARD_VARIANTS;
declare const CARD_HEADER = "flex flex-col space-y-1.5 p-6";
declare const CARD_TITLE = "text-2xl font-semibold leading-none tracking-tight";
declare const CARD_DESCRIPTION = "text-sm text-muted-foreground";
declare const CARD_CONTENT = "p-6 pt-0";
declare const CARD_FOOTER = "flex items-center p-6 pt-0";

declare const CRSD_THEME_FEATURES: readonly ["motion", "ambient", "copy", "icons", "forms", "table", "bursts"];
type CrsdThemeFeature = (typeof CRSD_THEME_FEATURES)[number];
type CrsdThemeFeatureFlags = Record<CrsdThemeFeature, boolean>;
interface CrsdThemeConfig {
    /** Feature overrides applied while the cursed preset is active. */
    cursed?: Partial<CrsdThemeFeatureFlags>;
    /** Feature overrides applied while the blessed preset is active. */
    blessed?: Partial<CrsdThemeFeatureFlags>;
}
declare const DEFAULT_THEME_FEATURES: CrsdThemeFeatureFlags;
declare function mergeThemeFeatures(base: CrsdThemeFeatureFlags, ...overrides: Array<Partial<CrsdThemeFeatureFlags> | undefined>): CrsdThemeFeatureFlags;

type CrsdTheme = 'default' | 'cursed' | 'blessed';
type CrsdCursedIntensity = 'low' | 'medium' | 'high';
declare const CRSD_THEME_CONFIG: InjectionToken<CrsdThemeConfig>;
declare function provideCrsdTheme(config?: CrsdThemeConfig): {
    provide: typeof CRSD_THEME_CONFIG;
    useValue: CrsdThemeConfig;
};
declare class CrsdThemeService {
    readonly theme: _angular_core.WritableSignal<CrsdTheme>;
    readonly intensity: _angular_core.WritableSignal<CrsdCursedIntensity>;
    readonly corruptionActive: _angular_core.WritableSignal<boolean>;
    readonly radianceActive: _angular_core.WritableSignal<boolean>;
    readonly isCursed: _angular_core.Signal<boolean>;
    readonly isBlessed: _angular_core.Signal<boolean>;
    readonly isThemed: _angular_core.Signal<boolean>;
    readonly features: _angular_core.Signal<CrsdThemeFeatureFlags>;
    private readonly injectedConfig;
    private presetConfig;
    private readonly runtimeFeatureOverrides;
    private corruptionTimer;
    private radianceTimer;
    constructor();
    isFeatureEnabled(feature: CrsdThemeFeature): boolean;
    setFeature(feature: CrsdThemeFeature, enabled: boolean): void;
    configureFeatures(overrides: Partial<CrsdThemeFeatureFlags>): void;
    resetFeatures(): void;
    configurePreset(config: CrsdThemeConfig): void;
    setTheme(theme: CrsdTheme): void;
    setIntensity(intensity: CrsdCursedIntensity): void;
    toggle(): void;
    triggerCorruption(durationMs?: number): void;
    triggerRadiance(durationMs?: number): void;
    private restoreFromStorage;
    private persist;
    private apply;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdThemeService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<any>;
}
declare function applyCrsdThemeFromStorage(): void;

interface CrsdTableColumn<T extends object> {
    key: keyof T & string;
    header: string;
    sortable?: boolean;
}
type CrsdSortDirection = 'asc' | 'desc' | null;
declare function sortRows<T extends object>(rows: T[], key: (keyof T & string) | null, direction: CrsdSortDirection): T[];
declare function toggleSortDirection(current: CrsdSortDirection): CrsdSortDirection;

declare class CrsdTable<T extends object> {
    readonly data: _angular_core.InputSignal<T[]>;
    readonly columns: _angular_core.InputSignal<CrsdTableColumn<T>[]>;
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    readonly themeService: CrsdThemeService;
    readonly skeletonRows: number[];
    readonly sortGlitchKey: _angular_core.WritableSignal<string | null>;
    readonly sortGlowKey: _angular_core.WritableSignal<string | null>;
    readonly corruptedFlash: _angular_core.WritableSignal<boolean>;
    readonly corruptedRows: _angular_core.WritableSignal<T[]>;
    readonly radianceReveal: _angular_core.WritableSignal<boolean>;
    private glitchTimer;
    private glowTimer;
    private flashTimer;
    private radianceTimer;
    private wasLoading;
    get hostClasses(): string;
    private readonly sortKey;
    private readonly sortDirection;
    readonly displayRows: _angular_core.Signal<T[]>;
    constructor();
    onSort(column: CrsdTableColumn<T>): void;
    skeletonLabel(rowIndex: number, key: string): string;
    skeletonLabelBlessed(rowIndex: number, key: string): string;
    ariaSort(key: keyof T & string): 'ascending' | 'descending' | 'none';
    showSortIcon(key: keyof T & string): boolean;
    sortIconName(key: keyof T & string): 'chevron-up' | 'chevron-down';
    trackRow(index: number, row: T): string | number;
    private triggerCorruptedFlash;
    private triggerRadianceReveal;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdTable<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdTable<any>, "crsd-table", never, { "data": { "alias": "data"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const BADGE_BASE = "inline-flex items-center rounded-md border px-2 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2";
type CrsdBadgeVariant = 'solid' | 'outline' | 'soft';
type CrsdBadgeColor = 'primary' | 'secondary' | 'success' | 'warning' | 'info' | 'destructive';
type CrsdBadgeSize = 'sm' | 'md';
declare function badgeClasses(variant: CrsdBadgeVariant, color: CrsdBadgeColor): string;
declare const BADGE_SIZES: Record<CrsdBadgeSize, string>;
/** Tighter chip layout when a dismiss control sits inside a badge. */
declare const REMOVABLE_BADGE_LAYOUT = "gap-0 py-0 pl-1.5 pr-0";
/** Visual tuning for dismiss controls nested in badges (hit target stays icon-xs). */
declare const BADGE_DISMISS_BTN = "rounded-sm opacity-60 ring-offset-0 hover:bg-current/10 hover:opacity-100";

declare class CrsdBadge {
    private readonly staticClass;
    readonly variant: _angular_core.InputSignal<CrsdBadgeVariant>;
    readonly color: _angular_core.InputSignal<CrsdBadgeColor>;
    readonly size: _angular_core.InputSignal<CrsdBadgeSize>;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdBadge, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdBadge, "[crsdBadge]", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class CrsdBadgeDismiss {
    readonly removeLabel: _angular_core.InputSignal<string>;
    readonly variant: _angular_core.InputSignal<CrsdBtnVariant>;
    readonly color: _angular_core.InputSignal<CrsdBtnColor>;
    readonly size: _angular_core.InputSignal<"sm" | "md" | "lg" | "icon-xs" | "icon-sm" | "icon">;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dismiss: _angular_core.OutputEmitterRef<void>;
    readonly hostClasses: _angular_core.Signal<string>;
    protected iconSize(): CrsdIconSize;
    onClick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdBadgeDismiss, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdBadgeDismiss, "button[crsdBadgeDismiss]", never, { "removeLabel": { "alias": "removeLabel"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "dismiss": "dismiss"; }, never, never, true, never>;
}

declare class CrsdRemovableBadge {
    protected readonly REMOVABLE_BADGE_LAYOUT = "gap-0 py-0 pl-1.5 pr-0";
    readonly variant: _angular_core.InputSignal<CrsdBadgeVariant>;
    readonly color: _angular_core.InputSignal<CrsdBadgeColor>;
    readonly size: _angular_core.InputSignal<CrsdBadgeSize>;
    readonly removeLabel: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dismiss: _angular_core.OutputEmitterRef<void>;
    protected onDismiss(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdRemovableBadge, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdRemovableBadge, "crsd-removable-badge", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "removeLabel": { "alias": "removeLabel"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "dismiss": "dismiss"; }, never, ["*"], true, never>;
}

declare const SPINNER_BASE = "animate-spin text-primary";
type CrsdSpinnerSize = 'sm' | 'md' | 'lg';
declare const SPINNER_SIZES: Record<CrsdSpinnerSize, string>;

declare class CrsdSpinner {
    readonly size: _angular_core.InputSignal<CrsdSpinnerSize>;
    readonly label: _angular_core.InputSignal<string>;
    readonly userClass: _angular_core.InputSignal<string>;
    readonly strokeWidth: _angular_core.Signal<number>;
    readonly hostClasses: _angular_core.Signal<string>;
    readonly svgClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSpinner, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdSpinner, "crsd-spinner", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class CrsdLabel {
    private readonly staticClass;
    readonly for: _angular_core.InputSignal<string>;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdLabel, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdLabel, "[crsdLabel]", never, { "for": { "alias": "for"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const LABEL_BASE = "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70";

declare class CrsdFieldContext {
    readonly controlId: _angular_core.WritableSignal<string | null>;
    readonly invalid: _angular_core.WritableSignal<boolean>;
    readonly errorIds: _angular_core.WritableSignal<string[]>;
    private readonly descriptionIds;
    setControlId(id: string): void;
    registerDescription(id: string): void;
    unregisterDescription(id: string): void;
    registerError(id: string): void;
    unregisterError(id: string): void;
    describedBy(): string | null;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdFieldContext, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<any>;
}

declare class CrsdField implements OnInit {
    private readonly staticClass;
    readonly invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly fieldContext;
    private readonly idService;
    readonly isInvalid: _angular_core.Signal<boolean>;
    constructor(staticClass: string | null);
    ngOnInit(): void;
    readonly hostClasses: _angular_core.Signal<string>;
    get context(): CrsdFieldContext;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdField, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdField, "[crsdField]", never, { "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdFieldDescription implements OnInit, OnDestroy {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly fieldContext;
    private readonly idService;
    private readonly _elementId;
    constructor(staticClass: string | null);
    readonly elementId: _angular_core.Signal<string>;
    readonly hostClasses: _angular_core.Signal<string>;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdFieldDescription, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdFieldDescription, "[crsdFieldDescription]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdFieldError implements OnInit, OnDestroy {
    private readonly staticClass;
    readonly validator: _angular_core.InputSignal<string>;
    readonly show: _angular_core.InputSignal<boolean | null>;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly fieldContext;
    private readonly idService;
    private readonly _elementId;
    constructor(staticClass: string | null);
    readonly elementId: _angular_core.Signal<string>;
    readonly visible: _angular_core.Signal<boolean | null>;
    readonly hostClasses: _angular_core.Signal<string>;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdFieldError, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdFieldError, "[crsdFieldError]", never, { "validator": { "alias": "validator"; "required": false; "isSignal": true; }; "show": { "alias": "show"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const FIELD_BASE = "space-y-2";
declare const FIELD_ERROR_BASE = "text-sm font-medium text-destructive";
declare const FIELD_DESCRIPTION_BASE = "text-sm text-muted-foreground";

type CrsdAlertVariant = 'default' | 'success' | 'error' | 'warning' | 'info';
declare const ALERT_BASE = "relative w-full rounded-lg border p-4 text-sm";
declare const ALERT_VARIANTS: Record<CrsdAlertVariant, string>;
declare const ALERT_TITLE_BASE = "mb-1 font-medium leading-none tracking-tight";
declare const ALERT_DESCRIPTION_BASE = "text-sm leading-relaxed";

declare class CrsdAlert {
    private readonly staticClass;
    readonly variant: _angular_core.InputSignal<CrsdAlertVariant>;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    readonly hostRole: _angular_core.Signal<"status" | "alert">;
    readonly hostLive: _angular_core.Signal<"assertive" | "polite">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdAlert, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdAlert, "[crsdAlert]", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdAlertTitle {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdAlertTitle, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdAlertTitle, "[crsdAlertTitle]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdAlertDescription {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdAlertDescription, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdAlertDescription, "[crsdAlertDescription]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type CrsdTooltipSide = 'top' | 'right' | 'bottom' | 'left';
declare const TOOLTIP_CONTENT_BASE = "z-tooltip rounded-md border border-border bg-popover px-3 py-1.5 text-sm text-popover-foreground shadow-md";

declare class CrsdTooltipPortal {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdTooltipPortal, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdTooltipPortal, "[crsdTooltipPortal]", never, {}, {}, never, never, true, never>;
}
declare class CrsdTooltip {
    private readonly attrTooltip;
    readonly crsdTooltip: _angular_core.InputSignal<string>;
    readonly side: _angular_core.InputSignal<CrsdTooltipSide>;
    readonly showDelay: _angular_core.InputSignal<number>;
    readonly hideDelay: _angular_core.InputSignal<number>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private readonly portalTemplate;
    private readonly elementRef;
    private readonly portalViewContainer;
    private readonly overlayService;
    private readonly idService;
    private readonly destroyRef;
    private readonly applicationRef;
    readonly tooltipId: string;
    readonly isOpen: _angular_core.WritableSignal<boolean>;
    private overlayRef;
    constructor(attrTooltip: string | null);
    private tooltipText;
    private hasContent;
    open(): void;
    close(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdTooltip, [{ attribute: "crsdTooltip"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdTooltip, "[crsdTooltip]", never, { "crsdTooltip": { "alias": "crsdTooltip"; "required": false; "isSignal": true; }; "side": { "alias": "side"; "required": false; "isSignal": true; }; "showDelay": { "alias": "showDelay"; "required": false; "isSignal": true; }; "hideDelay": { "alias": "hideDelay"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, ["portalTemplate"], never, true, never>;
}

type CrsdOpenState = 'open' | 'closed';

declare class CrsdFocusTrap implements OnInit, OnDestroy {
    readonly crsdFocusTrap: _angular_core.InputSignal<boolean>;
    readonly crsdFocusTrapAutoCapture: _angular_core.InputSignal<boolean>;
    private trap;
    private previousFocus;
    private readonly elementRef;
    private readonly focusTrapFactory;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdFocusTrap, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdFocusTrap, "[crsdFocusTrap]", never, { "crsdFocusTrap": { "alias": "crsdFocusTrap"; "required": false; "isSignal": true; }; "crsdFocusTrapAutoCapture": { "alias": "crsdFocusTrapAutoCapture"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class CrsdDialogPortal {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdDialogPortal, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdDialogPortal, "[crsdDialogPortal]", never, {}, {}, never, never, true, never>;
}
declare class CrsdDialog {
    readonly state: _angular_core.ModelSignal<CrsdOpenState>;
    readonly stateChanged: _angular_core.OutputEmitterRef<CrsdOpenState>;
    readonly closeOnBackdropClick: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closeOnEscape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly titleId: string;
    readonly descriptionId: string;
    private readonly portalTemplate;
    private readonly overlayService;
    private readonly viewContainer;
    private readonly destroyRef;
    private overlayRef;
    private triggerElement;
    constructor();
    open(from?: HTMLElement): void;
    close(): void;
    setState(next: CrsdOpenState): void;
    private attachOverlay;
    private detachOverlay;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdDialog, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdDialog, "[crsdDialog]", ["crsdDialog"], { "state": { "alias": "state"; "required": false; "isSignal": true; }; "closeOnBackdropClick": { "alias": "closeOnBackdropClick"; "required": false; "isSignal": true; }; "closeOnEscape": { "alias": "closeOnEscape"; "required": false; "isSignal": true; }; }, { "state": "stateChange"; "stateChanged": "stateChanged"; }, ["portalTemplate"], never, true, never>;
}
declare class CrsdDialogTrigger {
    private readonly dialog;
    private readonly elementRef;
    onClick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdDialogTrigger, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdDialogTrigger, "[crsdDialogTrigger]", never, {}, {}, never, never, true, never>;
}
declare class CrsdDialogClose {
    private readonly dialog;
    onClick(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdDialogClose, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdDialogClose, "[crsdDialogClose]", never, {}, {}, never, never, true, never>;
}
declare class CrsdDialogContent {
    private readonly staticClass;
    protected readonly dialog: CrsdDialog;
    readonly userClass: _angular_core.InputSignal<string>;
    readonly alert: _angular_core.InputSignalWithTransform<boolean, unknown>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    readonly hostRole: _angular_core.Signal<"alertdialog" | "dialog">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdDialogContent, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdDialogContent, "[crsdDialogContent]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; "alert": { "alias": "alert"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof CrsdFocusTrap; inputs: {}; outputs: {}; }]>;
}
declare class CrsdDialogHeader {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdDialogHeader, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdDialogHeader, "[crsdDialogHeader]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdDialogTitle {
    private readonly staticClass;
    protected readonly dialog: CrsdDialog;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdDialogTitle, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdDialogTitle, "[crsdDialogTitle]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdDialogDescription {
    private readonly staticClass;
    protected readonly dialog: CrsdDialog;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdDialogDescription, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdDialogDescription, "[crsdDialogDescription]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdDialogFooter {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdDialogFooter, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdDialogFooter, "[crsdDialogFooter]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class CrsdConfirmDialog {
    readonly state: _angular_core.ModelSignal<CrsdOpenState>;
    readonly title: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    readonly cancelLabel: _angular_core.InputSignal<string>;
    readonly confirmLabel: _angular_core.InputSignal<string>;
    readonly destructive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closeOnBackdropClick: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closeOnEscape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly confirmed: _angular_core.OutputEmitterRef<void>;
    readonly cancelled: _angular_core.OutputEmitterRef<void>;
    private readonly innerDialog;
    private suppressDismissEvent;
    /** Open the confirm overlay; optional element receives focus when closed. */
    open(from?: HTMLElement): void;
    protected confirmColor(): CrsdBtnColor;
    onProjectedTriggerClick(event: Event): void;
    confirm(): void;
    cancel(): void;
    onStateChanged(next: CrsdOpenState): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdConfirmDialog, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdConfirmDialog, "crsd-confirm-dialog", never, { "state": { "alias": "state"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; "isSignal": true; }; "confirmLabel": { "alias": "confirmLabel"; "required": false; "isSignal": true; }; "destructive": { "alias": "destructive"; "required": false; "isSignal": true; }; "closeOnBackdropClick": { "alias": "closeOnBackdropClick"; "required": false; "isSignal": true; }; "closeOnEscape": { "alias": "closeOnEscape"; "required": false; "isSignal": true; }; }, { "state": "stateChange"; "confirmed": "confirmed"; "cancelled": "cancelled"; }, never, ["[crsdConfirmTrigger]"], true, never>;
}

declare const DIALOG_CONTENT_BASE = "fixed left-1/2 top-1/2 z-modal grid w-full max-w-lg -translate-x-1/2 -translate-y-1/2 gap-4 border border-border bg-background p-6 shadow-lg sm:rounded-lg";
declare const DIALOG_HEADER_BASE = "flex flex-col space-y-1.5 text-center sm:text-left";
declare const DIALOG_FOOTER_BASE = "flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2";
declare const DIALOG_TITLE_BASE = "text-lg font-semibold leading-none tracking-tight";
declare const DIALOG_DESCRIPTION_BASE = "text-sm text-muted-foreground";

type CrsdToastVariant = 'default' | 'success' | 'error' | 'warning' | 'info';
interface CrsdToastOptions {
    description?: string;
    duration?: number;
    variant?: CrsdToastVariant;
    /** Use cursed personality copy (auto when CrsdThemeService is cursed unless false). */
    cursedCopy?: boolean;
    /** Use blessed personality copy (auto when CrsdThemeService is blessed unless false). */
    blessedCopy?: boolean;
}
interface CrsdToastData {
    id: string;
    title: string;
    description?: string;
    variant: CrsdToastVariant;
    duration: number;
}
declare const TOAST_BASE = "pointer-events-auto relative w-full overflow-hidden rounded-md border border-border p-4 pr-9 shadow-lg transition-all";
declare const TOAST_VARIANTS: Record<CrsdToastVariant, string>;
declare const TOAST_RICH_VARIANTS: Record<CrsdToastVariant, string>;
declare const TOASTER_BASE = "fixed top-0 z-toast flex max-h-screen w-full flex-col-reverse gap-2 p-4 sm:bottom-0 sm:right-0 sm:top-auto sm:flex-col md:max-w-[420px]";

declare class CrsdToaster {
    readonly userClass: _angular_core.InputSignal<string>;
    readonly richColors: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private readonly toastService;
    constructor();
    readonly toasts: _angular_core.WritableSignal<_mentros_crsd_ui.CrsdToastData[]>;
    readonly hostClasses: _angular_core.Signal<string>;
    toastClasses(variant: keyof typeof TOAST_VARIANTS): string;
    dismiss(id: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdToaster, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdToaster, "crsd-toaster", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; "richColors": { "alias": "richColors"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class CrsdToastService {
    readonly toasts: _angular_core.WritableSignal<CrsdToastData[]>;
    private readonly themeService;
    private nextId;
    show(title: string, options?: CrsdToastOptions): string;
    success(title: string, options?: Omit<CrsdToastOptions, 'variant'>): string;
    error(title: string, options?: Omit<CrsdToastOptions, 'variant'>): string;
    warning(title: string, options?: Omit<CrsdToastOptions, 'variant'>): string;
    info(title: string, options?: Omit<CrsdToastOptions, 'variant'>): string;
    cursed(variant?: CrsdToastVariant, options?: Omit<CrsdToastOptions, 'variant' | 'cursedCopy'>): string;
    blessed(variant?: CrsdToastVariant, options?: Omit<CrsdToastOptions, 'variant' | 'blessedCopy'>): string;
    dismiss(id: string): void;
    dismissAll(): void;
    private shouldUseCursedCopy;
    private shouldUseBlessedCopy;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdToastService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<any>;
}
declare const toast: {
    show: (title: string, options?: CrsdToastOptions) => string;
    success: (title: string, options?: Omit<CrsdToastOptions, "variant">) => string;
    error: (title: string, options?: Omit<CrsdToastOptions, "variant">) => string;
    warning: (title: string, options?: Omit<CrsdToastOptions, "variant">) => string;
    info: (title: string, options?: Omit<CrsdToastOptions, "variant">) => string;
    cursed: (variant?: CrsdToastVariant, options?: Omit<CrsdToastOptions, "variant" | "cursedCopy">) => string;
    blessed: (variant?: CrsdToastVariant, options?: Omit<CrsdToastOptions, "variant" | "blessedCopy">) => string;
    dismiss: (id: string) => void;
    dismissAll: () => void;
};

interface CrsdOption<T = string> {
    value: T;
    label: string;
    disabled?: boolean;
}
declare function normalizeOptions<T>(options: readonly (CrsdOption<T> | T)[]): CrsdOption<T>[];

declare class CrsdSelectPortal {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSelectPortal, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSelectPortal, "[crsdSelectPortal]", never, {}, {}, never, never, true, never>;
}
declare class CrsdSelectTriggerHost {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSelectTriggerHost, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSelectTriggerHost, "[crsdSelectTriggerHost]", never, {}, {}, never, never, true, never>;
}
declare class CrsdSelectValueTemplate {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSelectValueTemplate, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSelectValueTemplate, "[crsdSelectValueTemplate]", never, {}, {}, never, never, true, never>;
}
declare class CrsdSelect<T = string> {
    readonly value: _angular_core.ModelSignal<T | null>;
    readonly valueChanged: _angular_core.OutputEmitterRef<T | null>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly state: _angular_core.ModelSignal<CrsdOpenState>;
    readonly stateChanged: _angular_core.OutputEmitterRef<CrsdOpenState>;
    readonly listboxId: string;
    readonly activeDescendant: _angular_core.WritableSignal<string | null>;
    readonly valueTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    private readonly portalTemplate;
    private readonly triggerRef;
    private readonly overlayService;
    private readonly viewContainer;
    private readonly destroyRef;
    private overlayRef;
    private outsideClickSub;
    private initialNavigation;
    constructor();
    select(value: T): void;
    navigate(movement: number | 'first' | 'last'): void;
    commitActive(): void;
    toggle(): void;
    setState(next: CrsdOpenState): void;
    private openOverlay;
    private closeOverlay;
    private setActiveOption;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSelect<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSelect<any>, "[crsdSelect]", ["crsdSelect"], { "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "state": { "alias": "state"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "valueChanged": "valueChanged"; "state": "stateChange"; "stateChanged": "stateChanged"; }, ["valueTemplate", "portalTemplate", "triggerRef"], never, true, never>;
}
declare class CrsdSelectValue {
    readonly crsdSelectValue: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSelectValue, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSelectValue, "[crsdSelectValue]", never, { "crsdSelectValue": { "alias": "crsdSelectValue"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdSelectPlaceholder {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSelectPlaceholder, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSelectPlaceholder, "[crsdSelectPlaceholder]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdSelectItem<T = string> {
    private readonly staticClass;
    readonly value: _angular_core.InputSignal<T>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    protected readonly select: CrsdSelect<T>;
    readonly optionId: string;
    readonly selected: _angular_core.Signal<boolean>;
    readonly highlighted: _angular_core.Signal<boolean>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    onSelect(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSelectItem<any>, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSelectItem<any>, "[crsdSelectItem]", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdSelectContent<T = string> {
    private readonly staticClass;
    protected readonly select: CrsdSelect<T>;
    readonly userClass: _angular_core.InputSignal<string>;
    readonly options: _angular_core.InputSignal<readonly (T | CrsdOption<T>)[] | undefined>;
    constructor(staticClass: string | null);
    readonly normalizedOptions: _angular_core.Signal<CrsdOption<T>[]>;
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSelectContent<any>, [{ attribute: "class"; }]>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdSelectContent<any>, "[crsdSelectContent]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

type CrsdSelectTriggerSize = 'sm' | 'md' | 'lg';
declare const SELECT_TRIGGER_BASE = "flex w-full cursor-pointer items-center justify-between gap-2 rounded-md border border-input bg-background text-left text-sm ring-offset-background transition-colors hover:bg-muted/50 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0";
declare const SELECT_TRIGGER_SIZES: Record<CrsdSelectTriggerSize, string>;
declare const SELECT_CONTENT_BASE = "z-modal max-h-60 w-full overflow-auto rounded-md border border-border bg-popover p-1 text-popover-foreground shadow-md";
declare const SELECT_ITEM_BASE = "relative flex w-full cursor-pointer select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none hover:bg-muted focus:bg-muted data-[disabled]:pointer-events-none data-[disabled]:opacity-50";
declare const SELECT_PLACEHOLDER_BASE = "text-muted-foreground";

declare class CrsdSelectTrigger {
    private readonly staticClass;
    protected readonly select: CrsdSelect<any>;
    readonly size: _angular_core.InputSignal<CrsdSelectTriggerSize>;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSelectTrigger, [{ attribute: "class"; }]>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdSelectTrigger, "[crsdSelectTrigger]", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, ["[crsdSelectPlaceholder]", "[crsdSelectValue]", "*"], true, [{ directive: typeof CrsdSelectTriggerHost; inputs: {}; outputs: {}; }]>;
}

type CrsdEmptyMediaVariant = 'default' | 'icon';
declare const EMPTY_BASE = "flex min-w-0 flex-1 flex-col items-center justify-center gap-6 rounded-lg border border-dashed border-border p-6 text-center";
declare const EMPTY_HEADER_BASE = "flex max-w-sm flex-col items-center gap-2";
declare const EMPTY_MEDIA_BASE = "flex shrink-0 items-center justify-center text-muted-foreground";
declare const EMPTY_MEDIA_ICON_VARIANT = "mb-2 rounded-full bg-muted p-3 text-muted-foreground [&_img]:size-6 [&_svg]:size-6";
declare const EMPTY_TITLE_BASE = "text-lg font-semibold tracking-tight";
declare const EMPTY_DESCRIPTION_BASE = "text-sm text-muted-foreground";

declare class CrsdEmpty {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdEmpty, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdEmpty, "[crsdEmpty]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdEmptyHeader {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdEmptyHeader, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdEmptyHeader, "[crsdEmptyHeader]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdEmptyMedia {
    private readonly staticClass;
    readonly variant: _angular_core.InputSignal<CrsdEmptyMediaVariant>;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdEmptyMedia, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdEmptyMedia, "[crsdEmptyMedia]", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdEmptyTitle {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdEmptyTitle, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdEmptyTitle, "[crsdEmptyTitle]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdEmptyDescription {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdEmptyDescription, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdEmptyDescription, "[crsdEmptyDescription]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type CrsdSheetSide = 'left' | 'right' | 'top' | 'bottom';
declare const SHEET_CONTENT_BASE = "fixed z-modal flex flex-col gap-4 border border-border bg-background p-6 shadow-lg transition ease-in-out";
declare const SHEET_SIDES: Record<CrsdSheetSide, string>;

declare class CrsdSheetPortal {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSheetPortal, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSheetPortal, "[crsdSheetPortal]", never, {}, {}, never, never, true, never>;
}
declare class CrsdSheet {
    readonly state: _angular_core.ModelSignal<CrsdOpenState>;
    readonly stateChanged: _angular_core.OutputEmitterRef<CrsdOpenState>;
    readonly side: _angular_core.InputSignal<CrsdSheetSide>;
    readonly closeOnBackdropClick: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly titleId: string;
    readonly descriptionId: string;
    private readonly portalTemplate;
    private readonly overlayService;
    private readonly viewContainer;
    private readonly destroyRef;
    private overlayRef;
    private triggerElement;
    constructor();
    open(from?: HTMLElement): void;
    close(): void;
    setState(next: CrsdOpenState): void;
    private attachOverlay;
    private detachOverlay;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSheet, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSheet, "[crsdSheet]", ["crsdSheet"], { "state": { "alias": "state"; "required": false; "isSignal": true; }; "side": { "alias": "side"; "required": false; "isSignal": true; }; "closeOnBackdropClick": { "alias": "closeOnBackdropClick"; "required": false; "isSignal": true; }; }, { "state": "stateChange"; "stateChanged": "stateChanged"; }, ["portalTemplate"], never, true, never>;
}
declare class CrsdSheetTrigger {
    private readonly sheet;
    private readonly elementRef;
    onClick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSheetTrigger, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSheetTrigger, "[crsdSheetTrigger]", never, {}, {}, never, never, true, never>;
}
declare class CrsdSheetClose {
    protected readonly sheet: CrsdSheet;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSheetClose, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSheetClose, "[crsdSheetClose]", never, {}, {}, never, never, true, never>;
}
declare class CrsdSheetContent {
    private readonly staticClass;
    protected readonly sheet: CrsdSheet;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSheetContent, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSheetContent, "[crsdSheetContent]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof CrsdFocusTrap; inputs: {}; outputs: {}; }]>;
}
declare class CrsdSheetHeader {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSheetHeader, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSheetHeader, "[crsdSheetHeader]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdSheetTitle {
    private readonly staticClass;
    protected readonly sheet: CrsdSheet;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSheetTitle, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSheetTitle, "[crsdSheetTitle]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdSheetDescription {
    private readonly staticClass;
    protected readonly sheet: CrsdSheet;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSheetDescription, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSheetDescription, "[crsdSheetDescription]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdSheetFooter {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSheetFooter, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSheetFooter, "[crsdSheetFooter]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class CrsdMenu {
    private readonly staticClass;
    readonly escaped: _angular_core.OutputEmitterRef<void>;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly elementRef;
    private typeahead;
    private typeaheadTimer;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    focusFirst(): void;
    onFocus(event: FocusEvent): void;
    onKeydown(event: KeyboardEvent): void;
    private focusItem;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdMenu, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdMenu, "[crsdMenu]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, { "escaped": "escaped"; }, never, never, true, never>;
}
declare class CrsdMenuItem {
    private readonly staticClass;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdMenuItem, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdMenuItem, "[crsdMenuItem]", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdMenuLabel {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdMenuLabel, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdMenuLabel, "[crsdMenuLabel]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdMenuGroup {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdMenuGroup, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdMenuGroup, "[crsdMenuGroup]", never, {}, {}, never, never, true, never>;
}
declare class CrsdMenuRadioItem {
    private readonly staticClass;
    readonly value: _angular_core.InputSignal<string>;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly group;
    constructor(staticClass: string | null);
    readonly selected: _angular_core.Signal<boolean>;
    readonly hostClasses: _angular_core.Signal<string>;
    select(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdMenuRadioItem, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdMenuRadioItem, "[crsdMenuRadioItem]", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdMenuRadioGroup {
    readonly value: _angular_core.ModelSignal<string>;
    readonly options: _angular_core.InputSignal<readonly (string | CrsdOption<string>)[] | undefined>;
    readonly normalizedOptions: _angular_core.Signal<CrsdOption<string>[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdMenuRadioGroup, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdMenuRadioGroup, "[crsdMenuRadioGroup]", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, ["*"], true, never>;
}
declare class CrsdMenuRadioIndicator {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdMenuRadioIndicator, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdMenuRadioIndicator, "[crsdMenuRadioIndicator]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const MENU_CONTENT_BASE = "z-modal min-w-[8rem] overflow-hidden rounded-md border border-border bg-popover p-1 text-popover-foreground shadow-md";
declare const MENU_ITEM_BASE = "relative flex cursor-pointer select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none hover:bg-muted focus:bg-muted data-[disabled]:pointer-events-none data-[disabled]:opacity-50";
declare const MENU_LABEL_BASE = "px-2 py-1.5 text-sm font-semibold";

declare class CrsdDropdownMenuPortal {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdDropdownMenuPortal, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdDropdownMenuPortal, "[crsdDropdownMenuPortal]", never, {}, {}, never, never, true, never>;
}
declare class CrsdDropdownMenuTrigger {
    protected readonly menu: CrsdDropdownMenu;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdDropdownMenuTrigger, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdDropdownMenuTrigger, "[crsdDropdownMenuTrigger]", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdDropdownMenu {
    readonly state: _angular_core.ModelSignal<CrsdOpenState>;
    readonly stateChanged: _angular_core.OutputEmitterRef<CrsdOpenState>;
    private readonly portalTemplate;
    private readonly triggerRef;
    private readonly overlayService;
    private readonly viewContainer;
    private readonly destroyRef;
    private overlayRef;
    private outsideClickSub;
    constructor();
    toggle(): void;
    close(): void;
    setState(next: CrsdOpenState): void;
    private openOverlay;
    private readonly onMenuClick;
    private closeOverlay;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdDropdownMenu, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdDropdownMenu, "[crsdDropdownMenu]", ["crsdDropdownMenu"], { "state": { "alias": "state"; "required": false; "isSignal": true; }; }, { "state": "stateChange"; "stateChanged": "stateChanged"; }, ["portalTemplate", "triggerRef"], never, true, never>;
}
declare class CrsdDropdownMenuContent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdDropdownMenuContent, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdDropdownMenuContent, "[crsdDropdownMenuContent]", never, {}, {}, never, never, true, never>;
}

declare class CrsdContextMenuPortal {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdContextMenuPortal, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdContextMenuPortal, "[crsdContextMenuPortal]", never, {}, {}, never, never, true, never>;
}
declare class CrsdContextMenuTrigger {
    protected readonly menu: CrsdContextMenu;
    private readonly destroyRef;
    constructor();
    onContextMenu(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdContextMenuTrigger, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdContextMenuTrigger, "[crsdContextMenuTrigger]", never, {}, {}, never, never, true, never>;
}
declare class CrsdContextMenu {
    readonly state: _angular_core.ModelSignal<CrsdOpenState>;
    readonly stateChanged: _angular_core.OutputEmitterRef<CrsdOpenState>;
    private readonly portalTemplate;
    private readonly triggerRef;
    private readonly overlayService;
    private readonly viewContainer;
    private readonly destroyRef;
    private overlayRef;
    private lastPosition;
    private previouslyFocused;
    constructor();
    openAt(x: number, y: number): void;
    close(): void;
    setState(next: CrsdOpenState): void;
    private openOverlay;
    private closeOverlay;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdContextMenu, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdContextMenu, "[crsdContextMenu]", ["crsdContextMenu"], { "state": { "alias": "state"; "required": false; "isSignal": true; }; }, { "state": "stateChange"; "stateChanged": "stateChanged"; }, ["portalTemplate", "triggerRef"], never, true, never>;
}
declare class CrsdContextMenuContent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdContextMenuContent, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdContextMenuContent, "[crsdContextMenuContent]", never, {}, {}, never, never, true, never>;
}

declare class CrsdComboboxComponent<T = string> {
    readonly value: _angular_core.ModelSignal<T[]>;
    readonly options: _angular_core.InputSignal<readonly (T | CrsdOption<T>)[]>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly filterPlaceholder: _angular_core.InputSignal<string>;
    readonly emptyLabel: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdComboboxComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdComboboxComponent<any>, "crsd-combobox", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": true; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "emptyLabel": { "alias": "emptyLabel"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

declare class CrsdComboboxPortal {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdComboboxPortal, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdComboboxPortal, "[crsdComboboxPortal]", never, {}, {}, never, never, true, never>;
}
declare class CrsdComboboxChip {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdComboboxChip, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdComboboxChip, "[crsdComboboxChip]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdComboboxTriggerHost {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdComboboxTriggerHost, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdComboboxTriggerHost, "[crsdComboboxTriggerHost]", never, {}, {}, never, never, true, never>;
}
declare class CrsdComboboxValues {
    readonly templateRef: TemplateRef<any>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdComboboxValues, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdComboboxValues, "[crsdComboboxValues]", never, {}, {}, never, never, true, never>;
}
declare class CrsdCombobox<T = string> {
    readonly value: _angular_core.ModelSignal<T[]>;
    readonly valueChanged: _angular_core.OutputEmitterRef<T[]>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly state: _angular_core.ModelSignal<CrsdOpenState>;
    readonly filter: _angular_core.WritableSignal<string>;
    readonly options: _angular_core.InputSignal<readonly (T | CrsdOption<T>)[] | undefined>;
    readonly emptyLabel: _angular_core.InputSignal<string | undefined>;
    readonly itemToString: _angular_core.InputSignal<(item: T) => string>;
    readonly isItemEqualToValue: _angular_core.InputSignal<(a: T, b: T) => boolean>;
    readonly listboxId: string;
    readonly activeDescendant: _angular_core.WritableSignal<string | null>;
    private readonly labels;
    private readonly portalTemplate;
    private readonly triggerRef;
    private readonly overlayService;
    private readonly viewContainer;
    private readonly destroyRef;
    private overlayRef;
    private outsideClickSub;
    private initialNavigation;
    constructor();
    toggle(): void;
    add(item: T): void;
    remove(item: T): void;
    containsValue(item: T): boolean;
    itemKey(item: T): string;
    setFilter(text: string): void;
    clearFilter(): void;
    registerItemLabel(value: T, label: string): void;
    labelFor(value: T): string;
    navigate(movement: number | 'first' | 'last'): void;
    commitActive(): void;
    private openOverlay;
    private closeOverlay;
    private activateFirstVisible;
    private setActiveOption;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdCombobox<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdCombobox<any>, "[crsdCombobox]", ["crsdCombobox"], { "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "state": { "alias": "state"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "emptyLabel": { "alias": "emptyLabel"; "required": false; "isSignal": true; }; "itemToString": { "alias": "itemToString"; "required": false; "isSignal": true; }; "isItemEqualToValue": { "alias": "isItemEqualToValue"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "valueChanged": "valueChanged"; "state": "stateChange"; }, ["portalTemplate", "triggerRef"], never, true, never>;
}

declare class CrsdComboboxPanel {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdComboboxPanel, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdComboboxPanel, "[crsdComboboxPanel]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdComboboxFilter {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdComboboxFilter, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdComboboxFilter, "[crsdComboboxFilter]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdComboboxItem<T = string> {
    private readonly staticClass;
    readonly value: _angular_core.InputSignal<T>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    protected readonly combobox: CrsdCombobox<T>;
    readonly optionId: string;
    private readonly elementRef;
    constructor(staticClass: string | null);
    readonly selected: _angular_core.Signal<boolean>;
    readonly highlighted: _angular_core.Signal<boolean>;
    readonly filteredOut: _angular_core.Signal<boolean>;
    isFilteredOut(): boolean;
    readonly hostClasses: _angular_core.Signal<string>;
    toggle(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdComboboxItem<any>, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdComboboxItem<any>, "[crsdComboboxItem]", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdComboboxEmpty {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly combobox;
    private readonly content;
    constructor(staticClass: string | null);
    readonly shouldHide: _angular_core.Signal<boolean>;
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdComboboxEmpty, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdComboboxEmpty, "[crsdComboboxEmpty]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdComboboxContent<T = string> {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    readonly options: _angular_core.InputSignal<readonly (T | CrsdOption<T>)[] | undefined>;
    readonly emptyLabel: _angular_core.InputSignal<string | undefined>;
    protected readonly combobox: CrsdCombobox<T>;
    private readonly items;
    constructor(staticClass: string | null);
    readonly resolvedOptions: _angular_core.Signal<readonly (T | CrsdOption<T>)[] | undefined>;
    readonly resolvedEmptyLabel: _angular_core.Signal<string | undefined>;
    readonly visibleOptions: _angular_core.Signal<CrsdOption<T>[]>;
    readonly hasVisibleItems: _angular_core.Signal<boolean>;
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdComboboxContent<any>, [{ attribute: "class"; }]>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdComboboxContent<any>, "[crsdComboboxContent]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "emptyLabel": { "alias": "emptyLabel"; "required": false; "isSignal": true; }; }, {}, ["items"], ["*"], true, never>;
}
declare class CrsdComboboxInput {
    protected readonly combobox: CrsdCombobox<any>;
    onInput(event: Event): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdComboboxInput, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdComboboxInput, "[crsdComboboxInput]", never, {}, {}, never, never, true, never>;
}
declare class CrsdComboboxChipInput {
    protected readonly combobox: CrsdCombobox<any>;
    onInput(event: Event): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdComboboxChipInput, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdComboboxChipInput, "[crsdComboboxChipInput]", never, {}, {}, never, never, true, never>;
}

declare class CrsdComboboxTrigger {
    private readonly staticClass;
    protected readonly combobox: CrsdCombobox<any>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly custom: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly valuesTemplateRef;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    readonly valuesTemplate: _angular_core.Signal<CrsdComboboxValues | null>;
    protected removeItem(item: unknown): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdComboboxTrigger, [{ attribute: "class"; }]>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdComboboxTrigger, "[crsdComboboxTrigger]", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "custom": { "alias": "custom"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, ["valuesTemplateRef"], ["*"], true, [{ directive: typeof CrsdComboboxTriggerHost; inputs: {}; outputs: {}; }]>;
}

declare const COMBOBOX_TRIGGER_BASE = "flex min-h-10 w-full cursor-pointer flex-wrap items-center gap-1.5 rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background transition-colors hover:bg-muted/50 focus-within:outline-none focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-2 [&_svg]:ml-auto [&_svg]:size-4 [&_svg]:shrink-0";
declare const COMBOBOX_CHIP_BASE = "inline-flex items-center gap-1 rounded-md bg-secondary px-2 py-0.5 text-xs font-medium text-secondary-foreground";
declare const COMBOBOX_PANEL_BASE = "z-modal w-full overflow-hidden rounded-md border border-border bg-popover text-popover-foreground shadow-md";
declare const COMBOBOX_CONTENT_BASE = "max-h-60 w-full overflow-auto p-1";
declare const COMBOBOX_FILTER_BASE = "border-b border-border p-2";

declare class CrsdAutocompleteComponent {
    readonly value: _angular_core.ModelSignal<string>;
    readonly options: _angular_core.InputSignal<readonly (string | CrsdOption<string>)[]>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly emptyLabel: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showOptionsAt: _angular_core.InputSignal<number>;
    readonly maxOptions: _angular_core.InputSignal<number | undefined>;
    readonly type: _angular_core.InputSignal<string>;
    readonly spellcheck: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdAutocompleteComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdAutocompleteComponent, "crsd-autocomplete", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": true; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "emptyLabel": { "alias": "emptyLabel"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "showOptionsAt": { "alias": "showOptionsAt"; "required": false; "isSignal": true; }; "maxOptions": { "alias": "maxOptions"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "spellcheck": { "alias": "spellcheck"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

type CrsdAutocompleteFilterFn = (query: string, option: CrsdOption<string>) => boolean;
declare function defaultAutocompleteFilter(query: string, option: CrsdOption<string>): boolean;
declare class CrsdAutocompletePortal {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdAutocompletePortal, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdAutocompletePortal, "[crsdAutocompletePortal]", never, {}, {}, never, never, true, never>;
}
declare class CrsdAutocompleteTriggerHost {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdAutocompleteTriggerHost, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdAutocompleteTriggerHost, "[crsdAutocompleteTriggerHost]", never, {}, {}, never, never, true, never>;
}
declare class CrsdAutocomplete {
    readonly value: _angular_core.ModelSignal<string>;
    readonly valueChanged: _angular_core.OutputEmitterRef<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly state: _angular_core.ModelSignal<CrsdOpenState>;
    readonly stateChanged: _angular_core.OutputEmitterRef<CrsdOpenState>;
    readonly options: _angular_core.InputSignal<readonly (string | CrsdOption<string>)[] | undefined>;
    readonly emptyLabel: _angular_core.InputSignal<string | undefined>;
    readonly showOptionsAt: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly maxOptions: _angular_core.InputSignal<number | undefined>;
    readonly filterOption: _angular_core.InputSignal<CrsdAutocompleteFilterFn>;
    readonly listboxId: string;
    readonly highlightedIndex: _angular_core.WritableSignal<number>;
    readonly optionIds: _angular_core.WritableSignal<string[]>;
    private readonly portalTemplate;
    private readonly triggerRef;
    private readonly overlayService;
    private readonly viewContainer;
    private readonly destroyRef;
    private overlayRef;
    private outsideClickSub;
    readonly normalizedOptions: _angular_core.Signal<CrsdOption<string>[]>;
    readonly visibleOptions: _angular_core.Signal<CrsdOption<string>[]>;
    constructor();
    canOpen(): boolean;
    evaluateOpen(): void;
    setValue(next: string): void;
    commit(optionValue: string): void;
    setState(next: CrsdOpenState): void;
    moveHighlight(delta: number): void;
    commitHighlighted(): void;
    highlightedOptionId(): string | null;
    isHighlighted(index: number): boolean;
    private openOverlay;
    private closeOverlay;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdAutocomplete, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdAutocomplete, "[crsdAutocomplete]", ["crsdAutocomplete"], { "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "state": { "alias": "state"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "emptyLabel": { "alias": "emptyLabel"; "required": false; "isSignal": true; }; "showOptionsAt": { "alias": "showOptionsAt"; "required": false; "isSignal": true; }; "maxOptions": { "alias": "maxOptions"; "required": false; "isSignal": true; }; "filterOption": { "alias": "filterOption"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "valueChanged": "valueChanged"; "state": "stateChange"; "stateChanged": "stateChanged"; }, ["portalTemplate", "triggerRef"], never, true, never>;
}

declare class CrsdAutocompleteTrigger {
    protected readonly autocomplete: CrsdAutocomplete;
    private readonly crsdInput;
    constructor();
    readonly activeDescendant: _angular_core.Signal<string | null>;
    onFocus(): void;
    onInput(event: Event): void;
    onTab(): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdAutocompleteTrigger, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdAutocompleteTrigger, "[crsdAutocompleteTrigger]", never, {}, {}, never, never, true, [{ directive: typeof CrsdAutocompleteTriggerHost; inputs: {}; outputs: {}; }]>;
}
declare class CrsdAutocompleteItem {
    private readonly staticClass;
    readonly value: _angular_core.InputSignal<string>;
    readonly index: _angular_core.InputSignal<number | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    protected readonly autocomplete: CrsdAutocomplete;
    constructor(staticClass: string | null);
    readonly optionId: _angular_core.Signal<string | null>;
    readonly highlighted: _angular_core.Signal<boolean>;
    readonly selected: _angular_core.Signal<boolean>;
    readonly hostClasses: _angular_core.Signal<string>;
    onSelect(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdAutocompleteItem, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdAutocompleteItem, "[crsdAutocompleteItem]", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; "index": { "alias": "index"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdAutocompleteEmpty {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly autocomplete;
    constructor(staticClass: string | null);
    readonly shouldHide: _angular_core.Signal<boolean>;
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdAutocompleteEmpty, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdAutocompleteEmpty, "[crsdAutocompleteEmpty]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdAutocompleteContent {
    private readonly staticClass;
    protected readonly autocomplete: CrsdAutocomplete;
    readonly userClass: _angular_core.InputSignal<string>;
    readonly options: _angular_core.InputSignal<readonly (string | CrsdOption<string>)[] | undefined>;
    readonly emptyLabel: _angular_core.InputSignal<string | undefined>;
    constructor(staticClass: string | null);
    readonly itemValueClass = "min-w-0 flex-1 truncate text-left";
    readonly itemHintClass = "ml-auto max-w-[50%] shrink-0 truncate text-right text-muted-foreground";
    readonly resolvedOptions: _angular_core.Signal<readonly (string | CrsdOption<string>)[] | undefined>;
    readonly resolvedEmptyLabel: _angular_core.Signal<string | undefined>;
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdAutocompleteContent, [{ attribute: "class"; }]>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdAutocompleteContent, "[crsdAutocompleteContent]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "emptyLabel": { "alias": "emptyLabel"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare const AUTOCOMPLETE_CONTENT_BASE = "z-modal max-h-60 w-full overflow-auto rounded-md border border-border bg-popover p-1 text-popover-foreground shadow-md";
declare const AUTOCOMPLETE_ITEM_BASE = "relative flex w-full cursor-pointer select-none items-center gap-2 rounded-sm py-1.5 px-2 text-sm outline-none hover:bg-muted focus:bg-muted data-[disabled]:pointer-events-none data-[disabled]:opacity-50";
declare const AUTOCOMPLETE_ITEM_VALUE = "min-w-0 flex-1 truncate text-left";
declare const AUTOCOMPLETE_ITEM_HINT = "ml-auto max-w-[50%] shrink-0 truncate text-right text-muted-foreground";
declare const AUTOCOMPLETE_EMPTY_BASE = "py-6 text-center text-sm text-muted-foreground";

type CrsdSidebarState = 'expanded' | 'collapsed';
declare const SIDEBAR_BASE = "flex h-full w-[var(--crsd-sidebar-width)] flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground transition-[width] duration-200 ease-linear";
declare const SIDEBAR_MENU_BUTTON_BASE = "flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm outline-none hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 focus-visible:ring-sidebar-ring disabled:pointer-events-none disabled:opacity-50";

type CrsdSidebarCollapsible = 'none' | 'icon';
declare class CrsdSidebarWrapper {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    readonly sidebarContainerClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSidebarWrapper, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSidebarWrapper, "[crsdSidebarWrapper]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; "sidebarContainerClass": { "alias": "sidebarContainerClass"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdSidebar {
    private readonly staticClass;
    readonly collapsible: _angular_core.InputSignal<CrsdSidebarCollapsible>;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly sidebarService;
    constructor(staticClass: string | null);
    readonly effectiveState: _angular_core.Signal<CrsdSidebarState>;
    readonly sidebarWidth: _angular_core.Signal<"3rem" | "16rem">;
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSidebar, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSidebar, "[crsdSidebar]", never, { "collapsible": { "alias": "collapsible"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdSidebarHeader {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSidebarHeader, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSidebarHeader, "[crsdSidebarHeader]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdSidebarContent {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSidebarContent, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSidebarContent, "[crsdSidebarContent]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdSidebarFooter {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSidebarFooter, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSidebarFooter, "[crsdSidebarFooter]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdSidebarMenu {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly sidebarService;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSidebarMenu, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSidebarMenu, "[crsdSidebarMenu]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdSidebarMenuItem {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSidebarMenuItem, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSidebarMenuItem, "[crsdSidebarMenuItem]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdSidebarMenuLabel {
    private readonly sidebarService;
    readonly isCollapsed: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSidebarMenuLabel, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSidebarMenuLabel, "[crsdSidebarMenuLabel]", never, {}, {}, never, never, true, never>;
}
declare class CrsdSidebarMenuButton {
    private readonly staticClass;
    readonly tooltip: _angular_core.InputSignal<string>;
    readonly isActive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly sidebarService;
    private readonly elementRef;
    private readonly overlayService;
    private readonly idService;
    private readonly destroyRef;
    private overlayRef;
    constructor(staticClass: string | null);
    readonly isCollapsed: _angular_core.Signal<boolean>;
    readonly hostClasses: _angular_core.Signal<string>;
    private openTooltip;
    private closeTooltip;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSidebarMenuButton, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdSidebarMenuButton, "[crsdSidebarMenuButton]", never, { "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "isActive": { "alias": "isActive"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class CrsdSidebarService {
    readonly state: _angular_core.WritableSignal<CrsdSidebarState>;
    toggleSidebar(): void;
    expand(): void;
    collapse(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSidebarService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<any>;
}

interface CrsdIconMultiselectOption {
    key: string;
    name: string;
    iconUrl: string;
    accent?: string;
}
declare class CrsdIconMultiselect {
    readonly label: _angular_core.InputSignal<string>;
    readonly labelId: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly emptyLabel: _angular_core.InputSignal<string>;
    readonly options: _angular_core.InputSignal<readonly CrsdIconMultiselectOption[]>;
    readonly value: _angular_core.ModelSignal<CrsdIconMultiselectOption[]>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly generatedLabelId;
    readonly hostClasses: _angular_core.Signal<string>;
    readonly resolvedLabelId: _angular_core.Signal<string>;
    protected readonly itemToString: (option: CrsdIconMultiselectOption) => string;
    protected readonly isItemEqualToValue: (a: CrsdIconMultiselectOption, b: CrsdIconMultiselectOption) => boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdIconMultiselect, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdIconMultiselect, "crsd-icon-multiselect", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "labelId": { "alias": "labelId"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "emptyLabel": { "alias": "emptyLabel"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, never, true, never>;
}

interface CrsdSearchPickerOption {
    id: string | number | null;
    label: string;
    imageUrl?: string;
}
declare class CrsdSearchPicker {
    readonly options: _angular_core.InputSignal<readonly CrsdSearchPickerOption[]>;
    readonly selectedId: _angular_core.ModelSignal<string | number | null>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly emptyLabel: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly elementRef;
    readonly listboxId: string;
    readonly emptyOptionId: string;
    protected readonly open: _angular_core.WritableSignal<boolean>;
    protected readonly query: _angular_core.WritableSignal<string>;
    protected readonly activeOptionId: _angular_core.WritableSignal<string | null>;
    protected readonly panelAbove: _angular_core.WritableSignal<boolean>;
    protected readonly panelMaxHeight: _angular_core.WritableSignal<number | null>;
    protected readonly listMaxHeight: _angular_core.WritableSignal<number | null>;
    protected readonly panelTop: _angular_core.WritableSignal<number | null>;
    protected readonly panelLeft: _angular_core.WritableSignal<number | null>;
    protected readonly panelWidth: _angular_core.WritableSignal<number | null>;
    private static readonly VIEWPORT_EDGE_PADDING_PX;
    private static readonly PANEL_GAP_PX;
    private static readonly PANEL_CHROME_PX;
    private static readonly DEFAULT_LIST_MAX_HEIGHT_PX;
    readonly hostClasses: _angular_core.Signal<string>;
    protected readonly selectedOption: _angular_core.Signal<CrsdSearchPickerOption | null>;
    protected readonly filteredOptions: _angular_core.Signal<readonly CrsdSearchPickerOption[]>;
    constructor();
    protected toggleOpen(event: Event): void;
    protected selectOption(id: string | number | null, event: Event): void;
    protected close(): void;
    protected onQueryInput(event: Event): void;
    protected onTriggerKeydown(event: KeyboardEvent): void;
    protected onListboxKeydown(event: KeyboardEvent): void;
    protected onDocumentClick(event: MouseEvent): void;
    protected onDocumentScroll(event: Event): void;
    private updatePanelLayout;
    private resetPanelLayout;
    protected optionId(id: string | number | null): string;
    private visibleOptionIds;
    private activateSelectedOrFirst;
    private moveActive;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSearchPicker, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdSearchPicker, "crsd-search-picker", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; "selectedId": { "alias": "selectedId"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "emptyLabel": { "alias": "emptyLabel"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, { "selectedId": "selectedIdChange"; }, never, never, true, never>;
}

interface CrsdAvatarGridItem {
    imageUrl: string;
    label: string;
    subtitle?: string;
    borderColor?: string;
}
declare class CrsdAvatarGrid {
    readonly items: _angular_core.InputSignal<readonly CrsdAvatarGridItem[]>;
    readonly userClass: _angular_core.InputSignal<string>;
    readonly columns: _angular_core.InputSignal<number>;
    readonly hostClasses: _angular_core.Signal<string>;
    readonly gridTemplateColumns: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdAvatarGrid, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdAvatarGrid, "crsd-avatar-grid", never, { "items": { "alias": "items"; "required": true; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class CrsdFlipCard {
    readonly flipped: _angular_core.ModelSignal<boolean>;
    readonly durationMs: _angular_core.InputSignal<number>;
    readonly flipOnClick: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    private readonly front;
    private readonly back;
    constructor();
    flip(): void;
    onHostClick(event: MouseEvent): void;
    readonly hostClasses: _angular_core.Signal<string>;
    readonly innerClasses: _angular_core.Signal<string>;
    private setFaceHidden;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdFlipCard, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdFlipCard, "crsd-flip-card", ["crsdFlipCard"], { "flipped": { "alias": "flipped"; "required": false; "isSignal": true; }; "durationMs": { "alias": "duration"; "required": false; "isSignal": true; }; "flipOnClick": { "alias": "flipOnClick"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, { "flipped": "flippedChange"; }, ["front", "back"], ["[crsdFlipCardFront]", "[crsdFlipCardBack]"], true, never>;
}

declare class CrsdFlipCardFront {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    get hostClasses(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdFlipCardFront, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdFlipCardFront, "[crsdFlipCardFront]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class CrsdFlipCardBack {
    private readonly staticClass;
    readonly userClass: _angular_core.InputSignal<string>;
    constructor(staticClass: string | null);
    get hostClasses(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdFlipCardBack, [{ attribute: "class"; }]>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CrsdFlipCardBack, "[crsdFlipCardBack]", never, { "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const FLIP_CARD_HOST = "group relative block";
declare const FLIP_CARD_HOST_FLIPPED = "z-10";
declare const FLIP_CARD_INNER = "relative h-full w-full motion-safe:[transform-style:preserve-3d] motion-safe:transition-transform motion-reduce:transition-none";
declare const FLIP_CARD_INNER_FLIPPED = "motion-safe:[transform:rotateY(180deg)]";
declare const FLIP_CARD_FACE = "absolute inset-0 motion-safe:[backface-visibility:hidden]";
declare const FLIP_CARD_FACE_FRONT = "motion-reduce:group-data-[flipped=true]:hidden";
declare const FLIP_CARD_FACE_BACK = "motion-safe:[transform:rotateY(180deg)] motion-reduce:hidden motion-reduce:group-data-[flipped=true]:block";

interface CrsdSelectableListItem {
    id: string | number;
    label: string;
    subtitle?: string;
    imageUrl?: string;
    meta?: string;
    badge?: string;
    count?: number;
}
declare class CrsdSelectableList {
    readonly items: _angular_core.InputSignal<readonly CrsdSelectableListItem[]>;
    readonly selectedIds: _angular_core.ModelSignal<(string | number)[]>;
    readonly selectedId: _angular_core.ModelSignal<string | number | null>;
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly searchable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly emptyLabel: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly userClass: _angular_core.InputSignal<string>;
    protected readonly query: _angular_core.ModelSignal<string>;
    readonly listboxId: string;
    protected readonly activeOptionId: _angular_core.WritableSignal<string | null>;
    readonly hostClasses: _angular_core.Signal<string>;
    protected readonly filteredItems: _angular_core.Signal<readonly CrsdSelectableListItem[]>;
    protected isSelected(id: string | number): boolean;
    protected toggleItem(id: string | number): void;
    protected onQueryInput(event: Event): void;
    protected ensureActive(): void;
    protected onKeydown(event: KeyboardEvent): void;
    protected optionId(id: string | number): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdSelectableList, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdSelectableList, "crsd-selectable-list", never, { "items": { "alias": "items"; "required": true; "isSignal": true; }; "selectedIds": { "alias": "selectedIds"; "required": false; "isSignal": true; }; "selectedId": { "alias": "selectedId"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "searchable": { "alias": "searchable"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "emptyLabel": { "alias": "emptyLabel"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; "query": { "alias": "query"; "required": false; "isSignal": true; }; }, { "selectedIds": "selectedIdsChange"; "selectedId": "selectedIdChange"; "query": "queryChange"; }, never, never, true, never>;
}

interface CrsdTieredTextPreviewRow {
    label: string;
    text: string;
}
interface CrsdTieredTextPreviewData {
    preamble?: string | null;
    rows: readonly CrsdTieredTextPreviewRow[];
    rules?: string | null;
}
declare class CrsdTieredTextPreview {
    readonly data: _angular_core.InputSignal<CrsdTieredTextPreviewData | null>;
    readonly fallbackText: _angular_core.InputSignal<string>;
    readonly emptyLabel: _angular_core.InputSignal<string>;
    readonly userClass: _angular_core.InputSignal<string>;
    readonly hostClasses: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdTieredTextPreview, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CrsdTieredTextPreview, "crsd-tiered-text-preview", never, { "data": { "alias": "data"; "required": false; "isSignal": true; }; "fallbackText": { "alias": "fallbackText"; "required": false; "isSignal": true; }; "emptyLabel": { "alias": "emptyLabel"; "required": false; "isSignal": true; }; "userClass": { "alias": "class"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare function cn(...inputs: ClassValue[]): string;

type CrsdColorMode = 'light' | 'dark' | 'system';
type CrsdResolvedColorMode = 'light' | 'dark';
declare class CrsdColorModeService {
    readonly mode: _angular_core.WritableSignal<CrsdColorMode>;
    private readonly systemDark;
    readonly resolved: _angular_core.Signal<CrsdResolvedColorMode>;
    readonly isDark: _angular_core.Signal<boolean>;
    constructor();
    setMode(mode: CrsdColorMode): void;
    toggle(): void;
    private restoreFromStorage;
    private persist;
    private apply;
    private watchSystemPreference;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CrsdColorModeService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<any>;
}
declare function applyCrsdColorModeFromStorage(): void;

declare const CURSED_EMPTY_MESSAGES: {
    readonly titles: readonly ["Nothing here.", "The void stares back.", "No results.", "Empty. Suspiciously empty.", "This page has been abandoned."];
    readonly descriptions: readonly ["Probably for the best.", "The void is listening.", "Try again. Or do not.", "Create something before it notices.", "Your data may have been consumed."];
};
declare function pickCursedEmptyMessage(): {
    title: string;
    description: string;
};

declare const BLESSED_EMPTY_MESSAGES: {
    readonly titles: readonly ["All is calm.", "Room for something beautiful.", "A quiet moment.", "Nothing here yet.", "Space awaits your light."];
    readonly descriptions: readonly ["Create when you are ready.", "The page is resting peacefully.", "Something wonderful could go here.", "Begin with a single step.", "Grace grows in empty places."];
};
declare function pickBlessedEmptyMessage(): {
    title: string;
    description: string;
};

declare const CURSED_TOAST_MESSAGES: Record<CrsdToastVariant, {
    titles: readonly string[];
    descriptions: readonly string[];
}>;
declare function pickCursedToastMessage(variant: CrsdToastVariant): {
    title: string;
    description: string;
};

declare const BLESSED_TOAST_MESSAGES: Record<CrsdToastVariant, {
    titles: readonly string[];
    descriptions: readonly string[];
}>;
declare function pickBlessedToastMessage(variant: CrsdToastVariant): {
    title: string;
    description: string;
};

declare const CURSED_SKELETON_LABELS: readonly ["Null Priest", "Void Walker", "Glitch Entity", "Wrong One", "???"];
declare function pickCursedSkeletonLabel(): string;

declare const CURSED_ICON_SHAPES: {
    readonly check: readonly [{
        readonly type: "path";
        readonly d: "M20 6 9 17l-2-2";
    }, {
        readonly type: "path";
        readonly d: "M6 6l3 3";
    }];
    readonly x: readonly [{
        readonly type: "path";
        readonly d: "M19 5 5 19";
    }, {
        readonly type: "path";
        readonly d: "m7 5 12 12";
    }];
    readonly star: readonly [{
        readonly type: "path";
        readonly d: "M12 2l1.4 4.3 4.6.2-3.6 2.7 1.3 4.5L12 11.8 8.3 14l1.3-4.5-3.6-2.7 4.6-.2L12 2z";
    }, {
        readonly type: "path";
        readonly d: "M4 20l2-6";
    }];
    readonly 'alert-triangle': readonly [{
        readonly type: "path";
        readonly d: "M12 3 2 21h20L12 3z";
    }, {
        readonly type: "path";
        readonly d: "M12 9v5";
    }, {
        readonly type: "path";
        readonly d: "M11 17h2";
    }, {
        readonly type: "path";
        readonly d: "M8 19l8-14";
    }];
    readonly loader: readonly [{
        readonly type: "path";
        readonly d: "M12 2v4";
    }, {
        readonly type: "path";
        readonly d: "M12 18v4";
    }, {
        readonly type: "path";
        readonly d: "m4.93 4.93 2.83 2.83";
    }, {
        readonly type: "path";
        readonly d: "m16.24 16.24 2.83 2.83";
    }, {
        readonly type: "path";
        readonly d: "M2 12h4";
    }, {
        readonly type: "path";
        readonly d: "M18 12h4";
    }];
    readonly heart: readonly [{
        readonly type: "path";
        readonly d: "M12 21s-6-4.35-8-7.5C2.5 10.5 4 7 7 7c1.7 0 3 1 5 3 2-2 3.3-3 5-3 3 0 4.5 3.5 3 6.5-2 3.15-8 7.5-8 7.5z";
    }, {
        readonly type: "path";
        readonly d: "M8 9l2 2 4-4";
    }];
    readonly settings: readonly [{
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "12";
        readonly r: "3";
    }, {
        readonly type: "path";
        readonly d: "M12 2v2";
    }, {
        readonly type: "path";
        readonly d: "M12 20v2";
    }, {
        readonly type: "path";
        readonly d: "m4.93 4.93 1.41 1.41";
    }, {
        readonly type: "path";
        readonly d: "m17.66 17.66 1.41 1.41";
    }, {
        readonly type: "path";
        readonly d: "M2 12h2";
    }, {
        readonly type: "path";
        readonly d: "M20 12h2";
    }];
    readonly user: readonly [{
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "8";
        readonly r: "3.5";
    }, {
        readonly type: "path";
        readonly d: "M6 20c0-3.5 2.7-6 6-6s6 2.5 6 6";
    }, {
        readonly type: "circle";
        readonly cx: "9";
        readonly cy: "7.5";
        readonly r: "0.5";
    }, {
        readonly type: "circle";
        readonly cx: "15";
        readonly cy: "7.5";
        readonly r: "0.5";
    }];
    readonly home: readonly [{
        readonly type: "path";
        readonly d: "M4 11 12 4l8 7";
    }, {
        readonly type: "path";
        readonly d: "M6 10v9h12v-9";
    }, {
        readonly type: "path";
        readonly d: "M10 19V13h4v6";
    }, {
        readonly type: "path";
        readonly d: "M3 21h18";
    }];
    readonly search: readonly [{
        readonly type: "circle";
        readonly cx: "10";
        readonly cy: "10";
        readonly r: "6";
    }, {
        readonly type: "path";
        readonly d: "m21 21-5-5";
    }, {
        readonly type: "path";
        readonly d: "M8 8h4";
    }];
    readonly bell: readonly [{
        readonly type: "path";
        readonly d: "M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9";
    }, {
        readonly type: "path";
        readonly d: "M10 21h4";
    }, {
        readonly type: "path";
        readonly d: "M12 3v2";
    }];
};
type CrsdCursedIconName = keyof typeof CURSED_ICON_SHAPES;

declare const BLESSED_ICON_SHAPES: {
    readonly check: readonly [{
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "12";
        readonly r: "9";
    }, {
        readonly type: "path";
        readonly d: "M8 12.5 10.5 15 16 9";
    }];
    readonly x: readonly [{
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "12";
        readonly r: "9";
    }, {
        readonly type: "path";
        readonly d: "M9 9l6 6";
    }, {
        readonly type: "path";
        readonly d: "m15 9-6 6";
    }];
    readonly star: readonly [{
        readonly type: "path";
        readonly d: "M12 3l2.2 4.5 5 .7-3.6 3.5 1 5.2L12 14.8 7.4 17l1-5.2L4.8 8.2l5-.7L12 3z";
    }, {
        readonly type: "path";
        readonly d: "M12 3v2";
    }];
    readonly 'alert-triangle': readonly [{
        readonly type: "path";
        readonly d: "M12 4.5 20.5 19H3.5L12 4.5z";
    }, {
        readonly type: "path";
        readonly d: "M12 9v4.5";
    }, {
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "16.5";
        readonly r: "0.75";
    }];
    readonly loader: readonly [{
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "12";
        readonly r: "9";
    }, {
        readonly type: "path";
        readonly d: "M12 3v3";
    }, {
        readonly type: "path";
        readonly d: "M12 18v3";
    }, {
        readonly type: "path";
        readonly d: "m4.22 4.22 2.12 2.12";
    }, {
        readonly type: "path";
        readonly d: "m17.66 17.66 2.12 2.12";
    }, {
        readonly type: "path";
        readonly d: "M3 12h3";
    }, {
        readonly type: "path";
        readonly d: "M18 12h3";
    }];
    readonly heart: readonly [{
        readonly type: "path";
        readonly d: "M12 20.5s-5.5-3.8-7.5-6.8C2.8 10.8 4.5 7.5 7.8 7.5c1.6 0 2.8.8 4.2 2.4 1.4-1.6 2.6-2.4 4.2-2.4 3.3 0 5 3.3 3.3 6.2-2 3-7.5 6.8-7.5 6.8z";
    }, {
        readonly type: "path";
        readonly d: "M9 10.5l1.8 1.8L15 8";
    }];
    readonly settings: readonly [{
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "12";
        readonly r: "3.5";
    }, {
        readonly type: "path";
        readonly d: "M12 2.5v2.5";
    }, {
        readonly type: "path";
        readonly d: "M12 19v2.5";
    }, {
        readonly type: "path";
        readonly d: "m4.5 4.5 1.8 1.8";
    }, {
        readonly type: "path";
        readonly d: "m17.7 17.7 1.8 1.8";
    }, {
        readonly type: "path";
        readonly d: "M2.5 12H5";
    }, {
        readonly type: "path";
        readonly d: "M19 12h2.5";
    }];
    readonly user: readonly [{
        readonly type: "circle";
        readonly cx: "12";
        readonly cy: "8.5";
        readonly r: "3.25";
    }, {
        readonly type: "path";
        readonly d: "M6.5 19.5c0-3 2.5-5.5 5.5-5.5s5.5 2.5 5.5 5.5";
    }, {
        readonly type: "path";
        readonly d: "M12 2.5v1.5";
    }];
    readonly home: readonly [{
        readonly type: "path";
        readonly d: "M5 11.5 12 5l7 6.5";
    }, {
        readonly type: "path";
        readonly d: "M7.5 10.5V19h9v-8.5";
    }, {
        readonly type: "path";
        readonly d: "M10 19v-4.5h4V19";
    }, {
        readonly type: "path";
        readonly d: "M4 19.5h16";
    }];
    readonly search: readonly [{
        readonly type: "circle";
        readonly cx: "10.5";
        readonly cy: "10.5";
        readonly r: "5.5";
    }, {
        readonly type: "path";
        readonly d: "m20 20-4.8-4.8";
    }, {
        readonly type: "path";
        readonly d: "M10.5 7.5v6";
    }];
    readonly bell: readonly [{
        readonly type: "path";
        readonly d: "M6.5 9.5a5.5 5.5 0 0 1 11 0c0 6 2.5 7.5 2.5 7.5H4s2.5-1.5 2.5-7.5";
    }, {
        readonly type: "path";
        readonly d: "M10.5 19a1.5 1.5 0 0 0 3 0";
    }, {
        readonly type: "path";
        readonly d: "M12 3.5v1.5";
    }];
};
type CrsdBlessedIconName = keyof typeof BLESSED_ICON_SHAPES;

declare const crsdTailwindPreset: {
    theme: {
        extend: {
            colors: {
                background: string;
                foreground: string;
                card: {
                    DEFAULT: string;
                    foreground: string;
                };
                primary: {
                    DEFAULT: string;
                    foreground: string;
                };
                secondary: {
                    DEFAULT: string;
                    foreground: string;
                };
                destructive: {
                    DEFAULT: string;
                    foreground: string;
                };
                success: {
                    DEFAULT: string;
                    foreground: string;
                };
                warning: {
                    DEFAULT: string;
                    foreground: string;
                };
                info: {
                    DEFAULT: string;
                    foreground: string;
                };
                muted: {
                    DEFAULT: string;
                    foreground: string;
                };
                border: string;
                input: string;
                ring: string;
                popover: {
                    DEFAULT: string;
                    foreground: string;
                };
                sidebar: {
                    DEFAULT: string;
                    foreground: string;
                    primary: string;
                    'primary-foreground': string;
                    accent: string;
                    'accent-foreground': string;
                    border: string;
                    ring: string;
                };
            };
            borderRadius: {
                lg: string;
                md: string;
                sm: string;
            };
            zIndex: {
                overlay: string;
                modal: string;
                toast: string;
                tooltip: string;
            };
        };
    };
};

export { ALERT_BASE, ALERT_DESCRIPTION_BASE, ALERT_TITLE_BASE, ALERT_VARIANTS, AUTOCOMPLETE_CONTENT_BASE, AUTOCOMPLETE_EMPTY_BASE, AUTOCOMPLETE_ITEM_BASE, AUTOCOMPLETE_ITEM_HINT, AUTOCOMPLETE_ITEM_VALUE, BADGE_BASE, BADGE_DISMISS_BTN, BADGE_SIZES, BLESSED_EMPTY_MESSAGES, BLESSED_ICON_SHAPES, BLESSED_TOAST_MESSAGES, BUTTON_BASE, BUTTON_ICON_TYPO, BUTTON_SIZES, CARD_BASE, CARD_CONTENT, CARD_DESCRIPTION, CARD_FOOTER, CARD_HEADER, CARD_TITLE, CARD_VARIANTS, COMBOBOX_CHIP_BASE, COMBOBOX_CONTENT_BASE, COMBOBOX_FILTER_BASE, COMBOBOX_PANEL_BASE, COMBOBOX_TRIGGER_BASE, CRSD_THEME_CONFIG, CRSD_THEME_FEATURES, CURSED_EMPTY_MESSAGES, CURSED_ICON_SHAPES, CURSED_SKELETON_LABELS, CURSED_TOAST_MESSAGES, CrsdAlert, CrsdAlertDescription, CrsdAlertTitle, CrsdAutocomplete, CrsdAutocompleteComponent, CrsdAutocompleteContent, CrsdAutocompleteEmpty, CrsdAutocompleteItem, CrsdAutocompletePortal, CrsdAutocompleteTrigger, CrsdAutocompleteTriggerHost, CrsdAvatarGrid, CrsdBadge, CrsdBadgeDismiss, CrsdBtn, CrsdCard, CrsdCardContent, CrsdCardDescription, CrsdCardFooter, CrsdCardHeader, CrsdCardTitle, CrsdColorModeService, CrsdCombobox, CrsdComboboxChip, CrsdComboboxChipInput, CrsdComboboxComponent, CrsdComboboxContent, CrsdComboboxEmpty, CrsdComboboxFilter, CrsdComboboxInput, CrsdComboboxItem, CrsdComboboxPanel, CrsdComboboxPortal, CrsdComboboxTrigger, CrsdComboboxTriggerHost, CrsdComboboxValues, CrsdConfirmDialog, CrsdContextMenu, CrsdContextMenuContent, CrsdContextMenuPortal, CrsdContextMenuTrigger, CrsdDialog, CrsdDialogClose, CrsdDialogContent, CrsdDialogDescription, CrsdDialogFooter, CrsdDialogHeader, CrsdDialogPortal, CrsdDialogTitle, CrsdDialogTrigger, CrsdDropdownMenu, CrsdDropdownMenuContent, CrsdDropdownMenuPortal, CrsdDropdownMenuTrigger, CrsdEmpty, CrsdEmptyDescription, CrsdEmptyHeader, CrsdEmptyMedia, CrsdEmptyTitle, CrsdField, CrsdFieldDescription, CrsdFieldError, CrsdFlipCard, CrsdFlipCardBack, CrsdFlipCardFront, CrsdFocusTrap, CrsdIcon, CrsdIconMultiselect, CrsdInput, CrsdLabel, CrsdMenu, CrsdMenuGroup, CrsdMenuItem, CrsdMenuLabel, CrsdMenuRadioGroup, CrsdMenuRadioIndicator, CrsdMenuRadioItem, CrsdRemovableBadge, CrsdSearchPicker, CrsdSelect, CrsdSelectContent, CrsdSelectItem, CrsdSelectPlaceholder, CrsdSelectPortal, CrsdSelectTrigger, CrsdSelectTriggerHost, CrsdSelectValue, CrsdSelectValueTemplate, CrsdSelectableList, CrsdSheet, CrsdSheetClose, CrsdSheetContent, CrsdSheetDescription, CrsdSheetFooter, CrsdSheetHeader, CrsdSheetPortal, CrsdSheetTitle, CrsdSheetTrigger, CrsdSidebar, CrsdSidebarContent, CrsdSidebarFooter, CrsdSidebarHeader, CrsdSidebarMenu, CrsdSidebarMenuButton, CrsdSidebarMenuItem, CrsdSidebarMenuLabel, CrsdSidebarService, CrsdSidebarWrapper, CrsdSpinner, CrsdSwitch, CrsdTable, CrsdTextarea, CrsdThemeService, CrsdTieredTextPreview, CrsdToastService, CrsdToaster, CrsdTooltip, CrsdTooltipPortal, DEFAULT_THEME_FEATURES, DIALOG_CONTENT_BASE, DIALOG_DESCRIPTION_BASE, DIALOG_FOOTER_BASE, DIALOG_HEADER_BASE, DIALOG_TITLE_BASE, EMPTY_BASE, EMPTY_DESCRIPTION_BASE, EMPTY_HEADER_BASE, EMPTY_MEDIA_BASE, EMPTY_MEDIA_ICON_VARIANT, EMPTY_TITLE_BASE, FIELD_BASE, FIELD_DESCRIPTION_BASE, FIELD_ERROR_BASE, FLIP_CARD_FACE, FLIP_CARD_FACE_BACK, FLIP_CARD_FACE_FRONT, FLIP_CARD_HOST, FLIP_CARD_HOST_FLIPPED, FLIP_CARD_INNER, FLIP_CARD_INNER_FLIPPED, ICON_BASE, ICON_SHAPES, ICON_SIZES, INPUT_BASE, LABEL_BASE, MENU_CONTENT_BASE, MENU_ITEM_BASE, MENU_LABEL_BASE, REMOVABLE_BADGE_LAYOUT, SELECT_CONTENT_BASE, SELECT_ITEM_BASE, SELECT_PLACEHOLDER_BASE, SELECT_TRIGGER_BASE, SELECT_TRIGGER_SIZES, SHEET_CONTENT_BASE, SHEET_SIDES, SIDEBAR_BASE, SIDEBAR_MENU_BUTTON_BASE, SPINNER_BASE, SPINNER_SIZES, SWITCH_TRACK_BASE, SWITCH_TRACK_SIZES, TEXTAREA_BASE, TOASTER_BASE, TOAST_BASE, TOAST_RICH_VARIANTS, TOAST_VARIANTS, TOOLTIP_CONTENT_BASE, applyCrsdColorModeFromStorage, applyCrsdThemeFromStorage, badgeClasses, buttonClasses, cn, crsdTailwindPreset, crsdTailwindPreset as crsdTailwindPresetDefault, defaultAutocompleteFilter, iconShapes, isIconBtnSize, mergeThemeFeatures, normalizeOptions, pickBlessedEmptyMessage, pickBlessedToastMessage, pickCursedEmptyMessage, pickCursedSkeletonLabel, pickCursedToastMessage, provideCrsdTheme, resolveIconShapes, sortRows, toast, toggleSortDirection };
export type { CrsdAlertVariant, CrsdAutocompleteFilterFn, CrsdAvatarGridItem, CrsdBadgeColor, CrsdBadgeSize, CrsdBadgeVariant, CrsdBlessedIconName, CrsdBtnColor, CrsdBtnSize, CrsdBtnVariant, CrsdCardVariant, CrsdColorMode, CrsdCursedIconName, CrsdCursedIntensity, CrsdEmptyMediaVariant, CrsdIconMultiselectOption, CrsdIconName, CrsdIconShape, CrsdIconSize, CrsdOpenState, CrsdOption, CrsdResolvedColorMode, CrsdSearchPickerOption, CrsdSelectTriggerSize, CrsdSelectableListItem, CrsdSheetSide, CrsdSidebarCollapsible, CrsdSidebarState, CrsdSortDirection, CrsdSpinnerSize, CrsdSwitchSize, CrsdSwitchVariant, CrsdTableColumn, CrsdTheme, CrsdThemeConfig, CrsdThemeFeature, CrsdThemeFeatureFlags, CrsdTieredTextPreviewData, CrsdTieredTextPreviewRow, CrsdToastData, CrsdToastOptions, CrsdToastVariant, CrsdTooltipSide };
